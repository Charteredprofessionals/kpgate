#!/bin/bash
# Kiro IDE Compatibility Verification Script
# Tests all required endpoints for KiroProxy Gateway v2.8.0

set -e

ENDPOINT="${1:-http://localhost:8085}"
PASSED=0
FAILED=0

echo "=========================================="
echo "KiroProxy v2.8.0 - Kiro IDE Compatibility"
echo "=========================================="
echo "Testing endpoint: $ENDPOINT"
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

test_endpoint() {
    local name=$1
    local method=$2
    local path=$3
    local expected_status=$4
    local check_json=${5:-true}

    echo -n "Testing $name... "
    
    if [ "$method" = "GET" ]; then
        response=$(curl -s -w "\n%{http_code}" "$ENDPOINT$path" -H "ngrok-skip-browser-warning: 69420" 2>/dev/null || echo "000")
    else
        response=$(curl -s -w "\n%{http_code}" -X "$method" "$ENDPOINT$path" \
            -H "Content-Type: application/json" \
            -H "ngrok-skip-browser-warning: 69420" \
            -d '{}' 2>/dev/null || echo "000")
    fi
    
    status=$(echo "$response" | tail -1)
    body=$(echo "$response" | head -n -1)
    
    if [ "$status" = "$expected_status" ]; then
        if [ "$check_json" = "true" ]; then
            if echo "$body" | jq . >/dev/null 2>&1; then
                echo -e "${GREEN}✓ PASS${NC} (HTTP $status, valid JSON)"
                PASSED=$((PASSED + 1))
                return 0
            else
                echo -e "${YELLOW}⚠ WARN${NC} (HTTP $status, invalid JSON)"
                PASSED=$((PASSED + 1))
                return 0
            fi
        else
            echo -e "${GREEN}✓ PASS${NC} (HTTP $status)"
            PASSED=$((PASSED + 1))
            return 0
        fi
    else
        echo -e "${RED}✗ FAIL${NC} (Expected $expected_status, got $status)"
        FAILED=$((FAILED + 1))
        return 1
    fi
}

# Test 1: Health Check
test_endpoint "Health Check" "GET" "/health" "200"

# Test 2: ListAvailableModels (AWS Bedrock format) - CRITICAL
echo -n "Testing ListAvailableModels (AWS)... "
response=$(curl -s "$ENDPOINT/listAvailableModels" -H "ngrok-skip-browser-warning: 69420" 2>/dev/null)
if echo "$response" | jq -e '.models | length > 0' >/dev/null 2>&1; then
    model_count=$(echo "$response" | jq '.models | length')
    echo -e "${GREEN}✓ PASS${NC} ($model_count models discovered)"
    PASSED=$((PASSED + 1))
else
    echo -e "${RED}✗ FAIL${NC} (No models found or invalid response)"
    FAILED=$((FAILED + 1))
fi

# Test 3: OpenAI-Compatible Model List
echo -n "Testing /v1/models (OpenAI)... "
response=$(curl -s "$ENDPOINT/v1/models" -H "ngrok-skip-browser-warning: 69420" 2>/dev/null)
if echo "$response" | jq -e '.data | length >= 0' >/dev/null 2>&1; then
    model_count=$(echo "$response" | jq '.data | length')
    echo -e "${GREEN}✓ PASS${NC} ($model_count free models)"
    PASSED=$((PASSED + 1))
else
    echo -e "${RED}✗ FAIL${NC} (Invalid OpenAI response)"
    FAILED=$((FAILED + 1))
fi

# Test 4: Status Endpoint
test_endpoint "Status Endpoint" "GET" "/status" "200"

# Test 5: Config Endpoint
test_endpoint "Config API" "GET" "/api/config" "200"

# Test 6: Metrics Endpoint
test_endpoint "Prometheus Metrics" "GET" "/metrics" "200" "false"

# Test 7: GetFeatureConfiguration
test_endpoint "GetFeatureConfiguration" "GET" "/featureconfiguration" "200"

# Test 8: GetProfile
test_endpoint "GetProfile" "GET" "/getprofile" "200"

# Test 9: GetUsageLimits
test_endpoint "GetUsageLimits" "GET" "/usagelimits" "200"

# Test 10: CORS Preflight
echo -n "Testing CORS Preflight... "
response=$(curl -s -w "\n%{http_code}" -X OPTIONS "$ENDPOINT/health" \
    -H "Origin: https://gemini.google.com" \
    -H "Access-Control-Request-Method: POST" \
    2>/dev/null)
status=$(echo "$response" | tail -1)
if [ "$status" = "200" ]; then
    echo -e "${GREEN}✓ PASS${NC} (HTTP 200)"
    PASSED=$((PASSED + 1))
else
    echo -e "${RED}✗ FAIL${NC} (Expected 200, got $status)"
    FAILED=$((FAILED + 1))
fi

# Test 11: AWS Bedrock Streaming (Basic)
echo -n "Testing AWS Bedrock Streaming... "
response=$(curl -s -w "\n%{http_code}" -X POST "$ENDPOINT/generateAssistantResponse" \
    -H "Content-Type: application/json" \
    -H "x-amzn-requestid: test-req-001" \
    -H "ngrok-skip-browser-warning: 69420" \
    -d '{
        "conversationState": {},
        "messages": [{"role": "user", "content": [{"text": "ping"}]}]
    }' 2>/dev/null || echo "000")
status=$(echo "$response" | tail -1)
if [ "$status" = "200" ]; then
    echo -e "${GREEN}✓ PASS${NC} (HTTP 200, streaming response)"
    PASSED=$((PASSED + 1))
else
    echo -e "${YELLOW}⚠ WARN${NC} (Expected 200, got $status - provider may be unavailable)"
    PASSED=$((PASSED + 1))
fi

echo ""
echo "=========================================="
echo "Results Summary"
echo "=========================================="
echo -e "Passed: ${GREEN}$PASSED${NC}"
echo -e "Failed: ${RED}$FAILED${NC}"
echo ""

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}✓ ALL TESTS PASSED${NC}"
    echo "This gateway is FULLY COMPATIBLE with Kiro IDE!"
    echo ""
    echo "Integration Config:"
    echo "{"
    echo "  \"bedrock\": {"
    echo "    \"endpoint\": \"$ENDPOINT\""
    echo "  }"
    echo "}"
    exit 0
else
    echo -e "${RED}✗ SOME TESTS FAILED${NC}"
    echo "Review failures above and check server logs."
    exit 1
fi
