import { redirect } from "next/navigation";

export default function Home() {
  // Land users on the KiroProxy Command Center GUI
  redirect("/config");
}
