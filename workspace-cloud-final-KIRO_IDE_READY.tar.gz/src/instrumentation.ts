/**
 * instrumentation.ts — runs once when Next.js boots.
 * Spawns the KiroProxy Gateway as a child process on port 3001 so the Next.js
 * dev server (port 3000) can reverse-proxy all KiroProxy routes via rewrites
 * in next.config.ts.
 *
 * The KiroProxy child process is detached so it survives HMR reloads.
 */

export async function register() {
  // Only run on the server side (not during build)
  if (process.env.NEXT_RUNTIME !== 'nodejs') return;

  const { spawn } = await import('node:child_process');
  const path = await import('node:path');
  const fs = await import('node:fs');

  const projectRoot = process.cwd();
  const kiroEntry = path.join(
    projectRoot,
    'kiroproxygateway',
    'KiroProxy-Gateway-v2.8.0',
    'src',
    'index.js'
  );

  if (!fs.existsSync(kiroEntry)) {
    console.warn(`[instrumentation] KiroProxy entry not found at ${kiroEntry}, skipping spawn`);
    return;
  }

  // Don't double-spawn in dev HMR
  if ((globalThis as any).__KIROPROXY_CHILD__) {
    console.log('[instrumentation] KiroProxy already spawned, skipping');
    return;
  }

  const child = spawn(process.execPath, [kiroEntry], {
    env: {
      ...process.env,
      PORT: '3001',
      BIND_HOST: '127.0.0.1',
      // Externally-managed ngrok-free.dev tunnel URL — reported in /health
      // and /status as `tunnel`, and used by the Canvas Bridge / Gemini
      // direct-auth flows so they can be reached from a public origin
      // (gemini.google.com user-scripts need a public HTTPS endpoint).
      TUNNEL_URL: process.env.TUNNEL_URL || 'https://reassure-shrivel-underwear.ngrok-free.dev',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: false,
    cwd: projectRoot,
  });

  (globalThis as any).__KIROPROXY_CHILD__ = child;

  child.stdout?.on('data', (d) => process.stdout.write(`[kiroproxy] ${d}`));
  child.stderr?.on('data', (d) => process.stderr.write(`[kiroproxy] ${d}`));
  child.on('exit', (code) => {
    console.log(`[instrumentation] KiroProxy child exited with code ${code}`);
    (globalThis as any).__KIROPROXY_CHILD__ = null;
  });

  console.log(`[instrumentation] Spawned KiroProxy on port 3001 (PID ${child.pid})`);

  // Spawn the z-ai-headers bridge — watches /etc/.z-ai-config (refreshed by
  // the platform on each new chat session) and writes /tmp/zai-headers.json
  // in the shape the ZaiBackend custom provider's `headers` field expects.
  const headersBridge = path.join(
    projectRoot,
    'kiroproxygateway',
    'KiroProxy-Gateway-v2.8.0',
    'scripts',
    'z-ai-headers.js'
  );
  if (fs.existsSync(headersBridge)) {
    if ((globalThis as any).__ZAI_HEADERS_CHILD__) {
      console.log('[instrumentation] z-ai-headers bridge already spawned, skipping');
    } else {
      const bridge = spawn(process.execPath, [headersBridge], {
        env: { ...process.env },
        stdio: ['ignore', 'pipe', 'pipe'],
        detached: false,
        cwd: projectRoot,
      });
      (globalThis as any).__ZAI_HEADERS_CHILD__ = bridge;
      bridge.stdout?.on('data', (d) => process.stdout.write(`[zai-bridge] ${d}`));
      bridge.stderr?.on('data', (d) => process.stderr.write(`[zai-bridge] ${d}`));
      bridge.on('exit', (code) => {
        console.log(`[instrumentation] z-ai-headers bridge exited with code ${code}`);
        (globalThis as any).__ZAI_HEADERS_CHILD__ = null;
      });
      console.log(`[instrumentation] Spawned z-ai-headers bridge (PID ${bridge.pid})`);
    }
  } else {
    console.warn(`[instrumentation] z-ai-headers bridge not found at ${headersBridge}`);
  }
}
