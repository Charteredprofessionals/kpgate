#!/bin/bash
# Cloud Deployment Script for KiroProxy Gateway v2.8.0
# Deploys to kproxy.space-z.ai

set -e

echo "=========================================="
echo "KiroProxy Gateway v2.8.0 Cloud Deployment"
echo "=========================================="
echo ""

# Change to gateway directory
cd "$(dirname "$0")/KiroProxy-Gateway-v2.8.0"

# Check Node.js version
echo "Checking Node.js version..."
node_version=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$node_version" -lt 18 ]; then
    echo "❌ Error: Node.js 18+ required (found v$node_version)"
    exit 1
fi
echo "✓ Node.js $(node --version)"

# Install dependencies
echo ""
echo "Installing dependencies..."
npm install --production

# Verify critical modules
echo ""
echo "Verifying critical modules..."
required_modules=(
    "@ngrok/ngrok"
    "express"
)

for module in "${required_modules[@]}"; do
    if npm list "$module" >/dev/null 2>&1; then
        echo "✓ $module"
    else
        echo "❌ Missing: $module"
        exit 1
    fi
done

# Check environment configuration
echo ""
echo "Checking environment configuration..."
if [ -f ".env" ]; then
    echo "✓ .env file found"
    
    # Check for ngrok token
    if grep -q "NGROK_AUTHTOKEN=" .env && ! grep -q "NGROK_AUTHTOKEN=$" .env; then
        echo "✓ NGROK_AUTHTOKEN configured"
    else
        echo "⚠ Warning: NGROK_AUTHTOKEN not configured (tunnel will not work)"
    fi
else
    echo "⚠ Warning: .env file not found (using defaults)"
fi

# Stop existing PM2 process
echo ""
echo "Stopping existing processes..."
pm2 delete kiroproxy-gateway 2>/dev/null || true
sleep 2

# Start with PM2
echo ""
echo "Starting KiroProxy Gateway..."
pm2 start src/index.js \
    --name kiroproxy-gateway \
    --node-args="--max-old-space-size=512" \
    --time \
    --merge-logs \
    --log logs/combined.log \
    --error logs/error.log \
    --out logs/access.log

# Wait for startup
echo ""
echo "Waiting for server to start..."
sleep 5

# Health check
echo ""
echo "Running health check..."
for i in {1..10}; do
    if curl -s http://localhost:8085/health >/dev/null 2>&1; then
        echo "✓ Server is healthy"
        break
    fi
    if [ $i -eq 10 ]; then
        echo "❌ Server failed to start"
        pm2 logs kiroproxy-gateway --lines 50
        exit 1
    fi
    echo "Waiting... ($i/10)"
    sleep 2
done

# Get tunnel URL
echo ""
echo "Retrieving tunnel URL..."
tunnel_url=$(curl -s http://localhost:8085/health | jq -r '.tunnel // "not available"')
echo "Tunnel: $tunnel_url"

# Check model count
echo ""
echo "Checking model discovery..."
model_count=$(curl -s http://localhost:8085/listAvailableModels | jq '.models | length' 2>/dev/null || echo "0")
echo "Models discovered: $model_count"

# Display status
echo ""
echo "=========================================="
echo "Deployment Summary"
echo "=========================================="
pm2 info kiroproxy-gateway

echo ""
echo "✓ Deployment complete!"
echo ""
echo "Next steps:"
echo "1. Save PM2 process list: pm2 save"
echo "2. Setup PM2 startup: pm2 startup"
echo "3. Verify endpoints:"
echo "   curl http://localhost:8085/health"
echo "   curl http://localhost:8085/listAvailableModels | jq '.models | length'"
echo ""
echo "Public endpoint: $tunnel_url"
echo "Local endpoint: http://localhost:8085"
echo ""
echo "Monitor logs: pm2 logs kiroproxy-gateway"
echo "Check status: pm2 status"
echo "Restart: pm2 restart kiroproxy-gateway"
