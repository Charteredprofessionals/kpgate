/**
 * src/providers/cline.js - Cline API Provider Adapter (https://api.cline.bot)
 * Pure CommonJS exportable module
 */

'use strict';

const https = require('https');
const { executeWithRetry } = require('../resilience/retry_engine');
const { isCircuitOpen } = require('../resilience/circuit_breaker');
const { ProxyError } = require('../resilience/errors');
const { loadCustomConfig, isKeyValid } = require('../config/index');
const { MODELS } = require('../config/catalog');
const { translateToolsToUpstream } = require('../translators/tool_translator');
const { recordProviderCall } = require('../resilience/metrics');
const { extractToolsAndTextFromProviderResponse } = require('../translators/tool_extractor');

const CLINE_TIMEOUT = 120000;

function callClineApi(messages, requestedModel, tools = [], otomodeContext = null) {
  return executeWithRetry(async () => {
    if (isCircuitOpen('cline')) {
      const err = new Error('Cline API circuit breaker is open');
      err.code = 'CIRCUIT_OPEN';
      throw err;
    }

    const start = Date.now();

    return new Promise((resolve, reject) => {
      const cfg = loadCustomConfig();
      const apiKey = isKeyValid(cfg.clineApiKey) ? cfg.clineApiKey.trim() : null;
      if (!apiKey) {
        const err = new Error('No valid Cline API key configured in kiro_ai_config.json');
        err.code = 'MISSING_API_KEY';
        return reject(err);
      }

      const CLINE_FREE_DEFAULT = 'nvidia/nemotron-3.5-lightning:free';
      let modelSlug = requestedModel || CLINE_FREE_DEFAULT;

      if (!modelSlug.includes('/')) modelSlug = CLINE_FREE_DEFAULT;

      if (requestedModel === 'cline-deepseek-v4-flash') modelSlug = 'deepseek/deepseek-v4-flash-0731';
      else if (requestedModel === 'cline-glm-flash') modelSlug = 'z-ai/glm-5.3-flash';
      else if (requestedModel === 'cline-longcat-2') modelSlug = 'meituan/longcat-2.0';
      else if (requestedModel === 'cline-laguna-s') modelSlug = 'poolside/laguna-s-2.1:free';
      else if (requestedModel === 'cline-nemotron') modelSlug = 'nvidia/nemotron-3.5-lightning';
      else {
        const found = MODELS.models.find(m => m.modelId === requestedModel);
        if (found?.upstreamSlug) modelSlug = found.upstreamSlug;
      }

      if (!modelSlug.includes('/')) {
        return reject(new Error(`Cline API requires modelType/model format, got: '${modelSlug}'`));
      }

      const translatedTools = tools && tools.length > 0
        ? translateToolsToUpstream(tools, 'openai')
        : undefined;

      const requestBody = {
        model: modelSlug,
        messages: messages,
        stream: false
      };

      if (translatedTools) {
        requestBody.tools = translatedTools;
      }

      const postData = JSON.stringify(requestBody);

      const options = {
        hostname: 'api.cline.bot',
        port: 443,
        path: '/api/v1/chat/completions',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
          'Authorization': `Bearer ${apiKey}`,
          'User-Agent': 'Cline/4.1.17'
        },
        timeout: CLINE_TIMEOUT
      };

      console.log(`[KiroProxy] Forwarding to Cline API (https://api.cline.bot, model=${modelSlug}${translatedTools ? `, ${translatedTools.length} tools` : ''})...`);

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          const latency = Date.now() - start;

          try {
            const parsed = JSON.parse(data);
            const unwrapped = parsed.data || parsed;
            if (res.statusCode >= 200 && res.statusCode < 300) {
              const firstChoice = unwrapped.choices?.[0];
              if (firstChoice?.message && !firstChoice.message.content && firstChoice.message.reasoning_content) {
                firstChoice.message.content = firstChoice.message.reasoning_content;
              }

              const extracted = extractToolsAndTextFromProviderResponse(unwrapped, tools);
              const hasValidContent = Boolean(((extracted.text && extracted.text.trim().length > 0) || (extracted.toolCalls && extracted.toolCalls.length > 0)) && !parsed.error);

              if (hasValidContent) {
                recordProviderCall('cline', true, latency);
                resolve({
                  ...unwrapped,
                  _kiro: extracted
                });
                return;
              }

              console.warn(`[KiroProxy] ⚠️ Cline API returned HTTP 200 with empty completion (0 text, 0 tools) for model '${modelSlug}'`);
              recordProviderCall('cline', false, latency);

              if (otomodeContext && otomodeContext._fallbackList && otomodeContext._fallbackList.length > 0) {
                const oldModel = otomodeContext._activeModel || modelSlug || requestedModel;
                const nextModel = otomodeContext._fallbackList.shift();
                otomodeContext._activeModel = nextModel;
                const delay = 50;
                console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName || 'Cline'}) from ${oldModel} → ${nextModel} due to EMPTY_RESPONSE (HTTP 200)`);
                (async () => {
                  await new Promise(r => setTimeout(r, delay));
                  try {
                    const result = await callClineApi(messages, nextModel, tools, otomodeContext);
                    resolve(result);
                  } catch (err) {
                    reject(err);
                  }
                })();
                return;
              }

              if (otomodeContext && (!otomodeContext._fallbackList || otomodeContext._fallbackList.length === 0)) {
                console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName || 'Cline'}`);
              }

              const emptyErr = new ProxyError(
                'EMPTY_RESPONSE',
                `Cline API (${res.statusCode}): Model returned 0 text and 0 tools`,
                'Free model context saturated or empty completion received',
                { statusCode: res.statusCode }
              );
              emptyErr.code = 'EMPTY_RESPONSE';
              reject(emptyErr);
              return;
            } else {
              if (translatedTools && (res.statusCode === 400 || res.statusCode === 422)) {
                console.log(`[KiroProxy] 🔄 Cline model '${modelSlug}' rejected native tools (${res.statusCode}); retrying with prompt-based tool guide...`);
                callClineApi(messages, modelSlug, [], otomodeContext).then(resolve).catch(reject);
                return;
              }

              recordProviderCall('cline', false, latency);

              const isOtomodeRetryable = res.statusCode >= 400;

              if (otomodeContext && otomodeContext._fallbackList.length > 0 && isOtomodeRetryable) {
                const oldModel = otomodeContext._activeModel;
                const nextModel = otomodeContext._fallbackList.shift();
                if (nextModel) {
                  otomodeContext._activeModel = nextModel;
                  const delay = 250 + Math.random() * 500;
                  console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName}) from ${oldModel} → ${nextModel} due to HTTP ${res.statusCode} (${otomodeContext._fallbackList.length} free models remaining)`);
                  (async () => {
                    await new Promise(r => setTimeout(r, delay));
                    try {
                      const result = await callClineApi(messages, nextModel, tools, otomodeContext);
                      resolve(result);
                    } catch (err) {
                      reject(err);
                    }
                  })();
                  return;
                }
              }

              if (otomodeContext && otomodeContext._fallbackList.length === 0 && isOtomodeRetryable) {
                console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName}`);
              }

              const err = new Error(`Cline API (${res.statusCode}): ${parsed.error?.message || parsed.error || data.slice(0, 100)}`);
              err.code = 'PROVIDER_ERROR';
              reject(err);
            }
          } catch {
            recordProviderCall('cline', false, latency);
            const err = new Error(`Invalid JSON from Cline API (${res.statusCode}): ${data.slice(0, 150)}`);
            err.code = 'INVALID_RESPONSE';
            reject(err);
          }
        });
      });

      req.on('error', err => {
        recordProviderCall('cline', false, Date.now() - start);
        err.code = err.code || 'NETWORK_ERROR';
        reject(err);
      });

      req.on('timeout', () => {
        req.destroy();
        recordProviderCall('cline', false, Date.now() - start);
        const err = new Error(`Cline API timed out after ${CLINE_TIMEOUT}ms`);
        err.code = 'TIMEOUT';
        reject(err);
      });

      req.write(postData);
      req.end();
    });
  }, 'cline', otomodeContext ? 1 : 3);
}

module.exports = {
  callClineApi
};
