/**
 * src/providers/canvas_bridge.js - Isolated Ngrok Gemini Canvas Browser Session Bridge
 * Excluded from Global Automode; isolated browser queue & session architecture
 * Pure CommonJS exportable module
 */

'use strict';

const { executeWithRetry } = require('../resilience/retry_engine');
const { isCircuitOpen } = require('../resilience/circuit_breaker');
const { ProxyError } = require('../resilience/errors');
const { loadCustomConfig } = require('../config/index');
const { recordProviderCall } = require('../resilience/metrics');
const { extractToolCallsFromResponse, stripToolBlocksFromText } = require('../translators/tool_extractor');

const MAX_QUEUE_SIZE = 100;
const MAX_QUEUE_AGE = 300000; // 5 minutes
const geminiQueue = [];
const pendingGeminiRequests = new Map();
const cancelledGeminiRequests = new Set();

const pollRateLimiter = new Map(); // clientIP → [timestamps]
const MAX_POLLS_PER_MINUTE = 20;

function cleanStaleQueueEntries() {
  const now = Date.now();
  const before = geminiQueue.length;

  let i = geminiQueue.length;
  while (i--) {
    const entry = geminiQueue[i];
    const age = now - (entry.timestamp || entry.queuedAt || 0);

    if (age > MAX_QUEUE_AGE) {
      console.warn(`[BridgeQueue] Removing stale request ${entry.id} (age: ${Math.floor(age / 1000)}s)`);
      geminiQueue.splice(i, 1);

      const pending = pendingGeminiRequests.get(entry.id);
      if (pending?.reject) {
        pending.reject(new Error(`Request expired in queue after ${Math.floor(age / 1000)}s`));
      }
      pendingGeminiRequests.delete(entry.id);
    }
  }

  if (geminiQueue.length < before) {
    console.log(`[BridgeQueue] Cleaned ${before - geminiQueue.length} stale entries`);
  }
}

function checkPollRateLimit(clientIP) {
  const now = Date.now();
  const timestamps = pollRateLimiter.get(clientIP) || [];

  const recent = timestamps.filter(t => now - t < 60000);

  if (recent.length >= MAX_POLLS_PER_MINUTE) {
    return false;
  }

  recent.push(now);
  pollRateLimiter.set(clientIP, recent);
  return true;
}

// Pruning payload to ~400 tokens / 1500 chars to avoid Google Canvas auto-auth errors
function prunePayloadForCanvas(messages, maxTotalChars = 1500) {
  if (!Array.isArray(messages) || messages.length === 0) {
    return [{ role: 'user', content: 'Hello' }];
  }

  const systemMsg = messages.find(m => m.role === 'system');
  let sanitizedSystem = '';
  if (systemMsg && typeof systemMsg.content === 'string') {
    sanitizedSystem = systemMsg.content.slice(0, 200).trim();
  }

  const nonSystem = messages.filter(m => m.role !== 'system');
  const chatBudget = Math.max(400, maxTotalChars - sanitizedSystem.length);

  let lastUserTurn = null;
  for (let i = nonSystem.length - 1; i >= 0; i--) {
    if (nonSystem[i].role === 'user') {
      lastUserTurn = nonSystem[i];
      break;
    }
  }

  if (!lastUserTurn && nonSystem.length > 0) {
    lastUserTurn = nonSystem[nonSystem.length - 1];
  }

  let userContent = typeof lastUserTurn?.content === 'string'
    ? lastUserTurn.content
    : JSON.stringify(lastUserTurn?.content || 'Hello');

  if (userContent.length > chatBudget) {
    userContent = userContent.slice(0, chatBudget - 35) + '... [truncated for canvas limit]';
  }

  const pruned = [];
  if (sanitizedSystem) {
    pruned.push({ role: 'system', content: sanitizedSystem });
  }
  pruned.push({ role: 'user', content: userContent });
  return pruned;
}

function callNgrokGemini(messages, requestedModel, tools = []) {
  return executeWithRetry(async () => {
    if (isCircuitOpen('ngrok')) {
      throw new ProxyError(
        'CIRCUIT_OPEN',
        'Ngrok/Gemini circuit breaker is open',
        'Wait 30s for automatic recovery or try another provider'
      );
    }

    const start = Date.now();
    return new Promise((resolve, reject) => {
      const geminiModel = 'gemini-3-flash-preview';
      const controlledMessages = prunePayloadForCanvas(messages, 1500);

      const reqId = `gemini_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

      const queueEntry = {
        id: reqId,
        model: geminiModel,
        payload: {
          model: geminiModel,
          messages: controlledMessages,
          tools: tools && tools.length > 0 ? tools : undefined
        }
      };

      if (geminiQueue.length >= MAX_QUEUE_SIZE) {
        reject(new ProxyError(
          'QUEUE_FULL',
          `Browser bridge queue full (${MAX_QUEUE_SIZE} requests pending)`,
          'Wait for queue to clear or increase MAX_QUEUE_SIZE'
        ));
        return;
      }

      queueEntry.timestamp = Date.now();
      geminiQueue.push(queueEntry);
      console.log(`[BridgeQueue] Added ${reqId} to queue (depth: ${geminiQueue.length}/${MAX_QUEUE_SIZE}, model: ${geminiModel})`);

      const pendingEntry = {
        id: reqId,
        model: geminiModel,
        buffer: '',
        tools: tools,
        isStream: false,
        startTime: Date.now(),
        resolve: (response) => {
          const latency = Date.now() - start;
          recordProviderCall('ngrok', true, latency);
          resolve(response);
        },
        reject: (error) => {
          const latency = Date.now() - start;
          recordProviderCall('ngrok', false, latency);
          reject(error);
        }
      };

      pendingGeminiRequests.set(reqId, pendingEntry);

      const timeout = setTimeout(() => {
        if (pendingGeminiRequests.has(reqId)) {
          pendingGeminiRequests.delete(reqId);
          const latency = Date.now() - start;
          recordProviderCall('ngrok', false, latency);
          reject(new ProxyError(
            'TIMEOUT',
            'Browser bridge did not respond within 120s',
            'Ensure Gemini userscript is active in browser and polling /poll endpoint',
            { reqId, queueDepth: geminiQueue.length }
          ));
        }
      }, 120000);

      const originalResolve = pendingEntry.resolve;
      const originalReject = pendingEntry.reject;

      pendingEntry.resolve = (response) => {
        clearTimeout(timeout);
        originalResolve(response);
      };

      pendingEntry.reject = (error) => {
        clearTimeout(timeout);
        originalReject(error);
      };
    });
  }, 'ngrok', 3);
}

function handleBridgeChunk(reqId, textChunk) {
  const entry = pendingGeminiRequests.get(reqId);
  if (!entry) return;

  entry.buffer = (entry.buffer || '') + textChunk;

  if (entry.isStream && entry.res && !entry.res.headersSent) {
    try {
      entry.res.write(`data: ${JSON.stringify({
        id: `chatcmpl-${reqId}`,
        object: 'chat.completion.chunk',
        created: Math.floor(Date.now() / 1000),
        model: entry.model || 'gemini-2.0-flash-exp',
        choices: [{
          delta: { content: textChunk },
          index: 0,
          finish_reason: null
        }]
      })}\n\n`);
    } catch (err) {
      console.error(`[BridgeChunk] Error writing chunk for ${reqId}:`, err.message);
    }
  }
}

function normalizeGeminiToolCalls(functionCalls) {
  return functionCalls
    .filter(fc => fc && typeof fc.name === 'string' && fc.name.length > 0)
    .map(fc => {
      let name = fc.name.trim();
      let args = (typeof fc.args === 'object' && !Array.isArray(fc.args)) ? { ...fc.args } : {};

      if (name === 'write_file' || name === 'write_to_file' || name === 'create_file') name = 'fs_write';
      else if (name === 'edit_file' || name === 'modify_file') name = (args.oldStr || args.old_str || args.find) ? 'str_replace' : 'fs_write';
      else if (name === 'run_command' || name === 'bash' || name === 'powershell' || name === 'terminal') name = 'execute_pwsh';
      else if (name === 'ls' || name === 'dir' || name === 'list_dir') name = 'list_directory';
      else if (name === 'cat' || name === 'type' || name === 'read' || name === 'open_file') name = 'read_file';
      else if (name === 'search_files' || name === 'find_files' || name === 'find') name = 'file_search';
      else if (name === 'grep' || name === 'search_code') name = 'grep_search';
      else if (name === 'general-task-execution' || name === 'context-gatherer') {
        args.name = name;
        args.prompt = args.prompt || '';
        args.explanation = args.explanation || `Delegating ${name} task`;
        name = 'invoke_sub_agent';
      }

      if (name === 'list_directory') {
        const p = args.path || args.directory || args.dir || args.folder || args.target;
        if (!p || p === '.') {
          const workspaceRoot = process.env.WORKSPACE_ROOT || process.cwd();
          console.warn(`[KiroProxy] ⚠️ list_directory missing/relative path from Gemini — defaulting to workspace root: ${workspaceRoot}`);
          args.path = workspaceRoot;
        } else {
          args.path = p;
        }
        if (!args.explanation) args.explanation = `Listing contents of ${args.path}`;
      } else if (name === 'fs_write') {
        args.path = args.path || args.file || args.filepath || 'output.txt';
        args.text = args.text || args.content || args.code || '';
      } else if (name === 'str_replace') {
        args.path = args.path || args.file || args.filepath || '';
        args.oldStr = args.oldStr || args.old_str || args.find || '';
        args.newStr = args.newStr || args.new_str || args.replace || '';
      } else if (name === 'read_file' || name === 'read_code') {
        args.path = args.path || args.file || args.filepath || '';
        name = 'read_file';
      } else if (name === 'execute_pwsh' || name === 'execute_bash') {
        args.command = args.command || args.cmd || '';
        name = 'execute_pwsh';
      } else if (name === 'grep_search') {
        args.query = args.query || args.pattern || args.regex || '';
      } else if (name === 'file_search') {
        args.query = args.query || args.pattern || args.filename || '';
      } else if (name === 'validate_spec_format') {
        args.filePath = args.filePath || args.path || '';
      } else if (name === 'task_update') {
        args.tasksFilePath = args.tasksFilePath || args.path || '';
        args.taskId = String(args.taskId || args.id || '');
        args.status = args.status || 'completed';
      } else if (name === 'task_list') {
        args.tasksFilePath = args.tasksFilePath || args.path || '';
      }

      return { name, args };
    });
}

function handleBridgeDone(reqId, functionCalls, errorMessage) {
  const entry = pendingGeminiRequests.get(reqId);
  if (!entry) return;

  const finalContent = entry.buffer || '';

  if (errorMessage) {
    console.error(`[BridgeDone] Error for ${reqId}:`, errorMessage);

    if (entry.reject) {
      entry.reject(new ProxyError(
        'BRIDGE_ERROR',
        errorMessage,
        'Browser bridge reported an error during Gemini inference'
      ));
      pendingGeminiRequests.delete(reqId);
      return;
    }

    if (entry.res && !entry.res.headersSent) {
      entry.res.writeHead(500, { 'Content-Type': 'application/json' });
      entry.res.end(JSON.stringify({
        error: {
          message: errorMessage,
          type: 'bridge_error',
          code: 'gemini_bridge_failed'
        }
      }));
    }
    pendingGeminiRequests.delete(reqId);
    return;
  }

  const rawTools = entry.tools || [];
  let detectedTools = [];

  if (functionCalls && functionCalls.length > 0) {
    detectedTools = normalizeGeminiToolCalls(functionCalls);
    console.log(`[BridgeDone] Normalized ${functionCalls.length} Gemini functionCall(s) → ${detectedTools.map(t => t.name).join(', ')}`);
  } else {
    detectedTools = extractToolCallsFromResponse(finalContent, rawTools);
  }

  const cleanedText = detectedTools.length > 0
    ? stripToolBlocksFromText(finalContent)
    : finalContent;

  if (entry.resolve) {
    const responseData = {
      id: `chatcmpl-${reqId}`,
      object: 'chat.completion',
      created: Math.floor(Date.now() / 1000),
      model: entry.model || 'gemini-2.0-flash-exp',
      choices: [{
        index: 0,
        message: {
          role: 'assistant',
          content: cleanedText
        },
        finish_reason: detectedTools.length > 0 ? 'tool_calls' : 'stop'
      }],
      usage: {
        prompt_tokens: Math.round((entry.prompt || '').length / 4),
        completion_tokens: Math.round(finalContent.length / 4),
        total_tokens: Math.round(((entry.prompt || '').length + finalContent.length) / 4)
      },
      _kiro: {
        text: cleanedText,
        toolCalls: detectedTools,
        stopReason: detectedTools.length > 0 ? 'TOOL_USE' : 'END_TURN'
      }
    };

    if (detectedTools.length > 0) {
      responseData.choices[0].message.tool_calls = detectedTools.map((tool, i) => ({
        id: `call_${Date.now()}_${i}`,
        type: 'function',
        function: {
          name: tool.name || 'unknown',
          arguments: JSON.stringify(tool.args || {})
        }
      }));
    }

    entry.resolve(responseData);
    pendingGeminiRequests.delete(reqId);
    return;
  }

  if (entry.isStream) {
    const choices = [{ delta: {}, index: 0, finish_reason: 'stop' }];
    if (detectedTools.length > 0) {
      choices[0].finish_reason = 'tool_calls';
      choices[0].delta = {
        tool_calls: detectedTools.map((tool, i) => ({
          index: i,
          id: `call_${Date.now()}_${i}`,
          type: 'function',
          function: {
            name: tool.name || 'unknown',
            arguments: JSON.stringify(tool.args || {})
          }
        }))
      };
    }

    try {
      entry.res.write(`data: ${JSON.stringify({
        id: `chatcmpl-${reqId}`,
        object: 'chat.completion.chunk',
        created: Math.floor(Date.now() / 1000),
        model: entry.model || 'gemini-2.0-flash-exp',
        choices
      })}\n\n`);
      entry.res.write('data: [DONE]\n\n');
      entry.res.end();
    } catch (err) {
      console.error(`[BridgeDone] Error finishing stream for ${reqId}:`, err.message);
    }
  } else {
    const responseData = {
      id: `chatcmpl-${reqId}`,
      object: 'chat.completion',
      created: Math.floor(Date.now() / 1000),
      model: entry.model || 'gemini-2.0-flash-exp',
      choices: [{
        index: 0,
        message: {
          role: 'assistant',
          content: cleanedText
        },
        finish_reason: detectedTools.length > 0 ? 'tool_calls' : 'stop'
      }],
      usage: {
        prompt_tokens: Math.round((entry.prompt || '').length / 4),
        completion_tokens: Math.round(finalContent.length / 4),
        total_tokens: Math.round(((entry.prompt || '').length + finalContent.length) / 4)
      }
    };

    if (detectedTools.length > 0) {
      responseData.choices[0].message.tool_calls = detectedTools.map((tool, i) => ({
        id: `call_${Date.now()}_${i}`,
        type: 'function',
        function: {
          name: tool.name || 'unknown',
          arguments: JSON.stringify(tool.args || {})
        }
      }));
    }

    try {
      if (!entry.res.headersSent) {
        entry.res.writeHead(200, { 'Content-Type': 'application/json' });
      }
      entry.res.end(JSON.stringify(responseData));
    } catch (err) {
      console.error(`[BridgeDone] Error sending non-stream response for ${reqId}:`, err.message);
    }
  }

  pendingGeminiRequests.delete(reqId);
}

module.exports = {
  callNgrokGemini,
  handleBridgeChunk,
  handleBridgeDone,
  normalizeGeminiToolCalls,
  prunePayloadForCanvas,
  checkPollRateLimit,
  cleanStaleQueueEntries,
  geminiQueue,
  pendingGeminiRequests,
  cancelledGeminiRequests,
  pollRateLimiter,
  MAX_QUEUE_SIZE,
  MAX_QUEUE_AGE,
  MAX_POLLS_PER_MINUTE
};
