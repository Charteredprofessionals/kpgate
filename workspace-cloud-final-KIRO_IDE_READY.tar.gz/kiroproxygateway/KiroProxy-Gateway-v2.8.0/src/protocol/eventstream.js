/**
 * src/protocol/eventstream.js - AWS Bedrock EventStream binary framer & CRC32
 * Implements 12-byte prelude, type 7 string headers, and trailing message CRC32 (INV-05)
 * Pure CommonJS exportable module
 */

'use strict';

const zlib = require('zlib');

/**
 * Creates an AWS EventStream binary frame with 12-byte prelude and CRC32 checksums
 * @param {Object} headers - Key-value map of string headers
 * @param {string|Buffer} payload - Message payload
 * @returns {Buffer} Formatted binary EventStream frame
 */
function createEventStreamFrame(headers, payload) {
  const payloadBuf = typeof payload === 'string' ? Buffer.from(payload, 'utf-8') : (Buffer.isBuffer(payload) ? payload : Buffer.from(JSON.stringify(payload), 'utf-8'));
  const hBufs = [];

  for (const [k, v] of Object.entries(headers)) {
    const kBuf = Buffer.from(k, 'utf-8');
    const vBuf = Buffer.from(String(v), 'utf-8');
    const h = Buffer.alloc(1 + kBuf.length + 1 + 2 + vBuf.length);
    let ho = 0;
    h.writeUInt8(kBuf.length, ho++);
    kBuf.copy(h, ho);
    ho += kBuf.length;
    h.writeUInt8(7, ho++); // type 7 = string
    h.writeUInt16BE(vBuf.length, ho);
    ho += 2;
    vBuf.copy(h, ho);
    hBufs.push(h);
  }

  const headersBuf = Buffer.concat(hBufs);
  const totalLen = 12 + headersBuf.length + payloadBuf.length + 4;
  const prelude = Buffer.alloc(8);
  prelude.writeUInt32BE(totalLen, 0);
  prelude.writeUInt32BE(headersBuf.length, 4);

  const preludeCrc = zlib.crc32(prelude);

  const msgWithoutCrc = Buffer.concat([
    prelude,
    Buffer.alloc(4),
    headersBuf,
    payloadBuf
  ]);
  msgWithoutCrc.writeUInt32BE(preludeCrc, 8);

  const msgCrc = zlib.crc32(msgWithoutCrc);
  const finalMsg = Buffer.concat([msgWithoutCrc, Buffer.alloc(4)]);
  finalMsg.writeUInt32BE(msgCrc, finalMsg.length - 4);
  return finalMsg;
}

/**
 * Creates a Converse-compatible EventStream frame with JSON payload and proper headers
 * @param {string} eventType - e.g. 'assistantResponseEvent', 'toolUseEvent', 'metadataEvent'
 * @param {Object} payloadObj - Payload to JSON-serialize
 * @returns {Buffer}
 */
function createConverseEvent(eventType, payloadObj) {
  return createEventStreamFrame(
    {
      ':event-type': eventType,
      ':content-type': 'application/json',
      ':message-type': 'event'
    },
    JSON.stringify(payloadObj)
  );
}

module.exports = {
  createEventStreamFrame,
  createConverseEvent
};
