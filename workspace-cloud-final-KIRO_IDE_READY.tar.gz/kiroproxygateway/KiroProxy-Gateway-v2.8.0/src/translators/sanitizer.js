/**
 * src/translators/sanitizer.js - Windows path backslash & schema sanitizer
 * Enforces INV-07 (Dual-Stage Windows Path Backslash Sanitization)
 * Pure CommonJS exportable module
 */

'use strict';

/**
 * Sanitize unescaped backslashes in Windows file paths before JSON.parse
 * Replaces backslashes not followed by valid JSON escape characters (", \, /, b, f, n, r, t, uXXXX)
 * @param {string} jsonStr
 * @returns {string}
 */
function sanitizeJsonBackslashes(jsonStr) {
  if (!jsonStr) return '';
  return jsonStr.replace(/\\(?!["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '\\\\');
}

/**
 * Sanitize OpenAPI/Anthropic schema for upstream provider compatibility
 * Removes incompatible fields and normalizes type casing
 * @param {Object} schema
 * @param {string} providerType - 'gemini' | 'anthropic' | 'openai' | 'default'
 * @returns {Object}
 */
function sanitizeSchemaForUpstream(schema, providerType = 'default') {
  if (!schema || typeof schema !== 'object') {
    return { type: 'object', properties: {} };
  }
  
  const copy = JSON.parse(JSON.stringify(schema));
  
  function cleanNode(node) {
    if (!node || typeof node !== 'object') return;
    
    // Remove OpenAPI-specific fields that providers don't accept
    delete node.$schema;
    delete node.title;
    delete node.additionalProperties;
    delete node.default;
    delete node.examples;
    delete node.$id;
    delete node.$ref;
    
    // Normalize type casing based on provider
    if (typeof node.type === 'string') {
      if (providerType === 'gemini') {
        node.type = node.type.toUpperCase(); // Gemini requires UPPERCASE
      } else {
        node.type = node.type.toLowerCase(); // Most providers use lowercase
      }
    } else if (node.type === undefined && node.properties) {
      node.type = providerType === 'gemini' ? 'OBJECT' : 'object';
    }
    
    // Recursively clean nested properties
    if (node.properties) {
      for (const key of Object.keys(node.properties)) {
        cleanNode(node.properties[key]);
      }
    }
    if (node.items) {
      cleanNode(node.items);
    }
    if (node.allOf) {
      node.allOf.forEach(cleanNode);
    }
    if (node.anyOf) {
      node.anyOf.forEach(cleanNode);
    }
    if (node.oneOf) {
      node.oneOf.forEach(cleanNode);
    }
  }
  
  cleanNode(copy);
  
  // Ensure root has type and properties
  if (!copy.type) {
    copy.type = providerType === 'gemini' ? 'OBJECT' : 'object';
  }
  if (!copy.properties && copy.type === 'object') {
    copy.properties = {};
  }
  
  return copy;
}

module.exports = {
  sanitizeJsonBackslashes,
  sanitizeSchemaForUpstream
};
