/**
 * src/resilience/metrics.js - Metrics collector and percentile calculation
 * Enforces singleton identity (INV-09)
 * Pure CommonJS exportable module
 */

'use strict';

const METRICS = {
  toolInvocations: { total: 0, success: 0, failure: 0 },
  providerCalls: {
    kilo: { total: 0, success: 0, failure: 0, totalLatency: 0, latencies: [] },
    cline: { total: 0, success: 0, failure: 0, totalLatency: 0, latencies: [] },
    openrouter: { total: 0, success: 0, failure: 0, totalLatency: 0, latencies: [] },
    orcarouter: { total: 0, success: 0, failure: 0, totalLatency: 0, latencies: [] },
    ngrok: { total: 0, success: 0, failure: 0, totalLatency: 0, latencies: [] },
    gemini: { total: 0, success: 0, failure: 0, totalLatency: 0, latencies: [] }
  },
  sessionStart: Date.now()
};

function recordProviderCall(providerName, success, latency) {
  let metric = METRICS.providerCalls[providerName];
  if (!metric) {
    metric = { total: 0, success: 0, failure: 0, totalLatency: 0, latencies: [] };
    METRICS.providerCalls[providerName] = metric;
  }

  metric.total++;
  if (success) metric.success++;
  else metric.failure++;
  
  metric.totalLatency += latency;
  metric.latencies.push(latency);
  if (metric.latencies.length > 100) metric.latencies.shift(); // Keep last 100
}

function calculatePercentile(latencies, percentile) {
  if (latencies.length === 0) return 0;
  const sorted = [...latencies].sort((a, b) => a - b);
  const index = Math.ceil((percentile / 100) * sorted.length) - 1;
  return sorted[Math.max(0, index)];
}

function getMetricsSnapshot() {
  const snapshot = {
    uptime: Date.now() - METRICS.sessionStart,
    toolInvocations: { ...METRICS.toolInvocations },
    providers: {}
  };

  for (const [name, metric] of Object.entries(METRICS.providerCalls)) {
    snapshot.providers[name] = {
      total: metric.total,
      success: metric.success,
      failure: metric.failure,
      successRate: metric.total > 0 ? (metric.success / metric.total * 100).toFixed(2) + '%' : 'N/A',
      avgLatency: metric.total > 0 ? Math.round(metric.totalLatency / metric.total) : 0,
      p50: calculatePercentile(metric.latencies, 50),
      p99: calculatePercentile(metric.latencies, 99)
    };
  }

  return snapshot;
}

module.exports = {
  METRICS,
  recordProviderCall,
  calculatePercentile,
  getMetricsSnapshot
};
