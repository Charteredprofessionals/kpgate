/**
 * src/resilience/circuit_breaker.js - Circuit Breaker Finite State Machine
 * Enforces singleton identity (INV-09) and state transitions (CLOSED, OPEN, HALF_OPEN)
 * Pure CommonJS exportable module
 */

'use strict';

const CIRCUIT_BREAKERS = {
  kilo: { state: 'CLOSED', failures: 0, lastFailure: 0, resetTimeout: 30000 },
  cline: { state: 'CLOSED', failures: 0, lastFailure: 0, resetTimeout: 30000 },
  openrouter: { state: 'CLOSED', failures: 0, lastFailure: 0, resetTimeout: 30000 },
  orcarouter: { state: 'CLOSED', failures: 0, lastFailure: 0, resetTimeout: 30000 },
  ngrok: { state: 'CLOSED', failures: 0, lastFailure: 0, resetTimeout: 30000 },
  gemini: { state: 'CLOSED', failures: 0, lastFailure: 0, resetTimeout: 30000 }
};

const CIRCUIT_FAILURE_THRESHOLD = 5;
const HALF_OPEN_SUCCESS_THRESHOLD = 3;

function recordProviderSuccess(providerName) {
  let breaker = CIRCUIT_BREAKERS[providerName];
  if (!breaker) {
    breaker = { state: 'CLOSED', failures: 0, lastFailure: 0, resetTimeout: 30000 };
    CIRCUIT_BREAKERS[providerName] = breaker;
  }
  
  if (breaker.state === 'HALF_OPEN') {
    breaker.halfOpenSuccesses = (breaker.halfOpenSuccesses || 0) + 1;
    if (breaker.halfOpenSuccesses >= HALF_OPEN_SUCCESS_THRESHOLD) {
      breaker.state = 'CLOSED';
      breaker.failures = 0;
      breaker.halfOpenSuccesses = 0;
      console.log(`[CircuitBreaker] ✅ ${providerName} fully recovered (CLOSED after ${HALF_OPEN_SUCCESS_THRESHOLD} successes)`);
    } else {
      console.log(`[CircuitBreaker] ${providerName} HALF_OPEN testing: ${breaker.halfOpenSuccesses}/${HALF_OPEN_SUCCESS_THRESHOLD} successes`);
    }
  } else {
    breaker.failures = 0;
    breaker.state = 'CLOSED';
    breaker.halfOpenSuccesses = 0;
  }
}

function recordProviderFailure(providerName) {
  let breaker = CIRCUIT_BREAKERS[providerName];
  if (!breaker) {
    breaker = { state: 'CLOSED', failures: 0, lastFailure: 0, resetTimeout: 30000 };
    CIRCUIT_BREAKERS[providerName] = breaker;
  }

  breaker.failures++;
  breaker.lastFailure = Date.now();

  if (breaker.failures >= CIRCUIT_FAILURE_THRESHOLD) {
    breaker.state = 'OPEN';
    console.warn(`[CircuitBreaker] ⚠️  ${providerName} circuit OPENED after ${breaker.failures} failures`);
    
    // Auto-recovery timer
    setTimeout(() => {
      if (breaker.state === 'OPEN') {
        breaker.state = 'HALF_OPEN';
        breaker.failures = 0;
        console.log(`[CircuitBreaker] ${providerName} circuit HALF_OPEN (testing recovery)`);
      }
    }, breaker.resetTimeout);
  }
}

function isCircuitOpen(providerName) {
  const breaker = CIRCUIT_BREAKERS[providerName];
  if (!breaker) return false;
  
  if (breaker.state === 'OPEN') {
    const elapsed = Date.now() - breaker.lastFailure;
    if (elapsed > breaker.resetTimeout) {
      breaker.state = 'HALF_OPEN';
      breaker.failures = 0;
      console.log(`[CircuitBreaker] ${providerName} circuit HALF_OPEN (auto-recovery)`);
      return false;
    }
    return true;
  }
  
  return false;
}

module.exports = {
  CIRCUIT_BREAKERS,
  CIRCUIT_FAILURE_THRESHOLD,
  HALF_OPEN_SUCCESS_THRESHOLD,
  recordProviderSuccess,
  recordProviderFailure,
  isCircuitOpen
};
