/**
 * src/resilience/retry_engine.js - Smart retry engine with exponential backoff
 * Enforces single-probe half-open lock (INV-10) and retry backoffs
 * Pure CommonJS exportable module
 */

'use strict';

const {
  CIRCUIT_BREAKERS,
  recordProviderSuccess,
  recordProviderFailure
} = require('./circuit_breaker');

const HALF_OPEN_REQUESTS = new Map(); // providerName → requestId
const FALLBACK_TOTAL_TIMEOUT = 180000; // 180s timeout across all tiers

/**
 * Execute operation with retry and circuit breaker synchronization
 * @param {Function} operation - Async function to run
 * @param {string} providerName - Provider key
 * @param {number} maxRetries - Max retry attempts
 * @returns {Promise<any>}
 */
async function executeWithRetry(operation, providerName, maxRetries = 3) {
  const retryableErrors = ['TIMEOUT', 'ECONNRESET', 'ENOTFOUND', 'ETIMEDOUT', 'ECONNREFUSED', 'RATE_LIMIT', '429', '503'];
  let lastError = null;
  
  const breaker = CIRCUIT_BREAKERS[providerName];
  const testId = Math.random().toString(36).slice(2);
  
  // HALF_OPEN race condition protection - only allow one test request (INV-10)
  if (breaker?.state === 'HALF_OPEN') {
    if (HALF_OPEN_REQUESTS.has(providerName)) {
      throw new Error(`Provider ${providerName} already testing in HALF_OPEN state`);
    }
    HALF_OPEN_REQUESTS.set(providerName, testId);
  }

  try {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const result = await operation();
        recordProviderSuccess(providerName);
        return result;
      } catch (err) {
        lastError = err;
        const errorCode = err.code || err.message || err.statusCode || '';
        const errorStr = String(errorCode);
        const isRetryable = retryableErrors.some(code => errorStr.includes(String(code)));
        
        // Enhanced rate limit detection
        const isRateLimit = errorStr.includes('429') || errorStr.includes('RATE_LIMIT') || errorStr.includes('rate limit');

        if (!isRetryable || attempt === maxRetries) {
          recordProviderFailure(providerName);
          throw err;
        }

        // Longer backoff for rate limits
        const baseDelay = isRateLimit ? 2000 : 1000;
        const delay = Math.min(baseDelay * Math.pow(2, attempt - 1), isRateLimit ? 16000 : 8000);
        console.log(`[Retry] ${providerName} attempt ${attempt}/${maxRetries} failed${isRateLimit ? ' (RATE LIMIT)' : ''}, retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    recordProviderFailure(providerName);
    throw lastError;
  } finally {
    // Clean up HALF_OPEN lock
    if (HALF_OPEN_REQUESTS.get(providerName) === testId) {
      HALF_OPEN_REQUESTS.delete(providerName);
    }
  }
}

module.exports = {
  executeWithRetry,
  HALF_OPEN_REQUESTS,
  FALLBACK_TOTAL_TIMEOUT
};
