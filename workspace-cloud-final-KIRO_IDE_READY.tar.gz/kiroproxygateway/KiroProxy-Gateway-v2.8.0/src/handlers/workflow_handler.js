/**
 * src/handlers/workflow_handler.js - Workflow, MCP, TaskAssist & Telemetry Stubs
 * Pure CommonJS exportable module
 */

'use strict';

const { sendAwsResponse } = require('../protocol/smithy_parser');
const { dispatchInference } = require('../providers/dispatcher');

const KIRO_MCP_TOOLS = [
  {
    name: 'fs_write',
    description: 'Write or create a file with complete content',
    inputSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File path to write' },
        text: { type: 'string', description: 'Complete file content' }
      },
      required: ['path', 'text']
    }
  },
  {
    name: 'str_replace',
    description: 'Edit an existing file by replacing exact text',
    inputSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File path to edit' },
        oldStr: { type: 'string', description: 'Exact text to replace' },
        newStr: { type: 'string', description: 'Replacement text' }
      },
      required: ['path', 'oldStr', 'newStr']
    }
  },
  {
    name: 'read_file',
    description: 'Read file content',
    inputSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File path to read' },
        offset: { type: 'number', description: 'Line offset (optional)' },
        limit: { type: 'number', description: 'Line limit (optional)' }
      },
      required: ['path']
    }
  },
  {
    name: 'read_code',
    description: 'Read and analyze code files with AST parsing',
    inputSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File or directory path' },
        selector: { type: 'string', description: 'Symbol name to search (optional)' },
        explanation: { type: 'string', description: 'Why reading this code' }
      },
      required: ['path', 'explanation']
    }
  },
  {
    name: 'list_directory',
    description: 'List files and directories',
    inputSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Directory path' },
        depth: { type: 'number', description: 'Recursion depth (optional)' },
        explanation: { type: 'string', description: 'Why listing directory' }
      },
      required: ['path']
    }
  },
  {
    name: 'grep_search',
    description: 'Search files with regex patterns',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Regex pattern to search' },
        includePattern: { type: 'string', description: 'Glob pattern for files to include' },
        excludePattern: { type: 'string', description: 'Glob pattern for files to exclude' },
        caseSensitive: { type: 'boolean', description: 'Case sensitive search' },
        explanation: { type: 'string', description: 'Why performing search' }
      },
      required: ['query']
    }
  },
  {
    name: 'file_search',
    description: 'Search files by name pattern',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Filename fragment to search' },
        excludePattern: { type: 'string', description: 'Glob pattern to exclude' },
        explanation: { type: 'string', description: 'Why searching files' }
      },
      required: ['query', 'explanation']
    }
  },
  {
    name: 'execute_pwsh',
    description: 'Execute PowerShell commands',
    inputSchema: {
      type: 'object',
      properties: {
        command: { type: 'string', description: 'PowerShell command to execute' },
        cwd: { type: 'string', description: 'Working directory (optional)' },
        timeout: { type: 'number', description: 'Timeout in ms (optional)' }
      },
      required: ['command']
    }
  },
  {
    name: 'invoke_sub_agent',
    description: 'Invoke specialized sub-agents for complex tasks',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Agent name: context-gatherer, general-task-execution, introspect, custom-agent-creator' },
        prompt: { type: 'string', description: 'Task instructions for the agent' },
        explanation: { type: 'string', description: 'Why delegating to sub-agent' },
        contextFiles: { type: 'array', description: 'Optional file references to include' }
      },
      required: ['name', 'prompt', 'explanation']
    }
  },
  {
    name: 'validate_spec_format',
    description: 'Validate Kiro 3-spec format documents',
    inputSchema: {
      type: 'object',
      properties: {
        filePath: { type: 'string', description: 'Path to spec file (requirements.md, design.md, or tasks.md)' }
      },
      required: ['filePath']
    }
  },
  {
    name: 'task_list',
    description: 'List tasks from Kiro tasks.md file',
    inputSchema: {
      type: 'object',
      properties: {
        tasksFilePath: { type: 'string', description: 'Path to tasks.md file' },
        status: { type: 'string', description: 'Filter by status: ready, in_progress, completed (optional)' }
      },
      required: ['tasksFilePath']
    }
  },
  {
    name: 'task_update',
    description: 'Update task status in tasks.md',
    inputSchema: {
      type: 'object',
      properties: {
        tasksFilePath: { type: 'string', description: 'Path to tasks.md file' },
        taskId: { type: 'string', description: 'Task ID to update' },
        status: { type: 'string', description: 'New status: ready, in_progress, completed' }
      },
      required: ['tasksFilePath', 'taskId', 'status']
    }
  },
  {
    name: 'task_get',
    description: 'Get detailed task information',
    inputSchema: {
      type: 'object',
      properties: {
        tasksFilePath: { type: 'string', description: 'Path to tasks.md file' },
        taskId: { type: 'string', description: 'Task ID to inspect' }
      },
      required: ['tasksFilePath', 'taskId']
    }
  },
  {
    name: 'update_session_information',
    description: 'Update session status and description',
    inputSchema: {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Session title (optional)' },
        description: { type: 'string', description: 'Current work description (optional)' },
        status: { type: 'string', description: 'Status: in_progress, waiting_on_user, completed, idle (optional)' }
      }
    }
  },
  {
    name: 'todo_list',
    description: 'Manage task lists within sessions',
    inputSchema: {
      type: 'object',
      properties: {
        command: { type: 'string', description: 'Command: create, complete, add, remove, list' },
        task_list_description: { type: 'string', description: 'Task list description (for create)' },
        tasks: { type: 'array', description: 'Array of tasks (for create)' },
        completed_task_ids: { type: 'array', description: 'IDs of completed tasks (for complete)' },
        context_update: { type: 'string', description: 'Important context (for complete)' }
      },
      required: ['command']
    }
  }
];

async function handleWorkflowRoutes(req, res, urlPath, method, amzTarget, reqId, body = {}) {
  // 1. Workflow run
  if (urlPath.includes('/runtime/workflows/run') || amzTarget.includes('runworkflow')) {
    console.log('[KiroProxy] 🔄 Workflow request received - converting to direct execution mode');
    sendAwsResponse(res, 200, {
      workflowId: 'workflow_proxy_disabled_' + Date.now(),
      status: 'not_supported',
      message: 'Workflows are not available in proxy mode. Using direct execution instead.',
      recommendation: 'The proxy will handle your request directly without workflow orchestration.',
      fallbackMode: 'direct_execution'
    }, reqId);
    return true;
  }

  // 2. Workflow inspect
  if (urlPath.includes('/runtime/workflows/inspect') || amzTarget.includes('inspectworkflow')) {
    sendAwsResponse(res, 404, {
      error: 'WorkflowNotFound',
      message: 'Workflow inspection not supported in proxy mode'
    }, reqId);
    return true;
  }

  // 3. Workflow validate
  if (urlPath.includes('/runtime/workflows/validate') || amzTarget.includes('validateworkflow')) {
    sendAwsResponse(res, 501, {
      error: 'NotImplemented',
      message: 'Workflow validation not supported in proxy mode'
    }, reqId);
    return true;
  }

  // 4. InvokeMCP / InvokeMCPStream
  const isMcp = urlPath.includes('mcp') || amzTarget.includes('invokemcp') || Boolean(body.jsonrpc);
  if (isMcp) {
    sendAwsResponse(res, 200, {
      jsonrpc: '2.0',
      id: body.id || 'tools_list',
      result: { tools: KIRO_MCP_TOOLS }
    }, reqId, { 'Content-Type': 'application/json' });
    return true;
  }

  // 5. CodeWhisperer Task Assist
  if (urlPath.includes('generatetaskassistplan') || amzTarget.includes('generatetaskassistplan')) {
    sendAwsResponse(res, 200, { plan: [] }, reqId);
    return true;
  }

  if (urlPath.includes('createtaskassistconversation') || amzTarget.includes('createtaskassistconversation')) {
    sendAwsResponse(res, 200, {
      conversationId: 'conv_' + Date.now(),
      sessionId: 'sess_' + Date.now()
    }, reqId);
    return true;
  }

  if (urlPath.includes('deletetaskassistconversation') || amzTarget.includes('deletetaskassistconversation')) {
    sendAwsResponse(res, 200, { status: 'ok' }, reqId);
    return true;
  }

  if (urlPath.includes('taskassistcodegeneration') || amzTarget.includes('taskassistcodegeneration')) {
    sendAwsResponse(res, 200, {
      codeGenerationStatus: { status: 'COMPLETE' },
      results: []
    }, reqId);
    return true;
  }

  // 6. OpenAI-compatible /v1/chat/completions
  if (urlPath === '/v1/chat/completions') {
    try {
      if (!body.messages || !Array.isArray(body.messages) || body.messages.length === 0) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: 'messages array is required and must not be empty', type: 'invalid_request_error' } }));
        return true;
      }

      for (const msg of body.messages) {
        if (msg.content === null || msg.content === undefined) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: { message: 'message content cannot be null or undefined', type: 'invalid_request_error' } }));
          return true;
        }
      }

      const apiRes = await dispatchInference(body.messages || [], body.model);
      const text = apiRes?.choices?.[0]?.message?.content || JSON.stringify(apiRes);

      if (body.stream) {
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
          'Access-Control-Allow-Origin': '*'
        });
        const chunk = {
          id: 'chatcmpl-' + Date.now(),
          object: 'chat.completion.chunk',
          model: body.model || 'kilo-auto/small',
          choices: [{
            delta: { content: text },
            index: 0,
            finish_reason: null
          }]
        };
        res.write(`data: ${JSON.stringify(chunk)}\n\n`);
        res.write('data: [DONE]\n\n');
        res.end();
        return true;
      }

      res.writeHead(200, { 'Content-Type': 'application/json', 'Server': 'Amazon.com', 'Date': new Date().toUTCString() });
      res.end(JSON.stringify({
        id: 'kilo-' + Date.now(),
        object: 'chat.completion',
        model: body.model || 'kilo-auto/small',
        choices: [{
          message: { role: 'assistant', content: text },
          finish_reason: 'stop',
          index: 0
        }],
        usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
      }));
    } catch (err) {
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: err.message, type: 'gateway_error' } }));
    }
    return true;
  }

  // 7. Telemetry, Sessions, Spaces, User Data
  if (urlPath.includes('updatesessioninformation') || amzTarget.includes('updatesessioninformation') ||
      urlPath.includes('sendtelemetryevent') || amzTarget.includes('sendtelemetryevent') ||
      urlPath.includes('pushtelemetryevent') || amzTarget.includes('pushtelemetryevent') ||
      urlPath.includes('checkprovidersetup') || amzTarget.includes('checkprovidersetup') ||
      urlPath.includes('loadsession') || amzTarget.includes('loadsession') ||
      urlPath.includes('getsessionstatus') || amzTarget.includes('getsessionstatus') ||
      urlPath.includes('respondtopermission') || amzTarget.includes('respondtopermission')) {
    sendAwsResponse(res, 200, {
      __type: 'com.amazon.kiro.runtimeservice#Success',
      status: 'ok',
      acknowledged: true
    }, reqId);
    return true;
  }

  if (urlPath.includes('getuserdata') || amzTarget.includes('getuserdata')) {
    sendAwsResponse(res, 200, {
      user: {
        userId: 'usr_default',
        name: 'Developer',
        email: 'developer@kiro.local'
      }
    }, reqId);
    return true;
  }

  if (urlPath.includes('space') || amzTarget.includes('space')) {
    sendAwsResponse(res, 200, {
      spaces: [{
        spaceId: 'spc_default',
        name: 'Default Workspace',
        status: 'ACTIVE'
      }]
    }, reqId);
    return true;
  }

  return false;
}

module.exports = {
  handleWorkflowRoutes,
  KIRO_MCP_TOOLS
};
