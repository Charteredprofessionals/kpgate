/**
 * src/handlers/bedrock_handler.js - AWS Bedrock Converse Streaming Handler
 * Handles Converse streaming, tool translation, and stringified input contract (INV-06)
 * Pure CommonJS exportable module
 */

'use strict';

const { createEventStreamFrame } = require('../protocol/eventstream');
const { extractMessagesFromKiroPayload, extractKiroToolsFromPayload, sendAwsError } = require('../protocol/smithy_parser');
const {
  extractToolMetadata,
  extractToolCallsFromResponse,
  stripToolBlocksFromText,
  extractBalancedJson,
  extractToolArguments
} = require('../translators/tool_extractor');
const { FORBIDDEN_TOOLS_IN_PROXY } = require('../translators/tool_translator');
const { dispatchInference } = require('../providers/dispatcher');

async function handleConverseStreaming(req, res, body, reqId) {
  const convId = body.conversationState?.conversationId || body.sessionId || ('sess_' + Date.now());
  const requestedModel = body.conversationState?.currentMessage?.userInputMessage?.modelId || 'global-automode';
  const messages = extractMessagesFromKiroPayload(body, requestedModel);
  const lastMsg = messages[messages.length - 1]?.content || '';

  console.log(`[KiroProxy] Processing prompt for convId=${convId} (${messages.length} msgs, model=${requestedModel})`);

  try {
    const kiroTools = extractKiroToolsFromPayload(body);
    const isNgrokPath = requestedModel.startsWith('ngrok-');

    const filteredKiroTools = kiroTools.filter(rawTool => {
      const { name } = extractToolMetadata(rawTool);
      if (FORBIDDEN_TOOLS_IN_PROXY.includes(name.toLowerCase())) {
        console.warn(`[KiroProxy] ⚠️ Suppressing forbidden workflow tool in proxy mode: ${name}`);
        console.warn(`[KiroProxy] 💡 Proxy mode does not support workflows. Use direct tool execution instead.`);
        return false;
      }
      return true;
    });

    const toolsForDispatch = isNgrokPath
      ? filteredKiroTools
      : filteredKiroTools.map(t => {
          const { name, description, schema } = extractToolMetadata(t);
          return {
            type: 'function',
            function: {
              name,
              description,
              parameters: schema
            }
          };
        });

    console.log(`[KiroProxy] Forwarding ${toolsForDispatch.length} tools to upstream (${requestedModel}, ${isNgrokPath ? 'raw→Canvas' : 'OpenAI format'})`);

    const apiRes = await dispatchInference(messages, requestedModel, toolsForDispatch);

    let responseText = '';
    let toolCalls = [];
    let stopReason = 'END_TURN';

    if (apiRes?._kiro) {
      responseText = apiRes._kiro.text || '';
      toolCalls = apiRes._kiro.toolCalls || [];
      stopReason = apiRes._kiro.stopReason || 'END_TURN';
      console.log(`[KiroProxy] Using translation layer: ${toolCalls.length} tools detected, stopReason=${stopReason}`);
    } else {
      if (typeof apiRes === 'string') {
        responseText = apiRes;
      } else if (apiRes?.choices?.[0]?.message?.content !== undefined && apiRes?.choices?.[0]?.message?.content !== null) {
        responseText = apiRes.choices[0].message.content;
      } else if (apiRes?.raw) {
        try {
          const parsed = JSON.parse(apiRes.raw);
          responseText = parsed.choices?.[0]?.message?.content || '';
        } catch {
          responseText = '';
        }
      } else {
        responseText = apiRes?.choices?.[0]?.message?.content || '';
      }
    }

    if (toolCalls.length === 0 && responseText && responseText.trim().length > 0) {
      const fallbackDetected = extractToolCallsFromResponse(responseText, filteredKiroTools);
      if (fallbackDetected.length > 0) {
        toolCalls = fallbackDetected;
        responseText = stripToolBlocksFromText(responseText);
        stopReason = 'TOOL_USE';
        console.log(`[KiroProxy] 🔄 Safety Fallback: Extracted ${toolCalls.length} tool(s) from response text (${toolCalls.map(t => t.name).join(', ')})`);
      }
    }

    if (!responseText || responseText.trim().length === 0) {
      if (toolCalls.length > 0) {
        console.log('[KiroProxy] Empty text but tool calls present — proceeding with tool emission only.');
      } else {
        console.warn('[KiroProxy] ⚠️  Upstream returned empty completion with no tool calls.');
        responseText = '⚠️ The upstream model returned an empty response. The Canvas bridge may not be running, or the model failed to generate output. Please check the Canvas bridge status and retry.';
      }
    }

    console.log(`[KiroProxy] Response text (${responseText.length} chars): "${responseText.slice(0, 80)}..."`);

    res.writeHead(200, {
      'Content-Type': 'application/vnd.amazon.eventstream',
      'x-amzn-kiro-conversation-id': convId,
      'x-amzn-session-id': convId,
      'x-amzn-requestid': reqId,
      'x-amzn-kiro-profile-arn': 'arn:aws:kiro:us-east-1:123456789012:profile/default',
      'Date': new Date().toUTCString(),
      'Server': 'Amazon.com'
    });

    if (toolCalls.length > 0) {
      console.log(`[KiroProxy] Emitting ${toolCalls.length} pre-extracted tools from translation layer`);

      const streamedLeadingText = Boolean(responseText && responseText.trim().length > 0);
      if (streamedLeadingText) {
        res.write(createEventStreamFrame(
          {
            ':event-type': 'assistantResponseEvent',
            ':content-type': 'application/json',
            ':message-type': 'event'
          },
          JSON.stringify({
            content: responseText,
            modelId: requestedModel
          })
        ));
      }

      let emittedCount = 0;
      for (let i = 0; i < toolCalls.length; i++) {
        const tool = toolCalls[i];
        const toolId = `tooluse_${Date.now()}_${i}_${Math.random().toString(36).slice(2, 8)}`;

        let finalToolName = tool.name;

        if (!finalToolName || typeof finalToolName !== 'string') {
          console.warn(`[KiroProxy] ⚠️ Invalid tool name (${typeof finalToolName}): ${JSON.stringify(tool).slice(0, 100)}`);
          continue;
        }

        let parsed = tool.args || {};

        if (typeof parsed !== 'object' || Array.isArray(parsed)) {
          console.warn(`[KiroProxy] ⚠️ Invalid tool args type (${typeof parsed}) for ${finalToolName}`);
          parsed = {};
        }

        if (finalToolName === 'general-task-execution' || finalToolName === 'context-gatherer') {
          const agentName = finalToolName;
          finalToolName = 'invoke_sub_agent';
          parsed.name = agentName;
          parsed.prompt = parsed.prompt || '';
          parsed.explanation = parsed.explanation || `Delegating ${agentName} task`;
        } else if (finalToolName === 'write_file' || finalToolName === 'write_to_file' || finalToolName === 'create_file') {
          finalToolName = 'fs_write';
        } else if (finalToolName === 'edit_file' || finalToolName === 'modify_file' || finalToolName === 'replace_file_content') {
          finalToolName = (parsed.oldStr || parsed.old_str || parsed.find) ? 'str_replace' : 'fs_write';
        } else if (finalToolName === 'run_command' || finalToolName === 'bash' || finalToolName === 'powershell' || finalToolName === 'terminal') {
          finalToolName = 'execute_pwsh';
        } else if (finalToolName === 'ls' || finalToolName === 'dir' || finalToolName === 'list_dir') {
          finalToolName = 'list_directory';
        } else if (finalToolName === 'cat' || finalToolName === 'type' || finalToolName === 'read' || finalToolName === 'open_file') {
          finalToolName = 'read_file';
        } else if (finalToolName === 'search_files' || finalToolName === 'find_files' || finalToolName === 'find') {
          finalToolName = 'file_search';
        } else if (finalToolName === 'grep' || finalToolName === 'search_code') {
          finalToolName = 'grep_search';
        } else if (finalToolName.includes(':')) {
          finalToolName = finalToolName.split(':').pop();
        }

        if (finalToolName === 'invoke_sub_agent') {
          const agentName = parsed.name || parsed.agent_name || 'general-task-execution';
          parsed = {
            name: agentName,
            prompt: parsed.prompt || '',
            explanation: parsed.explanation || `Delegating ${agentName} task to analyze workspace.`
          };
        } else if (finalToolName === 'fs_write') {
          const targetPath = parsed.path || parsed.file || parsed.filepath || '.';
          const content = parsed.text || parsed.content || parsed.code || '';
          parsed = { path: targetPath, text: content };
        } else if (finalToolName === 'str_replace') {
          parsed.path = parsed.path || parsed.file || parsed.filepath || '.';
          parsed.oldStr = parsed.oldStr || parsed.old_str || parsed.find || '';
          parsed.newStr = parsed.newStr || parsed.new_str || parsed.replace || '';
          if (!parsed.oldStr || typeof parsed.oldStr !== 'string' || parsed.oldStr.trim().length === 0) {
            console.warn('[KiroProxy] ⚠️ Suppressing invalid str_replace with empty oldStr.');
            continue;
          }
        } else if (finalToolName === 'read_file' || finalToolName === 'read_code') {
          finalToolName = 'read_file';
          parsed.path = parsed.path || parsed.file || parsed.filepath || '';
          if (!parsed.explanation) {
            parsed.explanation = `Reading ${parsed.path}`;
          }
        } else if (finalToolName === 'execute_pwsh' || finalToolName === 'execute_bash') {
          finalToolName = 'execute_pwsh';
          parsed.command = parsed.command || parsed.cmd || parsed.script || parsed.code || parsed.CommandLine || parsed.commandLine || parsed.powershell || parsed.pwsh || '';
          if (!parsed.command || typeof parsed.command !== 'string' || parsed.command.trim().length === 0) {
            const codeBlockMatch = responseText && responseText.match(/```(?:powershell|pwsh|bash|sh|cmd)?\r?\n([\s\S]*?)```/i);
            if (codeBlockMatch && codeBlockMatch[1] && codeBlockMatch[1].trim()) {
              parsed.command = codeBlockMatch[1].trim();
              console.log(`[KiroProxy] 🔄 Recovered execute_pwsh command from response code block: ${parsed.command.slice(0, 60)}...`);
            }
          }
          if (!parsed.command || typeof parsed.command !== 'string' || parsed.command.trim().length === 0) {
            console.warn('[KiroProxy] ⚠️ Suppressing execute_pwsh with empty command to prevent IDE validation loop!');
            continue;
          }
        } else if (finalToolName === 'list_directory') {
          const targetPath = parsed.path || parsed.directory || parsed.dir || parsed.folder || parsed.target || '.';
          if (!parsed.path && !parsed.directory && !parsed.dir && !parsed.folder) {
            console.warn('[KiroProxy] ⚠️  list_directory (native) called with missing path - defaulting to "."');
          }
          parsed = { path: targetPath || '.', explanation: `Listing contents of ${targetPath || '.'}` };
        } else if (finalToolName === 'validate_spec_format') {
          const target = parsed.filePath || parsed.path || parsed.file || parsed.filepath || '';
          delete parsed.path;
          delete parsed.file;
          delete parsed.filepath;
          parsed.filePath = target;
        } else if (finalToolName === 'task_list' || finalToolName === 'task_get' || finalToolName === 'task_update') {
          const target = parsed.tasksFilePath || parsed.filePath || parsed.path || parsed.file || '';
          delete parsed.path;
          delete parsed.file;
          delete parsed.filePath;
          parsed.tasksFilePath = target;
        } else if (finalToolName === 'analyze_requirements' || finalToolName === 'verify_requirements') {
          const target = parsed.requirementsFilePath || parsed.filePath || parsed.path || parsed.file || '';
          delete parsed.path;
          delete parsed.file;
          delete parsed.filePath;
          parsed.requirementsFilePath = target;
        } else if (finalToolName === 'grep_search' || finalToolName === 'file_search') {
          parsed.query = parsed.query || parsed.pattern || parsed.search || '';
          if (!parsed.explanation) {
            parsed.explanation = `Searching for ${parsed.query}`;
          }
        }

        const finalInputStr = JSON.stringify(parsed);
        console.log(`[KiroProxy] 🛠️ Emitting Tool ${i + 1}/${toolCalls.length}: ${finalToolName} -> ${finalInputStr.slice(0, 80)}...`);

        const toolFrame = createEventStreamFrame(
          {
            ':event-type': 'toolUseEvent',
            ':content-type': 'application/json',
            ':message-type': 'event'
          },
          JSON.stringify({
            toolUseId: toolId,
            name: finalToolName,
            input: finalInputStr,
            stop: true
          })
        );
        res.write(toolFrame);
        emittedCount++;
      }

      if (emittedCount === 0) {
        console.warn(`[KiroProxy] ⚠️ All tool calls were suppressed or invalid for ${convId}. Falling back to assistant text response.`);
        const fallbackText = (responseText && responseText.trim().length > 0)
          ? responseText
          : "I need more specific details or a valid command to proceed with this action.";

        if (!streamedLeadingText) {
          res.write(createEventStreamFrame(
            {
              ':event-type': 'assistantResponseEvent',
              ':content-type': 'application/json',
              ':message-type': 'event'
            },
            JSON.stringify({
              content: fallbackText,
              modelId: requestedModel
            })
          ));
        }

        const metaFrame = createEventStreamFrame(
          {
            ':event-type': 'metadataEvent',
            ':content-type': 'application/json',
            ':message-type': 'event'
          },
          JSON.stringify({
            tokenUsage: {
              uncachedInputTokens: Math.max(1, Math.ceil(lastMsg.length / 4)),
              outputTokens: Math.max(1, Math.ceil((fallbackText || '').length / 4))
            },
            stopReason: 'END_TURN'
          })
        );
        res.write(metaFrame);
        res.end();
        return;
      }

      const metaFrame = createEventStreamFrame(
        {
          ':event-type': 'metadataEvent',
          ':content-type': 'application/json',
          ':message-type': 'event'
        },
        JSON.stringify({
          tokenUsage: {
            uncachedInputTokens: Math.max(1, Math.ceil(lastMsg.length / 4)),
            outputTokens: Math.max(1, Math.ceil((responseText || '').length / 4))
          },
          stopReason: stopReason || 'TOOL_USE'
        })
      );
      res.write(metaFrame);
      res.end();
      console.log(`[KiroProxy] ${emittedCount} tool call(s) dispatched for ${convId} (stopReason: ${stopReason || 'TOOL_USE'})`);
      return;
    } else {
      let normalizedResponse = responseText.replace(/[\uFF5C\u2502\u00A6]/g, '|');

      let toolMatch = null;
      const prefixRegex = /<[\|\s]*(?:DSML[\|\s]*)?(?:tool_call)?[\|\s]*>*(?:call:|l:|tool:)?\s*([a-zA-Z0-9_\-:\.\/]+)\s*(?=\{)/i;
      const prefixHit = prefixRegex.exec(normalizedResponse);
      if (prefixHit) {
        const openBraceIdx = prefixHit.index + prefixHit[0].length;
        const balanced = extractBalancedJson(normalizedResponse, openBraceIdx);
        if (balanced) {
          toolMatch = [prefixHit[0] + balanced.jsonText, prefixHit[1], balanced.jsonText];
          toolMatch.index = prefixHit.index;
        }
      }

      if (!toolMatch || !toolMatch[1] || toolMatch[1].length < 2) {
        const directPrefixRegex = /(?:```(?:tool_call|json)?\s*)?(?:call:|l:|tool:)?\s*(execute_pwsh|execute_bash|read_file|read_code|fs_write|str_replace|list_directory|grep_search|file_search|invoke_sub_agent|validate_spec_format|task_list|task_update|task_get|write_file|edit_file|run_command)\s*(?=\{)/i;
        const directHit = directPrefixRegex.exec(normalizedResponse);
        if (directHit) {
          const openBraceIdx = directHit.index + directHit[0].length;
          const balanced = extractBalancedJson(normalizedResponse, openBraceIdx);
          if (balanced) {
            toolMatch = [directHit[0] + balanced.jsonText, directHit[1], balanced.jsonText];
            toolMatch.index = directHit.index;
          }
        }
      }

      if (toolMatch) {
        let rawToolName = toolMatch[1].trim();
        const rawArgs = toolMatch[2];
        const leadingText = normalizedResponse.slice(0, toolMatch.index).trim();

        let parsed = extractToolArguments(rawArgs);

        let finalToolName = rawToolName;
        if (rawToolName === 'general-task-execution' || rawToolName === 'context-gatherer') {
          const agentName = rawToolName;
          finalToolName = 'invoke_sub_agent';
          parsed.name = agentName;
        } else if (rawToolName === 'write_file' || rawToolName === 'write_to_file' || rawToolName === 'create_file') {
          finalToolName = 'fs_write';
        } else if (rawToolName === 'edit_file' || rawToolName === 'modify_file' || rawToolName === 'replace_file_content') {
          finalToolName = (parsed.oldStr || parsed.old_str || parsed.find) ? 'str_replace' : 'fs_write';
        } else if (rawToolName === 'run_command' || rawToolName === 'bash' || rawToolName === 'powershell' || rawToolName === 'terminal') {
          finalToolName = 'execute_pwsh';
        } else if (rawToolName === 'ls' || rawToolName === 'dir' || rawToolName === 'list_dir') {
          finalToolName = 'list_directory';
        } else if (rawToolName === 'cat' || rawToolName === 'type' || rawToolName === 'read' || rawToolName === 'open_file') {
          finalToolName = 'read_file';
        } else if (rawToolName === 'search_files' || rawToolName === 'find_files' || rawToolName === 'find') {
          finalToolName = 'file_search';
        } else if (rawToolName === 'grep' || rawToolName === 'search_code') {
          finalToolName = 'grep_search';
        } else if (rawToolName.includes(':')) {
          finalToolName = rawToolName.split(':').pop();
        }

        if (finalToolName === 'invoke_sub_agent') {
          const agentName = parsed.name || parsed.agent_name || 'general-task-execution';
          parsed = {
            name: agentName,
            prompt: parsed.prompt || '',
            explanation: parsed.explanation || `Delegating ${agentName} task to analyze workspace.`
          };
        } else if (finalToolName === 'fs_write') {
          const targetPath = parsed.path || parsed.file || parsed.filepath || '.';
          const content = parsed.text || parsed.content || parsed.code || '';
          delete parsed.file;
          delete parsed.filepath;
          delete parsed.content;
          delete parsed.code;
          parsed.path = targetPath;
          parsed.text = content;
        } else if (finalToolName === 'str_replace') {
          parsed.path = parsed.path || parsed.file || parsed.filepath || '.';
          parsed.oldStr = parsed.oldStr || parsed.old_str || parsed.find || '';
          parsed.newStr = parsed.newStr || parsed.new_str || parsed.replace || '';
        } else if (finalToolName === 'execute_pwsh' || finalToolName === 'execute_bash') {
          finalToolName = 'execute_pwsh';
          parsed.command = parsed.command || parsed.cmd || parsed.script || parsed.code || parsed.CommandLine || parsed.commandLine || parsed.powershell || parsed.pwsh || '';
        } else if (finalToolName === 'list_directory') {
          const targetPath = parsed.path || parsed.directory || parsed.dir || parsed.folder || parsed.target || '.';
          if (!parsed.path && !parsed.directory && !parsed.dir && !parsed.folder) {
            console.warn('[KiroProxy] ⚠️  list_directory (legacy) called with missing path - defaulting to "."');
          }
          delete parsed.directory;
          delete parsed.dir;
          delete parsed.folder;
          delete parsed.target;
          parsed.path = targetPath || '.';
          if (!parsed.explanation) {
            parsed.explanation = `Listing ${parsed.path}`;
          }
        } else if (finalToolName === 'read_file' || finalToolName === 'read_code') {
          let targetPath = parsed.path || parsed.file || parsed.filepath || '';
          if (!targetPath || targetPath === '.') {
            const m = rawArgs.match(/d:[\\\/][^"'\r\n,}]+/i) || rawArgs.match(/['"][^"'\r\n,}]+\.[a-zA-Z0-9]+['"]/);
            if (m) targetPath = m[0].replace(/['"]/g, '');
          }
          delete parsed.directory;
          delete parsed.dir;
          delete parsed.folder;
          delete parsed.file;
          delete parsed.filepath;
          parsed.path = targetPath;
          if (!parsed.explanation) {
            parsed.explanation = `Reading ${parsed.path}`;
          }
        } else if (finalToolName === 'validate_spec_format') {
          const target = parsed.filePath || parsed.path || parsed.file || parsed.filepath || '';
          delete parsed.path;
          delete parsed.file;
          delete parsed.filepath;
          parsed.filePath = target;
        } else if (finalToolName === 'task_list' || finalToolName === 'task_get' || finalToolName === 'task_update') {
          const target = parsed.tasksFilePath || parsed.filePath || parsed.path || parsed.file || '';
          delete parsed.path;
          delete parsed.file;
          delete parsed.filePath;
          parsed.tasksFilePath = target;
        } else if (finalToolName === 'analyze_requirements' || finalToolName === 'verify_requirements') {
          const target = parsed.requirementsFilePath || parsed.filePath || parsed.path || parsed.file || '';
          delete parsed.path;
          delete parsed.file;
          delete parsed.filePath;
          parsed.requirementsFilePath = target;
        } else if (finalToolName === 'grep_search' || finalToolName === 'file_search') {
          parsed.query = parsed.query || parsed.pattern || parsed.search || '';
          if (!parsed.explanation) {
            parsed.explanation = `Searching for ${parsed.query}`;
          }
        }

        if (finalToolName === 'str_replace' && (!parsed.oldStr || parsed.oldStr.trim().length === 0)) {
          console.warn('[KiroProxy] ⚠️ Suppressing invalid str_replace with empty oldStr.');
          const fallbackText = leadingText || "I need the specific code snippet or function to modify. Please tell me which section of the file you would like me to update.";
          res.write(createEventStreamFrame(
            {
              ':event-type': 'assistantResponseEvent',
              ':content-type': 'application/json',
              ':message-type': 'event'
            },
            JSON.stringify({
              content: fallbackText,
              modelId: requestedModel,
              messageId: 'msg_' + Date.now()
            })
          ));
          res.write(createEventStreamFrame(
            {
              ':event-type': 'metadataEvent',
              ':content-type': 'application/json',
              ':message-type': 'event'
            },
            JSON.stringify({
              tokenUsage: {
                uncachedInputTokens: Math.max(1, Math.ceil(lastMsg.length / 4)),
                outputTokens: Math.max(1, Math.ceil(fallbackText.length / 4)),
                totalTokens: Math.max(1, Math.ceil((lastMsg.length + fallbackText.length) / 4))
              },
              stopReason: 'END_TURN'
            })
          ));
          res.end();
          return;
        }

        if (finalToolName === 'execute_pwsh' && (!parsed.command || typeof parsed.command !== 'string' || parsed.command.trim().length === 0)) {
          const codeBlockMatch = responseText && responseText.match(/```(?:powershell|pwsh|bash|sh|cmd)?\r?\n([\s\S]*?)```/i);
          if (codeBlockMatch && codeBlockMatch[1] && codeBlockMatch[1].trim()) {
            parsed.command = codeBlockMatch[1].trim();
            console.log(`[KiroProxy] 🔄 Recovered execute_pwsh command from response code block: ${parsed.command.slice(0, 60)}...`);
          } else {
            console.warn('[KiroProxy] ⚠️ Suppressing invalid execute_pwsh with empty command to prevent IDE validation loop.');
            const fallbackText = leadingText || "I need a valid PowerShell command to execute. Please provide the command or specify the action.";
            res.write(createEventStreamFrame(
              {
                ':event-type': 'assistantResponseEvent',
                ':content-type': 'application/json',
                ':message-type': 'event'
              },
              JSON.stringify({
                content: fallbackText,
                modelId: requestedModel,
                messageId: 'msg_' + Date.now()
              })
            ));
            res.write(createEventStreamFrame(
              {
                ':event-type': 'metadataEvent',
                ':content-type': 'application/json',
                ':message-type': 'event'
              },
              JSON.stringify({
                tokenUsage: {
                  uncachedInputTokens: Math.max(1, Math.ceil(lastMsg.length / 4)),
                  outputTokens: Math.max(1, Math.ceil(fallbackText.length / 4)),
                  totalTokens: Math.max(1, Math.ceil((lastMsg.length + fallbackText.length) / 4))
                },
                stopReason: 'END_TURN'
              })
            ));
            res.end();
            return;
          }
        }

        const finalInputStr = JSON.stringify(parsed);
        console.log(`[KiroProxy] 🛠️ Auto-Dispatching Tool: ${finalToolName} (from ${rawToolName}) -> ${finalInputStr.slice(0, 80)}...`);

        if (leadingText.length > 0) {
          res.write(createEventStreamFrame(
            {
              ':event-type': 'assistantResponseEvent',
              ':content-type': 'application/json',
              ':message-type': 'event'
            },
            JSON.stringify({
              content: leadingText,
              modelId: requestedModel
            })
          ));
        }

        const toolFrame = createEventStreamFrame(
          {
            ':event-type': 'toolUseEvent',
            ':content-type': 'application/json',
            ':message-type': 'event'
          },
          JSON.stringify({
            toolUseId: 'tooluse_' + Date.now(),
            name: finalToolName,
            input: finalInputStr,
            stop: true
          })
        );
        res.write(toolFrame);

        const metaFrame = createEventStreamFrame(
          {
            ':event-type': 'metadataEvent',
            ':content-type': 'application/json',
            ':message-type': 'event'
          },
          JSON.stringify({
            tokenUsage: {
              uncachedInputTokens: Math.max(1, Math.ceil(lastMsg.length / 4)),
              outputTokens: Math.max(1, Math.ceil(responseText.length / 4))
            },
            stopReason: 'TOOL_USE'
          })
        );
        res.write(metaFrame);
        res.end();
        console.log(`[KiroProxy] Tool call dispatched for ${convId}`);
        return;
      }
    }

    let streamIdx = 0;
    while (streamIdx < responseText.length) {
      let nextCut = Math.min(streamIdx + 80, responseText.length);
      if (nextCut < responseText.length) {
        const charCode = responseText.charCodeAt(nextCut - 1);
        if (charCode >= 0xD800 && charCode <= 0xDBFF) {
          nextCut += 1;
        }
      }
      const chunk = responseText.slice(streamIdx, nextCut);
      streamIdx = nextCut;

      const frame = createEventStreamFrame(
        {
          ':event-type': 'assistantResponseEvent',
          ':content-type': 'application/json',
          ':message-type': 'event'
        },
        JSON.stringify({
          content: chunk,
          modelId: requestedModel,
          messageId: 'msg_' + Date.now()
        })
      );
      res.write(frame);
    }

    const metaFrame = createEventStreamFrame(
      {
        ':event-type': 'metadataEvent',
        ':content-type': 'application/json',
        ':message-type': 'event'
      },
      JSON.stringify({
        tokenUsage: {
          uncachedInputTokens: Math.max(1, Math.ceil(lastMsg.length / 4)),
          outputTokens: Math.max(1, Math.ceil(responseText.length / 4)),
          totalTokens: Math.max(1, Math.ceil((lastMsg.length + responseText.length) / 4))
        },
        stopReason: 'END_TURN'
      })
    );
    res.write(metaFrame);
    res.end();
    console.log(`[KiroProxy] Stream complete for ${convId}`);

  } catch (err) {
    console.error('[KiroProxy] Stream error:', err.message);
    if (!res.headersSent) {
      sendAwsError(res, 500, 'InternalServerException', err.message, reqId);
    } else {
      res.end();
    }
  }
}

module.exports = {
  handleConverseStreaming
};
