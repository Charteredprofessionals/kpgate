/**
 * src/handlers/canvas_handler.js - Canvas Bridge HTTP Route Handler
 * Serves /canvas, /poll, /chunk, /done, /cancel
 * MUST PRECEDE AWS CATCH-ALL in router evaluation order!
 * Pure CommonJS exportable module
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { PROXY_PORT } = require('../config/index');
const {
  geminiQueue,
  pendingGeminiRequests,
  cancelledGeminiRequests,
  handleBridgeChunk,
  handleBridgeDone,
  checkPollRateLimit,
  MAX_POLLS_PER_MINUTE
} = require('../providers/canvas_bridge');

function getCanvasDashboardFallbackHtml() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KiroProxy Gateway — Gemini Canvas Bridge</title>
  <style>
    body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif; background: #09090b; color: #fafafa; padding: 30px; margin: 0; font-size: 13px; }
    .card { background: #141417; border: 1px solid #27272a; border-radius: 6px; padding: 24px; max-width: 800px; margin: 40px auto; box-shadow: 0 16px 40px rgba(0,0,0,0.65); }
    h1 { color: #fafafa; font-size: 1.25rem; font-weight: 600; margin-bottom: 8px; }
    p { color: #a1a1aa; font-size: 0.85rem; line-height: 1.6; margin-bottom: 16px; }
    .status-badge { display: inline-flex; align-items: center; gap: 8px; background: #fafafa; color: #09090b; font-family: 'Cascadia Code', Consolas, monospace; font-weight: 600; padding: 3px 10px; border-radius: 4px; font-size: 0.75rem; margin-bottom: 16px; }
    .btn { background: #fafafa; color: #09090b; border: 1px solid #fafafa; padding: 7px 14px; border-radius: 4px; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-block; font-size: 0.82rem; }
    .btn-gemini { background: #09090b; color: #fafafa; border-color: #3f3f46; margin-right: 10px; }
    .code-box { background: #050507; border: 1px solid #27272a; border-radius: 4px; padding: 12px; font-family: 'Cascadia Code', Consolas, monospace; font-size: 0.8rem; color: #fafafa; margin: 16px 0; }
  </style>
</head>
<body>
  <div class="card">
    <div class="status-badge">● Canvas Bridge Ready</div>
    <h1>KiroProxy Gateway — Gemini Canvas Bridge</h1>
    <p>Zero-cost autonomous agent browser session bridge driving <strong>gemini-3-flash-preview</strong> (Fallback Mode).</p>
    <div class="code-box">Target Model: gemini-3-flash-preview | Auto-Auth: Active | Port: ${PROXY_PORT}</div>
    <a href="https://gemini.google.com" target="_blank" class="btn btn-gemini">Open gemini.google.com</a>
    <button class="btn" onclick="alert('Canvas Bridge Active')">START BRIDGE</button>
  </div>
</body>
</html>`;
}

/**
 * Handle Canvas Bridge HTTP routes
 * @returns {Promise<boolean>} true if handled, false if not a canvas route
 */
async function handleCanvasRoutes(req, res, urlPath, method, corsContext, body = {}) {
  const { corsOrigin, allowCredentials, corsAllowHeaders, reqOrigin } = corsContext;

  // 1. /canvas, /canvas-bridge, or / (browser navigation)
  if (method === 'GET' && (urlPath === '/canvas' || urlPath === '/canvas-bridge' || urlPath === '/canvas-dashboard' || (urlPath === '/' && req.headers.accept && req.headers.accept.includes('text/html')))) {
    const candidatePaths = [
      path.join(__dirname, '..', '..', 'scripts', 'canvas_bridge_dashboard.html'),
      path.join(__dirname, '..', '..', 'public', 'canvas_bridge_dashboard.html'),
      path.join(__dirname, 'canvas_bridge_dashboard.html')
    ];
    let dashboardContent = null;
    for (const p of candidatePaths) {
      if (fs.existsSync(p)) {
        try {
          dashboardContent = fs.readFileSync(p, 'utf-8');
          break;
        } catch (_) {}
      }
    }
    if (!dashboardContent) {
      dashboardContent = getCanvasDashboardFallbackHtml();
    }
    const canvasHeaders = {
      'Content-Type': 'text/html; charset=utf-8',
      'Access-Control-Allow-Origin': corsOrigin,
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': corsAllowHeaders,
      'ngrok-skip-browser-warning': '69420'
    };
    if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
      canvasHeaders['Access-Control-Allow-Credentials'] = 'true';
      canvasHeaders['Vary'] = 'Origin';
    }
    res.writeHead(200, canvasHeaders);
    res.end(dashboardContent);
    return true;
  }

  // 2. /dashboard or /bridge or /setup
  if (method === 'GET' && (urlPath === '/dashboard' || urlPath === '/bridge' || urlPath === '/setup')) {
    const candidatePaths = [
      path.join(__dirname, '..', '..', 'scripts', 'bridge_dashboard.html'),
      path.join(__dirname, '..', '..', 'public', 'bridge_dashboard.html')
    ];
    for (const p of candidatePaths) {
      if (fs.existsSync(p)) {
        const dashboardContent = fs.readFileSync(p, 'utf-8');
        const bridgeHeaders = {
          'Content-Type': 'text/html; charset=utf-8',
          'Access-Control-Allow-Origin': corsOrigin,
          'ngrok-skip-browser-warning': '69420'
        };
        if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
          bridgeHeaders['Access-Control-Allow-Credentials'] = 'true';
          bridgeHeaders['Vary'] = 'Origin';
        }
        res.writeHead(200, bridgeHeaders);
        res.end(dashboardContent);
        return true;
      }
    }
  }

  // 3. /gemini_bridge.user.js
  if (method === 'GET' && (urlPath === '/gemini_bridge.user.js' || urlPath === '/kiro_gemini_bridge.user.js')) {
    const candidatePaths = [
      path.join(__dirname, '..', '..', 'scripts', 'kiro_gemini_bridge.user.js'),
      path.join(__dirname, '..', '..', 'public', 'kiro_gemini_bridge.user.js')
    ];
    for (const p of candidatePaths) {
      if (fs.existsSync(p)) {
        const userscriptContent = fs.readFileSync(p, 'utf-8');
        const scriptHeaders = {
          'Content-Type': 'application/javascript',
          'Access-Control-Allow-Origin': corsOrigin,
          'ngrok-skip-browser-warning': '69420'
        };
        if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
          scriptHeaders['Access-Control-Allow-Credentials'] = 'true';
          scriptHeaders['Vary'] = 'Origin';
        }
        res.writeHead(200, scriptHeaders);
        res.end(userscriptContent);
        return true;
      }
    }
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Userscript file not found');
    return true;
  }

  // 4. /poll - Userscript polls for next request
  if ((method === 'GET' || method === 'OPTIONS') && (urlPath === '/poll' || urlPath === '/v1/poll' || urlPath.includes('/poll'))) {
    if (method === 'OPTIONS') {
      const pollPreflightHeaders = {
        'Access-Control-Allow-Origin': corsOrigin,
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': corsAllowHeaders,
        'Access-Control-Max-Age': '86400',
        'ngrok-skip-browser-warning': '69420',
        'Content-Length': '0'
      };
      if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
        pollPreflightHeaders['Access-Control-Allow-Credentials'] = 'true';
        pollPreflightHeaders['Vary'] = 'Origin';
      }
      res.writeHead(200, pollPreflightHeaders);
      res.end();
      return true;
    }

    const clientIP = req.socket.remoteAddress || 'unknown';
    if (!checkPollRateLimit(clientIP)) {
      const pollRateLimitHeaders = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': corsOrigin,
        'ngrok-skip-browser-warning': '69420'
      };
      if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
        pollRateLimitHeaders['Access-Control-Allow-Credentials'] = 'true';
        pollRateLimitHeaders['Vary'] = 'Origin';
      }
      res.writeHead(429, pollRateLimitHeaders);
      res.end(JSON.stringify({
        error: 'Rate limit exceeded',
        limit: MAX_POLLS_PER_MINUTE,
        window: '60 seconds'
      }));
      return true;
    }

    const now = Date.now();
    const pendingCancellations = [...cancelledGeminiRequests];
    cancelledGeminiRequests.clear();

    const LONG_POLL_MS = 5000;
    const LONG_POLL_TICK_MS = 50;
    const deadline = Date.now() + LONG_POLL_MS;
    let next = geminiQueue.shift();

    if (!next) {
      await new Promise(resolve => {
        const tick = () => {
          next = geminiQueue.shift();
          if (next || Date.now() >= deadline) {
            resolve();
          } else {
            setTimeout(tick, LONG_POLL_TICK_MS);
          }
        };
        setTimeout(tick, LONG_POLL_TICK_MS);
      });
    }

    const pollResponseHeaders = {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': corsOrigin,
      'ngrok-skip-browser-warning': '69420'
    };
    if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
      pollResponseHeaders['Access-Control-Allow-Credentials'] = 'true';
      pollResponseHeaders['Vary'] = 'Origin';
    }
    res.writeHead(200, pollResponseHeaders);

    if (next) {
      const CANVAS_MODEL = 'gemini-3-flash-preview';
      const canvasPayload = {
        ...next,
        payload: {
          ...next.payload,
          model: CANVAS_MODEL
        }
      };

      const responsePayload = {
        ...canvasPayload,
        _meta: {
          serverTime: now,
          queueDepth: geminiQueue.length,
          cancel: pendingCancellations.length > 0 ? pendingCancellations : undefined
        }
      };
      return res.end(JSON.stringify(responsePayload));
    }

    return res.end(JSON.stringify({
      id: null,
      _meta: {
        serverTime: now,
        queueDepth: 0,
        cancel: pendingCancellations.length > 0 ? pendingCancellations : undefined
      }
    }));
  }

  // 5. /chunk - Userscript sends streaming text chunks
  if (method === 'POST' && (urlPath === '/chunk' || urlPath === '/v1/chunk')) {
    if (body.id && body.text) {
      handleBridgeChunk(body.id, body.text);
    }
    const chunkHeaders = {
      'Content-Type': 'text/plain',
      'Access-Control-Allow-Origin': corsOrigin,
      'ngrok-skip-browser-warning': '69420'
    };
    if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
      chunkHeaders['Access-Control-Allow-Credentials'] = 'true';
      chunkHeaders['Vary'] = 'Origin';
    }
    res.writeHead(200, chunkHeaders);
    res.end('ok');
    return true;
  }

  // 6. /done - Userscript signals completion
  if (method === 'POST' && (urlPath === '/done' || urlPath === '/v1/done')) {
    if (body.id) {
      const entry = pendingGeminiRequests.get(body.id);
      if (entry && body.text) {
        entry.buffer = body.text;
      }
      handleBridgeDone(body.id, body.functionCalls || [], body.error || null);
    }
    const doneHeaders = {
      'Content-Type': 'text/plain',
      'Access-Control-Allow-Origin': corsOrigin,
      'ngrok-skip-browser-warning': '69420'
    };
    if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
      doneHeaders['Access-Control-Allow-Credentials'] = 'true';
      doneHeaders['Vary'] = 'Origin';
    }
    res.writeHead(200, doneHeaders);
    res.end('ok');
    return true;
  }

  // 7. /cancel - Cancel a pending request
  if (method === 'POST' && (urlPath === '/cancel' || urlPath === '/v1/cancel')) {
    const cancelReqId = body.id;
    if (cancelReqId) {
      const idx = geminiQueue.findIndex(q => q.id === cancelReqId);
      if (idx !== -1) {
        geminiQueue.splice(idx, 1);
        console.log(`[BridgeCancel] Removed ${cancelReqId} from queue`);
      }
      cancelledGeminiRequests.add(cancelReqId);

      const entry = pendingGeminiRequests.get(cancelReqId);
      if (entry && entry.res && !entry.res.headersSent) {
        if (entry.isStream) {
          entry.res.write('data: [DONE]\n\n');
          entry.res.end();
        } else {
          entry.res.writeHead(499, { 'Content-Type': 'application/json' });
          entry.res.end(JSON.stringify({ error: { message: 'Client cancelled' } }));
        }
        pendingGeminiRequests.delete(cancelReqId);
      }
    }
    const cancelHeaders = {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': corsOrigin,
      'ngrok-skip-browser-warning': '69420'
    };
    if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
      cancelHeaders['Access-Control-Allow-Credentials'] = 'true';
      cancelHeaders['Vary'] = 'Origin';
    }
    res.writeHead(200, cancelHeaders);
    res.end(JSON.stringify({ success: true, cancelled: cancelReqId || null }));
    return true;
  }

  return false;
}

module.exports = {
  handleCanvasRoutes,
  getCanvasDashboardFallbackHtml
};
