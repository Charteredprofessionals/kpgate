/**
 * src/config/validators.js - Input validation and schema enforcement
 * Pure CommonJS exportable module
 */

'use strict';

class ValidationError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = 'ValidationError';
    this.code = 'VALIDATION_ERROR';
    this.details = details;
  }
}

/**
 * Validates tool call arguments against schema
 * @param {string} toolName - Name of the tool being called
 * @param {object} args - Arguments provided
 * @param {object} schema - JSON schema for the tool
 * @throws {ValidationError} If validation fails
 */
function validateToolCall(toolName, args, schema) {
  if (!schema) {
    throw new ValidationError(
      `No schema available for tool: ${toolName}`,
      { tool: toolName }
    );
  }

  // Check required parameters
  const required = schema.required || [];
  const missing = [];
  
  for (const field of required) {
    if (!(field in args) || args[field] === null || args[field] === undefined) {
      missing.push(field);
    }
  }
  
  if (missing.length > 0) {
    throw new ValidationError(
      `Tool ${toolName} missing required parameter(s): ${missing.join(', ')}`,
      { 
        tool: toolName, 
        missing,
        provided: Object.keys(args),
        required
      }
    );
  }

  // Validate parameter types
  const properties = schema.properties || {};
  const typeErrors = [];

  for (const [key, value] of Object.entries(args)) {
    const propSchema = properties[key];
    if (!propSchema) continue; // Unknown param, will be handled separately

    const actualType = getActualType(value);
    const expectedTypes = Array.isArray(propSchema.type) ? propSchema.type : [propSchema.type];
    
    if (!expectedTypes.includes(actualType) && !expectedTypes.includes('null')) {
      typeErrors.push({
        param: key,
        expected: expectedTypes.join(' or '),
        actual: actualType,
        value: sanitizeValue(value)
      });
    }
  }

  if (typeErrors.length > 0) {
    throw new ValidationError(
      `Tool ${toolName} has type validation errors`,
      { tool: toolName, typeErrors }
    );
  }

  return true;
}

/**
 * Validates API key format and structure
 * @param {string} apiKey - API key to validate
 * @param {string} provider - Provider name for context
 * @returns {boolean} True if valid
 * @throws {ValidationError} If invalid
 */
function validateApiKey(apiKey, provider) {
  if (!apiKey || typeof apiKey !== 'string') {
    throw new ValidationError(
      `Invalid API key for ${provider}: must be a non-empty string`,
      { provider, type: typeof apiKey }
    );
  }

  if (apiKey.trim().length === 0) {
    throw new ValidationError(
      `Invalid API key for ${provider}: empty or whitespace only`,
      { provider }
    );
  }

  // Check for placeholder values
  const placeholders = ['your_key_here', 'xxx', 'token', 'secret', 'key'];
  if (placeholders.some(p => apiKey.toLowerCase().includes(p))) {
    throw new ValidationError(
      `Invalid API key for ${provider}: appears to be a placeholder`,
      { provider, key: sanitizeValue(apiKey) }
    );
  }

  return true;
}

/**
 * Validates request body structure for GenerateAssistantResponse
 * @param {object} body - Request body
 * @throws {ValidationError} If invalid
 */
function validateChatRequest(body) {
  const errors = [];

  // Required fields
  if (!body.modelId || typeof body.modelId !== 'string') {
    errors.push('modelId is required and must be a string');
  }

  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    errors.push('messages is required and must be a non-empty array');
  }

  // Validate message structure
  if (Array.isArray(body.messages)) {
    body.messages.forEach((msg, idx) => {
      if (!msg.role || !['user', 'assistant', 'system'].includes(msg.role)) {
        errors.push(`messages[${idx}].role must be 'user', 'assistant', or 'system'`);
      }
      if (!msg.content || !Array.isArray(msg.content)) {
        errors.push(`messages[${idx}].content must be a non-empty array`);
      }
    });
  }

  // Validate inference config
  if (body.inferenceConfig) {
    const config = body.inferenceConfig;
    
    if (config.maxTokens !== undefined) {
      if (!Number.isInteger(config.maxTokens) || config.maxTokens < 1 || config.maxTokens > 100000) {
        errors.push('inferenceConfig.maxTokens must be an integer between 1 and 100000');
      }
    }

    if (config.temperature !== undefined) {
      if (typeof config.temperature !== 'number' || config.temperature < 0 || config.temperature > 2) {
        errors.push('inferenceConfig.temperature must be a number between 0 and 2');
      }
    }

    if (config.topP !== undefined) {
      if (typeof config.topP !== 'number' || config.topP < 0 || config.topP > 1) {
        errors.push('inferenceConfig.topP must be a number between 0 and 1');
      }
    }
  }

  if (errors.length > 0) {
    throw new ValidationError(
      'Invalid chat request',
      { errors, body: sanitizeBody(body) }
    );
  }

  return true;
}

/**
 * Validates model ID format and availability
 * @param {string} modelId - Model identifier
 * @param {Array} availableModels - List of available models
 * @returns {boolean} True if valid
 */
function validateModelId(modelId, availableModels = []) {
  if (!modelId || typeof modelId !== 'string') {
    throw new ValidationError(
      'Invalid modelId: must be a non-empty string',
      { modelId, type: typeof modelId }
    );
  }

  if (availableModels.length > 0) {
    const exists = availableModels.some(m => m.modelId === modelId);
    if (!exists) {
      throw new ValidationError(
        `Model not found: ${modelId}`,
        { 
          modelId, 
          available: availableModels.slice(0, 10).map(m => m.modelId),
          totalAvailable: availableModels.length
        }
      );
    }
  }

  return true;
}

/**
 * Validates queue configuration
 * @param {object} config - Queue config object
 * @throws {ValidationError} If invalid
 */
function validateQueueConfig(config) {
  const errors = [];

  if (config.maxSize !== undefined) {
    if (!Number.isInteger(config.maxSize) || config.maxSize < 1) {
      errors.push('maxSize must be a positive integer');
    }
  }

  if (config.timeout !== undefined) {
    if (!Number.isInteger(config.timeout) || config.timeout < 1000) {
      errors.push('timeout must be an integer >= 1000ms');
    }
  }

  if (config.priority !== undefined) {
    if (!['high', 'normal', 'low'].includes(config.priority)) {
      errors.push("priority must be 'high', 'normal', or 'low'");
    }
  }

  if (errors.length > 0) {
    throw new ValidationError('Invalid queue configuration', { errors, config });
  }

  return true;
}

// ── Helper Functions ───────────────────────────────────────────────────────────

function getActualType(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'array';
  return typeof value;
}

function sanitizeValue(value) {
  if (typeof value === 'string' && value.length > 50) {
    return value.substring(0, 50) + '...[truncated]';
  }
  if (typeof value === 'string' && /api[_-]?key|token|secret|password/i.test(value)) {
    return '[REDACTED]';
  }
  return value;
}

function sanitizeBody(body) {
  const sanitized = { ...body };
  if (sanitized.apiKey) sanitized.apiKey = '[REDACTED]';
  if (sanitized.token) sanitized.token = '[REDACTED]';
  if (sanitized.messages && sanitized.messages.length > 3) {
    sanitized.messages = [...sanitized.messages.slice(0, 2), '...[truncated]', sanitized.messages[sanitized.messages.length - 1]];
  }
  return sanitized;
}

module.exports = {
  ValidationError,
  validateToolCall,
  validateApiKey,
  validateChatRequest,
  validateModelId,
  validateQueueConfig
};
