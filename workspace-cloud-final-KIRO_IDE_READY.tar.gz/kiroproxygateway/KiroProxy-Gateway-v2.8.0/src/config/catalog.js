/**
 * src/config/catalog.js - Model Catalog Registry & Free Model Auto-Populator
 * Enforces rateMultiplier: 0.0 (INV-01) and model ID prefix matching (INV-02)
 * Pure CommonJS exportable module
 */

'use strict';

const https = require('https');
const http = require('http');
const { URL } = require('url');
const { loadCustomConfig, isKeyValid } = require('./index');

let lastPopulateTime = 0;

// Base Models Registry
const MODELS = {
  models: [
    // ── 0. Global Automode ────────────────────────────────────────
    {
      modelId: 'global-automode',
      modelName: 'Global Automode',
      description: 'Priority: Primary → Kilo free models → Cline free models → OpenRouter free models → OrcaRouter free models → Gemini free models → Custom Providers free models',
      provider: 'kiro-proxy',
      category: 'auto',
      capabilities: ['chat', 'tools'],
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    // ── 1. Kilo Gateway (Zero-Cost Cloud, No Key Needed) ───────────
    {
      modelId: 'kilogateway',
      modelName: 'Kilo Gateway Free (Auto)',
      description: 'Zero-cost cloud AI via Kilo Gateway (Gemma 4 26B) — No API key needed',
      provider: 'kilo',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'kilo-auto/free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'kilo-free',
      modelName: 'Kilo Gateway: Free Model',
      description: 'Free high-speed cloud inference via api.kilo.ai',
      provider: 'kilo',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'kilo-auto/free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 8192
    },
    {
      modelId: 'kilo-auto/small',
      modelName: 'Kilo Gateway: Small (Auto)',
      description: 'Zero-cost auto small model inference via Kilo Gateway (api.kilo.ai)',
      provider: 'kilo',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'kilo-auto/small',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 32768
    },
    {
      modelId: 'kilo-openrouter_free',
      modelName: 'Kilo: OpenRouter Free Models Router',
      description: 'OpenRouter Free Models Router — Free via Kilo Gateway',
      provider: 'kilo',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'openrouter/free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 200000
    },
    {
      modelId: 'kilo-nvidia_nemotron_3_5_lightning_free',
      modelName: 'Kilo: Nemotron 3.5 Lightning Free',
      description: 'NVIDIA Nemotron 3.5 Lightning (Free via Kilo Gateway)',
      provider: 'kilo',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'nvidia/nemotron-3.5-lightning:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'kilo-stepfun_step-3_7-flash_free',
      modelName: 'Kilo: StepFun Step 3.7 Flash Free',
      description: 'StepFun Step 3.7 Flash — Free via Kilo Gateway',
      provider: 'kilo',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'stepfun/step-3.7-flash:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 262144
    },
    {
      modelId: 'kilo-google_gemma_4_26b_a4b_it_free',
      modelName: 'Kilo: Google Gemma 4 26B Free',
      description: 'Google Gemma 4 26B Instruct — Free via Kilo Gateway',
      provider: 'kilo',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'google/gemma-4-26b-a4b-it:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    // ── 2. Cline API Free Models ──────────────────────────────────
    {
      modelId: 'cline-deepseek-v4-flash',
      modelName: 'Cline Free: DeepSeek V4 Flash',
      description: 'Fast and efficient coding model with 1M context (Cline Free)',
      provider: 'cline',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'deepseek/deepseek-v4-flash',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'cline-glm-flash',
      modelName: 'Cline Free: GLM-5.3-Flash',
      description: 'Natively multimodal high-speed agentic model (Cline Free)',
      provider: 'cline',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'z-ai/glm-5.3-flash',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'cline-qwen3-coder-flash',
      modelName: 'Cline Free: Qwen 3 Coder Flash',
      description: 'Alibaba Qwen 3 Coder Flash coding agent model (Cline Free)',
      provider: 'cline',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'qwen/qwen3-coder-flash',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'cline-gemini-2.5-flash',
      modelName: 'Cline Free: Gemini 2.5 Flash',
      description: 'Google Gemini 2.5 Flash via Cline API (Zero Cost)',
      provider: 'cline',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'google/gemini-2.5-flash',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 1000000
    },
    {
      modelId: 'cline-nemotron',
      modelName: 'Cline Free: Nemotron 3.5',
      description: 'NVIDIA Nemotron 3.5 Lightning fast coding model (Cline Free)',
      provider: 'cline',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'nvidia/nemotron-3.5-lightning:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'cline-apodex-1.1-mini',
      modelName: 'Cline Free: Apodex 1.1 Mini',
      description: 'Apodex 1.1 Mini agentic coding model (Cline Free)',
      provider: 'cline',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'apodex/apodex-1.1-mini:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'cline-dots-3-note-preview',
      modelName: 'Cline Free: Dots 3 Note Preview',
      description: 'Dots 3 Note Preview reasoning model (Cline Free)',
      provider: 'cline',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'dots-studio/dots-3-note-preview:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    // ── 3. OpenRouter Free Models ─────────────────────────────────
    {
      modelId: 'openrouter-deepseek',
      modelName: 'OpenRouter: DeepSeek V3',
      description: 'DeepSeek V3 via OpenRouter API',
      provider: 'openrouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'deepseek/deepseek-chat',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'openrouter-claude',
      modelName: 'OpenRouter: Claude 3.7 Sonnet',
      description: 'Claude 3.7 Sonnet via OpenRouter API',
      provider: 'openrouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'anthropic/claude-3.7-sonnet',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 200000
    },
    {
      modelId: 'or-meta_llama_llama_3_3_70b_instruct_free',
      modelName: 'OpenRouter: Meta Llama 3.3 70B (Free)',
      description: 'Meta Llama 3.3 70B Instruct (Free tier on OpenRouter)',
      provider: 'openrouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'meta-llama/llama-3.3-70b-instruct:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'or-deepseek_deepseek_r1_free',
      modelName: 'OpenRouter: DeepSeek R1 (Free)',
      description: 'DeepSeek R1 full reasoning model (Free tier on OpenRouter)',
      provider: 'openrouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'deepseek/deepseek-r1:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'or-qwen_qwen_2_5_coder_32b_instruct_free',
      modelName: 'OpenRouter: Qwen 2.5 Coder 32B (Free)',
      description: 'Qwen 2.5 Coder 32B Instruct (Free tier on OpenRouter)',
      provider: 'openrouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'qwen/qwen-2.5-coder-32b-instruct:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'or-google_gemma_4_26b_a4b_it_free',
      modelName: 'OpenRouter: Gemma 4 26B (Free)',
      description: 'Google Gemma 4 26B Instruct (Free tier on OpenRouter)',
      provider: 'openrouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'google/gemma-4-26b-a4b-it:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'or-nvidia_nemotron_3_5_lightning_free',
      modelName: 'OpenRouter: Nemotron 3.5 Lightning (Free)',
      description: 'NVIDIA Nemotron 3.5 Lightning (Free tier on OpenRouter)',
      provider: 'openrouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'nvidia/nemotron-3.5-lightning:free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    // ── 4. OrcaRouter Free Models ─────────────────────────────────
    {
      modelId: 'orca-orcarouter-free',
      modelName: 'OrcaRouter Free: orcarouter/free',
      description: 'orcarouter/free (Free via OrcaRouter, API key required)',
      provider: 'orcarouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'orcarouter/free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 8192
    },
    {
      modelId: 'orca-deepseek-deepseek-v4-flash-free',
      modelName: 'OrcaRouter Free: DeepSeek V4 Flash',
      description: 'DeepSeek V4 Flash (Free via OrcaRouter, API key required)',
      provider: 'orcarouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'deepseek/deepseek-v4-flash-free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 8192
    },
    {
      modelId: 'orca-tencent-hy3-free',
      modelName: 'OrcaRouter Free: Tencent HY3 Free',
      description: 'Tencent Hunyuan 3 (Free via OrcaRouter, API key required)',
      provider: 'orcarouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'tencent/hy3-free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 8192
    },
    {
      modelId: 'orca-tencent-hy4-preview-free',
      modelName: 'OrcaRouter Free: Tencent HY4 Preview Free',
      description: 'Tencent HY4 preview (Free via OrcaRouter, API key required)',
      provider: 'orcarouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'tencent/hy4-preview-free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 8192
    },
    {
      modelId: 'orca-z-ai-glm-5-3-flash-free',
      modelName: 'OrcaRouter Free: Z.ai GLM 5.3 Flash Free',
      description: 'Z.ai GLM 5.3 Flash (Free via OrcaRouter, API key required)',
      provider: 'orcarouter',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'z-ai/glm-5.3-flash-free',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 8192
    },
    // ── 5. Gemini Models ──────────────────────────────────────────
    {
      modelId: 'ngrok-gemini-flash',
      modelName: 'Ngrok: Gemini 3.1 Flash Preview (Canvas Bridge)',
      description: 'Google Gemini 3.1 Flash Preview via Canvas Bridge — Zero-cost, browser auth',
      provider: 'ngrok',
      category: 'free',
      capabilities: ['chat', 'tools'],
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 1000000
    },
    {
      modelId: 'gemini-2.5-flash',
      modelName: 'Gemini: Gemini 2.5 Flash',
      description: 'Gemini 2.5 Flash via Google Generative AI API',
      provider: 'gemini',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'gemini-2.5-flash',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 1048576
    },
    {
      modelId: 'gemini-2.0-flash',
      modelName: 'Gemini: Gemini 2.0 Flash',
      description: 'Gemini 2.0 Flash via Google Generative AI API',
      provider: 'gemini',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'gemini-2.0-flash',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 1048576
    },
    {
      modelId: 'gemini-1.5-flash',
      modelName: 'Gemini: Gemini 1.5 Flash',
      description: 'Gemini 1.5 Flash via Google Generative AI API',
      provider: 'gemini',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'gemini-1.5-flash',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 1048576
    },
    // ── 6. Custom Models (Groq) ───────────────────────────────────
    {
      modelId: 'custom-groq-qwen_qwen3_8-27b',
      modelName: 'Groq: Qwen 3.8 27B',
      description: 'Qwen/Qwen3.8-27B — ultra-fast via Groq LPU',
      provider: 'custom',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'qwen/qwen3.8-27b',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 131072
    },
    {
      modelId: 'custom-groq-allam-2-7b',
      modelName: 'Groq: ALLaM 2 7B',
      description: 'ALLaM-2-7b — ultra-fast via Groq LPU',
      provider: 'custom',
      category: 'free',
      capabilities: ['chat', 'tools'],
      upstreamSlug: 'allam-2-7b',
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 8192
    },
    // ── Otomode Smart Fallback Models (v2.8.0) ────────────────────
    {
      modelId: 'kilo-otomode',
      modelName: 'Kilo Otomode (Smart Fallback)',
      description: 'Automatic fallback through all Kilo free models (free model 1 → free model 2 → ...)',
      provider: 'kilo',
      category: 'auto',
      capabilities: ['chat', 'tools'],
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'cline-otomode',
      modelName: 'Cline Otomode (Smart Fallback)',
      description: 'Automatic fallback through all Cline free models (free model 1 → free model 2 → ...)',
      provider: 'cline',
      category: 'auto',
      capabilities: ['chat', 'tools'],
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'openrouter-otomode',
      modelName: 'OpenRouter Otomode (Smart Fallback)',
      description: 'Automatic fallback through all OpenRouter free models (free model 1 → free model 2 → ...)',
      provider: 'openrouter',
      category: 'auto',
      capabilities: ['chat', 'tools'],
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'orca-otomode',
      modelName: 'OrcaRouter Otomode (Smart Fallback)',
      description: 'Automatic fallback through all OrcaRouter free models (free model 1 → free model 2 → ...)',
      provider: 'orcarouter',
      category: 'auto',
      capabilities: ['chat', 'tools'],
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'gemini-otomode',
      modelName: 'Gemini Otomode (Smart Fallback)',
      description: 'Automatic fallback through all Gemini free models (free model 1 → free model 2 → ...)',
      provider: 'gemini',
      category: 'auto',
      capabilities: ['chat', 'tools'],
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'custom-otomode',
      modelName: 'Custom Providers Otomode (Smart Fallback)',
      description: 'Automatic fallback through all Custom Provider free models (Groq, GLM, Abhyast-Gemini: free model 1 → free model 2 → ...)',
      provider: 'custom',
      category: 'auto',
      capabilities: ['chat', 'tools'],
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    },
    {
      modelId: 'ngrok-otomode',
      modelName: 'Ngrok Otomode (Smart Fallback)',
      description: 'Automatic fallback through all Ngrok free models (free model 1 → free model 2 → ...)',
      provider: 'ngrok',
      category: 'auto',
      capabilities: ['chat', 'tools'],
      rateMultiplier: 0.0,
      rateUnit: 'credit',
      contextWindow: 128000
    }
  ],
  defaultModel: { modelId: 'global-automode' }
};

/**
 * Build deduplicated fallback list for otomode models
 */
function buildOtomodeFallbackList(providerName, customProviderName = null) {
  const rawName = (providerName || '').toLowerCase();
  const normalizedProvider = rawName === 'orca' ? 'orcarouter' : (rawName.startsWith('custom-') ? 'custom' : rawName);
  const targetCustomSlug = customProviderName
    ? customProviderName.toLowerCase().replace(/[^a-z0-9]+/g, '-')
    : (rawName.startsWith('custom-') && rawName !== 'custom' ? rawName.replace(/^custom-/, '') : null);

  const nonChatPattern = /(?:lyria|content-safety|embedding|imagen|veo|aqa|tts|whisper|moderation)/i;

  const matched = MODELS.models.filter(m => {
    if (!m || m.modelId === 'global-automode' || m.modelId.endsWith('-otomode')) {
      return false;
    }
    if (m.provider !== normalizedProvider) {
      return false;
    }
    if (m.rateMultiplier !== 0.0 && m.category !== 'free') {
      return false;
    }
    const slug = m.upstreamSlug || m.modelId;
    if (!slug || slug === 'kilo-auto/small' || nonChatPattern.test(slug)) {
      return false;
    }
    if (normalizedProvider === 'openrouter' && !slug.endsWith(':free') && slug !== 'openrouter/free') {
      return false;
    }
    if (normalizedProvider === 'custom' && targetCustomSlug) {
      const mCustomSlug = m._customProvider?.name
        ? m._customProvider.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')
        : '';
      const prefix = 'custom-' + targetCustomSlug;
      if (mCustomSlug !== targetCustomSlug && m.modelId !== prefix && !m.modelId.startsWith(prefix + '-')) {
        return false;
      }
    }
    return true;
  });

  if (normalizedProvider === 'cline') {
    matched.sort((a, b) => {
      const aFree = (a.upstreamSlug || '').endsWith(':free') ? 0 : 1;
      const bFree = (b.upstreamSlug || '').endsWith(':free') ? 0 : 1;
      return aFree - bFree;
    });
  }

  const fallbackModels = [...new Set(matched.map(m => m.upstreamSlug || m.modelId))];
  return fallbackModels;
}

function fetchKiloGatewayModels() {
  return new Promise((resolve) => {
    try {
      const req = https.get({
        hostname: 'api.kilo.ai',
        port: 443,
        path: '/api/gateway/models',
        headers: { 'User-Agent': 'Kiro-Integration/2.5' },
        timeout: 10000
      }, (res) => {
        if (res.statusCode !== 200) {
          return resolve();
        }
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          try {
            const j = JSON.parse(data);
            const models = j.data || j.models || [];
            const freeModels = models.filter(m => {
              if (!m.id || m.id === 'kilo-auto/small') return false;
              const isFreeFlag = m.isFree === true;
              const pricingFree = m.pricing && String(m.pricing.prompt) === '0' && String(m.pricing.completion) === '0';
              const idFree = m.id.includes(':free') || m.id.includes('auto/free') || m.id.includes('auto_free') || m.id.includes('free');
              const pricingPaid = m.pricing && String(m.pricing.prompt) === '-1';
              return (isFreeFlag || pricingFree || idFree) && !pricingPaid;
            });

            for (const m of freeModels) {
              const safeId = 'kilo-' + m.id.replace(/[^a-zA-Z0-9_\-]/g, '_');
              if (MODELS.models.some(x => x.modelId === safeId || (x.provider === 'kilo' && x.upstreamSlug === m.id))) continue;
              const ctx = m.top_provider?.context_length || m.context_length || 128000;
              const caps = ['chat'];
              if (m.supported_parameters?.includes('tools')) caps.push('tools');
              if (m.architecture?.input_modalities?.includes('image')) caps.push('vision');
              MODELS.models.push({
                modelId: safeId,
                modelName: 'Kilo: ' + (m.name || m.id),
                description: (m.name || m.id) + ' — Free via Kilo Gateway',
                provider: 'kilo',
                category: 'free',
                capabilities: caps,
                upstreamSlug: m.id,
                rateMultiplier: 0.0,
                rateUnit: 'credit',
                contextWindow: ctx
              });
            }
            resolve();
          } catch {
            resolve();
          }
        });
      });
      req.on('timeout', () => { req.destroy(); resolve(); });
      req.on('error', () => resolve());
      req.end();
    } catch {
      resolve();
    }
  });
}

function fetchClineFreeModels() {
  return new Promise((resolve) => {
    try {
      const req = https.get({
        hostname: 'api.cline.bot',
        port: 443,
        path: '/api/v1/models',
        headers: { 'User-Agent': 'Cline/4.1.17' },
        timeout: 10000
      }, (res) => {
        if (res.statusCode !== 200) {
          const cfg = loadCustomConfig();
          if (isKeyValid(cfg.clineApiKey)) {
            fetchClineModelsWithAuth(cfg.clineApiKey).then(resolve).catch(resolve);
          } else {
            resolve();
          }
          return;
        }
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          try {
            const j = JSON.parse(data);
            const all = j.data || [];
            const free = all.filter(m => {
              if (!m.id) return false;
              const idFree = m.id.includes(':free') || m.id.includes('flash') || m.id.includes('free');
              let pricingFree = false;
              let pricingPaid = false;
              if (m.pricing) {
                const promptZero = String(m.pricing.prompt) === '0';
                const completionZero = String(m.pricing.completion) === '0';
                pricingFree = promptZero && completionZero;
                pricingPaid = String(m.pricing.prompt) === '-1' || String(m.pricing.completion) === '-1';
              }
              return (idFree || pricingFree) && !pricingPaid;
            });
            for (const m of free) {
              const safeId = 'cline-' + m.id.replace(/[^a-zA-Z0-9_\-]/g, '_');
              if (MODELS.models.some(x => x.modelId === safeId || (x.provider === 'cline' && x.upstreamSlug === m.id))) continue;
              MODELS.models.push({
                modelId: safeId,
                modelName: 'Cline Free: ' + (m.name || m.id),
                description: (m.name || m.id) + ' (Free via Cline API)',
                upstreamSlug: m.id,
                provider: 'cline',
                category: 'free',
                capabilities: ['chat', 'tools'],
                rateMultiplier: 0.0,
                rateUnit: 'credit',
                contextWindow: m.context_length || 128000
              });
            }
            resolve();
          } catch {
            resolve();
          }
        });
      });
      req.on('timeout', () => { req.destroy(); resolve(); });
      req.on('error', () => resolve());
      req.end();
    } catch {
      resolve();
    }
  });
}

function fetchClineModelsWithAuth(apiKey) {
  return new Promise((resolve) => {
    try {
      const req = https.get({
        hostname: 'api.cline.bot',
        port: 443,
        path: '/api/v1/models',
        headers: {
          'Authorization': 'Bearer ' + apiKey.trim(),
          'User-Agent': 'Cline/4.1.17'
        },
        timeout: 10000
      }, (res) => {
        if (res.statusCode !== 200) return resolve();
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          try {
            const j = JSON.parse(data);
            const all = j.data || [];
            const free = all.filter(m =>
              m.id && (
                m.id.includes(':free') ||
                m.id.includes('flash') ||
                m.id.includes('lightning') ||
                (m.pricing && (m.pricing.prompt === '0' || m.pricing.prompt === 0))
              )
            );
            for (const m of free) {
              if (!m.id) continue;
              const safeId = 'cline-' + m.id.replace(/[^a-zA-Z0-9_\-]/g, '_');
              if (MODELS.models.some(x => x.modelId === safeId || (x.provider === 'cline' && x.upstreamSlug === m.id))) continue;
              MODELS.models.push({
                modelId: safeId,
                modelName: 'Cline Free: ' + (m.name || m.id),
                description: (m.name || m.id) + ' (Free via Cline API)',
                upstreamSlug: m.id,
                provider: 'cline',
                category: 'free',
                capabilities: ['chat', 'tools'],
                rateMultiplier: 0.0,
                rateUnit: 'credit',
                contextWindow: m.context_length || 128000
              });
            }
            resolve();
          } catch {
            resolve();
          }
        });
      });
      req.on('timeout', () => { req.destroy(); resolve(); });
      req.on('error', () => resolve());
      req.end();
    } catch {
      resolve();
    }
  });
}

function fetchOpenRouterFreeModels() {
  return new Promise((resolve) => {
    try {
      const req = https.get({
        hostname: 'openrouter.ai',
        port: 443,
        path: '/api/v1/models',
        headers: { 'User-Agent': 'Kiro-Integration/2.5' },
        timeout: 10000
      }, (res) => {
        if (res.statusCode !== 200) return resolve();
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          try {
            const j = JSON.parse(data);
            const free = (j.data || []).filter(m => m.id && m.id.endsWith(':free'));
            for (const m of free) {
              const safeId = 'or-' + m.id.replace(/[^a-zA-Z0-9_\-]/g, '_');
              if (MODELS.models.some(x => x.modelId === safeId || (x.provider === 'openrouter' && x.upstreamSlug === m.id))) continue;
              MODELS.models.push({
                modelId: safeId,
                modelName: 'OpenRouter: ' + (m.name || m.id.split('/').pop()),
                description: (m.name || m.id) + ' (Free tier via OpenRouter)',
                upstreamSlug: m.id,
                provider: 'openrouter',
                category: 'free',
                capabilities: ['chat', 'tools'],
                rateMultiplier: 0.0,
                rateUnit: 'credit',
                contextWindow: m.context_length || 128000
              });
            }
            resolve();
          } catch {
            resolve();
          }
        });
      });
      req.on('timeout', () => { req.destroy(); resolve(); });
      req.on('error', () => resolve());
      req.end();
    } catch {
      resolve();
    }
  });
}

function fetchOrcaRouterFreeModels() {
  return new Promise((resolve) => {
    const cfg = loadCustomConfig();
    let apiKey = '';
    if (cfg.providers && cfg.providers.orcarouter && isKeyValid(cfg.providers.orcarouter.apiKey)) {
      apiKey = cfg.providers.orcarouter.apiKey.trim();
    } else if (isKeyValid(cfg.orcarouterApiKey)) {
      apiKey = cfg.orcarouterApiKey.trim();
    }
    if (!apiKey) return resolve();

    try {
      const req = https.request({
        hostname: 'api.orcarouter.ai',
        path: '/v1/models',
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 10000
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            if (res.statusCode !== 200) return resolve();
            const json = JSON.parse(data);
            if (!json.data || !Array.isArray(json.data)) return resolve();
            const allModels = json.data.filter(m => m.id && typeof m.id === 'string');
            const freeModels = allModels.filter(m => {
              const idFree = m.id.toLowerCase().includes('free');
              let pricingFree = false;
              let pricingPaid = false;
              if (m.pricing) {
                const inputZero = String(m.pricing.input) === '0';
                const outputZero = String(m.pricing.output) === '0';
                pricingFree = inputZero && outputZero;
                pricingPaid = String(m.pricing.input) === '-1' || String(m.pricing.output) === '-1';
              }
              return (idFree || pricingFree) && !pricingPaid;
            });

            freeModels.forEach(m => {
              const safeId = m.id.startsWith('orca-') ? m.id : `orca-${m.id.replace(/[^a-zA-Z0-9_\-]/g, '-')}`;
              if (MODELS.models.some(x => x.modelId === safeId || (x.provider === 'orcarouter' && x.upstreamSlug === m.id))) return;
              MODELS.models.push({
                modelId: safeId,
                modelName: 'OrcaRouter Free: ' + (m.name || m.id),
                description: (m.name || m.id) + ' (Free via OrcaRouter, API key required)',
                upstreamSlug: m.id,
                provider: 'orcarouter',
                category: 'free',
                capabilities: ['chat', 'tools'],
                rateMultiplier: 0.0,
                rateUnit: 'credit',
                contextWindow: m.context_length || 8192
              });
            });
            resolve();
          } catch {
            resolve();
          }
        });
      });
      req.on('error', () => resolve());
      req.on('timeout', () => { req.destroy(); resolve(); });
      req.end();
    } catch {
      resolve();
    }
  });
}

function fetchGeminiModels() {
  return new Promise((resolve) => {
    const cfg = loadCustomConfig();
    const apiKeys = cfg.geminiApiKeys || [];
    if (!apiKeys || apiKeys.length === 0) return resolve();

    const currentKey = apiKeys[0];
    if (!currentKey || !isKeyValid(currentKey)) return resolve();

    try {
      const useHeaderAuth = currentKey.startsWith('AQ.');
      const reqOptions = {
        hostname: 'generativelanguage.googleapis.com',
        port: 443,
        path: useHeaderAuth ? '/v1beta/models' : `/v1beta/models?key=${currentKey}`,
        headers: { 'User-Agent': 'Kiro-Integration/2.7.0' },
        timeout: 10000
      };
      if (useHeaderAuth) {
        reqOptions.headers['X-goog-api-key'] = currentKey;
      }
      const req = https.get(reqOptions, (res) => {
        if (res.statusCode !== 200) return resolve();
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          try {
            const j = JSON.parse(data);
            const models = j.models || [];
            for (const m of models) {
              if (!m.name) continue;
              const modelId = m.name.replace('models/', '');
              const safeId = modelId.startsWith('gemini-') 
                ? modelId.replace(/[^a-zA-Z0-9_\-\.]/g, '-')
                : 'gemini-' + modelId.replace(/[^a-zA-Z0-9_\-\.]/g, '-');
              if (MODELS.models.some(x => x.modelId === safeId || (x.provider === 'gemini' && x.upstreamSlug === modelId))) continue;
              if (!m.supportedGenerationMethods?.includes('generateContent')) continue;
              const isChatModel = !modelId.includes('tts') && !modelId.includes('audio') && !modelId.includes('clip') && !modelId.includes('robotics') && !modelId.includes('transcribe');
              if (!isChatModel) continue;

              MODELS.models.push({
                modelId: safeId,
                modelName: 'Gemini: ' + (m.displayName || modelId),
                description: m.description || (m.displayName + ' via Google Generative AI'),
                upstreamSlug: modelId,
                provider: 'gemini',
                category: 'free',
                capabilities: ['chat', 'tools'],
                rateMultiplier: 0.0,
                rateUnit: 'credit',
                contextWindow: m.inputTokenLimit || 32768,
                maxOutputTokens: m.outputTokenLimit || 8192
              });
            }
            resolve();
          } catch {
            resolve();
          }
        });
      });
      req.on('error', () => resolve());
      req.on('timeout', () => { req.destroy(); resolve(); });
      req.end();
    } catch {
      resolve();
    }
  });
}

function _addCustomProviderSingleEntry(p) {
  const safeId = 'custom-' + p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  if (MODELS.models.some(m => m.modelId === safeId)) return;
  MODELS.models.push({
    modelId: safeId,
    modelName: p.name,
    description: `${p.name} via ${p.baseUrl} (custom provider)`,
    provider: 'custom',
    category: 'custom',
    capabilities: ['chat', 'tools'],
    rateMultiplier: 0.0,
    rateUnit: 'credit',
    contextWindow: 128000,
    upstreamSlug: p.defaultModel || safeId,
    _customProvider: p
  });
}

function _discoverCustomProvider(p) {
  return new Promise((resolve) => {
    if (p.autoPopulate === false) {
      _addCustomProviderSingleEntry(p);
      return resolve();
    }
    try {
      const baseUrl = p.baseUrl.replace(/\/$/, '');
      const urlObj = new URL(baseUrl + '/models');
      const isHttps = urlObj.protocol === 'https:';
      const httpModule = isHttps ? https : http;

      const reqOptions = {
        hostname: urlObj.hostname,
        port: urlObj.port || (isHttps ? 443 : 80),
        path: urlObj.pathname + (urlObj.search || ''),
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${p.apiKey}`,
          'User-Agent': 'KiroProxy/2.7.0'
        },
        timeout: 10000
      };

      let settled = false;
      const settle = (fn) => { if (!settled) { settled = true; if (fn) fn(); resolve(); } };
      const freeOnly = p.freeOnly !== false;

      const req = httpModule.request(reqOptions, (res) => {
        let data = '';
        res.on('data', c => { data += c; });
        res.on('end', () => {
          settle(() => {
            if (res.statusCode !== 200) {
              _addCustomProviderSingleEntry(p);
              return;
            }
            try {
              const j = JSON.parse(data);
              const allModels = j.data || j.models || [];
              const eligibleModels = allModels.filter(model => {
                try {
                  if (!model.id) return false;
                  const outMods = model.output_modalities;
                  if (outMods) {
                    const modsArr = Array.isArray(outMods) ? outMods : [outMods];
                    if (modsArr.length > 0 && !modsArr.includes('text')) return false;
                  }
                  if (freeOnly) {
                    const isGroq = p.name.toLowerCase().includes('groq');
                    if (isGroq) return true;
                    if (!model.pricing) return true;
                    const prompt = String(model.pricing.prompt || '0');
                    const completion = String(model.pricing.completion || '0');
                    if (prompt === '-1' || completion === '-1') return false;
                    return prompt === '0' && completion === '0';
                  }
                  return true;
                } catch { return false; }
              });

              const providerPrefix = 'custom-' + p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
              let added = 0;
              for (const model of eligibleModels) {
                try {
                  const safeId = providerPrefix + '-' + model.id.replace(/[^a-zA-Z0-9_\-]/g, '_');
                  if (MODELS.models.some(x => x.modelId === safeId || (x.provider === 'custom' && x.upstreamSlug === model.id && x._customProvider?.name === p.name))) continue;
                  const ctx = model.context_window || model.context_length || 128000;
                  const caps = ['chat'];
                  if ((model.supported_features || []).includes('tools')) caps.push('tools');
                  const inMods = Array.isArray(model.input_modalities) ? model.input_modalities : [];
                  if (inMods.includes('image')) caps.push('vision');
                  MODELS.models.push({
                    modelId: safeId,
                    modelName: `${p.name}: ${model.name || model.id}`,
                    description: `${model.name || model.id} — via ${p.name}`,
                    provider: 'custom',
                    category: freeOnly ? 'free' : 'custom',
                    capabilities: caps,
                    rateMultiplier: 0.0,
                    rateUnit: 'credit',
                    contextWindow: ctx,
                    upstreamSlug: model.id,
                    _customProvider: p
                  });
                  added++;
                } catch {}
              }

              const customSlug = p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
              const otomodeId = `custom-${customSlug}-otomode`;
              if (!MODELS.models.some(m => m.modelId === otomodeId)) {
                MODELS.models.push({
                  modelId: otomodeId,
                  modelName: `${p.name} Otomode (Smart Fallback)`,
                  description: `Automatic fallback through all ${p.name} free models (free model 1 → free model 2 → ...)`,
                  provider: 'custom',
                  category: 'auto',
                  capabilities: ['chat', 'tools'],
                  rateMultiplier: 0.0,
                  rateUnit: 'credit',
                  contextWindow: 128000,
                  _customProvider: p
                });
              }

              if (added === 0) {
                _addCustomProviderSingleEntry(p);
              }
            } catch {
              _addCustomProviderSingleEntry(p);
            }
          });
        });
        res.on('error', () => settle(() => _addCustomProviderSingleEntry(p)));
      });

      req.on('timeout', () => { req.destroy(); settle(() => _addCustomProviderSingleEntry(p)); });
      req.on('error', () => settle(() => _addCustomProviderSingleEntry(p)));
      req.end();
    } catch {
      _addCustomProviderSingleEntry(p);
      resolve();
    }
  });
}

function fetchCustomProviderModels() {
  return new Promise((resolve) => {
    const cfg = loadCustomConfig();
    const providers = cfg.customProviders || [];
    const enabled = providers.filter(p => p.enabled !== false && p.baseUrl && p.apiKey);
    if (enabled.length === 0) return resolve();

    const promises = enabled.map(p => _discoverCustomProvider(p));
    Promise.allSettled(promises).then(() => resolve());
  });
}

async function autoPopulateFreeModels(force = false) {
  const now = Date.now();
  if (!force && now - lastPopulateTime < 900000) return;
  lastPopulateTime = now;

  await Promise.allSettled([
    fetchKiloGatewayModels(),
    fetchClineFreeModels(),
    fetchOpenRouterFreeModels(),
    fetchOrcaRouterFreeModels(),
    fetchGeminiModels(),
    fetchCustomProviderModels()
  ]);
}

module.exports = {
  MODELS,
  buildOtomodeFallbackList,
  autoPopulateFreeModels,
  fetchKiloGatewayModels,
  fetchClineFreeModels,
  fetchClineModelsWithAuth,
  fetchOpenRouterFreeModels,
  fetchOrcaRouterFreeModels,
  fetchGeminiModels,
  fetchCustomProviderModels
};
