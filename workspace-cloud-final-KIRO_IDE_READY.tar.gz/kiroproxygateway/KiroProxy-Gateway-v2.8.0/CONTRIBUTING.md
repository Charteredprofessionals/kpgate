# Contributing to KiroProxy Gateway

Thank you for your interest in contributing to KiroProxy Gateway! This document provides guidelines and instructions for contributing.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Process](#development-process)
- [Pull Request Process](#pull-request-process)
- [Coding Standards](#coding-standards)
- [Testing Requirements](#testing-requirements)

## Code of Conduct

### Our Pledge

We are committed to providing a welcoming and inspiring community for all. We pledge to make participation in our project a harassment-free experience for everyone.

### Our Standards

**Positive Behavior:**
- Using welcoming and inclusive language
- Being respectful of differing viewpoints
- Gracefully accepting constructive criticism
- Focusing on what is best for the community

**Unacceptable Behavior:**
- Harassment, trolling, or derogatory comments
- Publishing others' private information
- Other conduct considered inappropriate in a professional setting

## Getting Started

### Prerequisites

- Node.js 18+ installed
- Git for version control
- Basic understanding of Node.js and Express
- Familiarity with AI API integration

### Setup Development Environment

```bash
# Clone the repository
git clone https://github.com/yourusername/kiro-integration.git
cd kiro-integration

# Install dependencies
npm install

# Copy environment template
copy .env.template .env

# Edit .env with your API keys (optional for testing)
notepad .env

# Start the server
npm start
```

### Project Structure

```
kiro-integration/
├── scripts/              # Core server and utilities
│   ├── kiro_proxy_server.js
│   ├── batch/           # CLI scripts
│   └── utils/           # Helper utilities
├── tests/               # Test suites
├── docs/                # Documentation
├── public/              # Web UI
└── config/              # Configuration files
```

## Development Process

### SDLC Workflow

This project follows a structured Software Development Lifecycle:

#### 1. Plan
- Define feature or bug scope
- Check existing docs in `docs/`
- Review `scripts/kiro_proxy_server.js` for affected areas

#### 2. Implement
- Edit `scripts/kiro_proxy_server.js` for server changes
- Edit `public/config.html` for GUI changes
- Edit `scripts/batch/*.bat` for CLI changes
- Keep version comment at top of server file in sync

#### 3. Test
```bash
# Run full test suite
npm test

# Run specific test suites
npm run test:full
npm run test:edge
npm run test:scenarios
npm run test:kilo
```

#### 4. Verify
- All tests must pass (100%)
- `rateMultiplier: 0.0` on every model (FREE models only)
- `/config` GUI loads and saves correctly
- All providers healthy in `/health`

#### 5. Document
- Update `README.md` for user-facing changes
- Update `docs/` for technical changes
- Update changelog section in README

### Version Bumping

When bumping version (e.g. v2.7.0 → v2.8.0):

- [ ] `package.json` → `"version"`
- [ ] `scripts/kiro_proxy_server.js` → header comment + version string in startup banner
- [ ] `README.md` → version badge + changelog section
- [ ] `scripts/batch/*.bat` → version in header comments

## Pull Request Process

### Before Submitting

1. **Test Your Changes**
   ```bash
   npm run test:all
   ```

2. **Update Documentation**
   - Add/update relevant docs in `docs/`
   - Update README if user-facing changes

3. **Follow Coding Standards**
   - See [Coding Standards](#coding-standards) section

4. **Commit Message Format**
   ```
   type(scope): short description
   
   Longer description if needed.
   
   Fixes #123
   ```
   
   Types: `feat`, `fix`, `docs`, `test`, `refactor`, `chore`

### Submission Steps

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature-name`
3. Make your changes
4. Commit with clear messages
5. Push to your fork
6. Open a Pull Request

### PR Requirements

- ✅ All tests passing
- ✅ No breaking changes (or clearly documented)
- ✅ Documentation updated
- ✅ Code follows project standards
- ✅ Free-model-only policy maintained

### PR Review Process

1. Automated CI tests run
2. Code review by maintainers
3. Address review feedback
4. Approval and merge

## Coding Standards

### JavaScript Style

- **Indentation:** 2 spaces
- **Semicolons:** Required
- **Quotes:** Single quotes for strings
- **Naming:**
  - `camelCase` for variables and functions
  - `PascalCase` for classes
  - `UPPER_CASE` for constants

### Code Quality

```javascript
// Good: Clear, documented, error-handled
async function fetchProviderModels(provider, apiKey) {
  try {
    const response = await makeRequest({
      url: provider.baseUrl,
      headers: { 'Authorization': `Bearer ${apiKey}` }
    });
    
    return response.models.filter(m => m.pricing.free);
  } catch (error) {
    console.error(`[${provider.name}] Model fetch failed:`, error.message);
    return [];
  }
}

// Bad: No error handling, unclear naming
function f(p, k) {
  return makeRequest(p.url, k).models.filter(m => !m.pricing.amount);
}
```

### Error Handling

- Always use try-catch for async operations
- Log errors with context
- Return graceful fallbacks
- Never expose sensitive data in errors

### Comments

```javascript
// Single-line comments for brief explanations
const timeout = 30000; // 30 seconds

/**
 * Multi-line JSDoc for functions
 * 
 * @param {string} modelId - The model identifier
 * @param {Array} tools - Tool definitions
 * @returns {Promise<Object>} - The inference response
 */
async function generateResponse(modelId, tools) {
  // Implementation
}
```

## Testing Requirements

### Test Coverage

All new features must include tests:

- **Unit Tests:** Test individual functions
- **Integration Tests:** Test API endpoints
- **E2E Tests:** Test full workflows

### Running Tests

```bash
# All tests
npm run test:all

# Specific suites
npm test                # Core gateway tests
npm run test:scenarios  # Real-world scenarios
npm run test:kilo       # Kilo & custom providers
npm run test:edge       # Edge cases
```

### Writing Tests

```javascript
// tests/test_new_feature.js
const http = require('http');

async function testNewFeature() {
  const response = await makeRequest({
    hostname: '127.0.0.1',
    port: 8084,
    path: '/new-endpoint',
    method: 'POST'
  }, { test: 'data' });

  if (response.statusCode !== 200) {
    throw new Error(`Expected 200, got ${response.statusCode}`);
  }
  
  console.log('✅ New feature test passed');
}
```

### Test Standards

- Tests must be deterministic (no flakiness)
- Mock external API calls when possible
- Clean up resources after tests
- Use descriptive test names

## Free Models Policy

**CRITICAL:** This gateway provides FREE AI model access only.

### Requirements

1. All models must have `rateMultiplier: 0.0`
2. No paid models in catalog
3. Verify pricing in provider responses
4. Test suite checks for paid models

### Adding New Providers

When adding a new provider:

```javascript
// 1. Filter for free models only
const freeModels = allModels.filter(m => 
  m.pricing.free || 
  m.cost === 0 || 
  m.rateMultiplier === 0
);

// 2. Add rateMultiplier field
freeModels.forEach(m => {
  m.rateMultiplier = 0.0;  // FREE models only!
});

// 3. Test the provider
npm run test:kilo
```

## Security Guidelines

### API Keys

- Never commit API keys
- Use `.env` for local keys
- Document required keys in `.env.template`
- Add `.env` to `.gitignore`

### Input Validation

- Validate all user inputs
- Sanitize before processing
- Limit request sizes
- Use rate limiting

### Dependencies

- Keep dependencies updated
- Review security advisories
- Use `npm audit` regularly

## Documentation

### Types of Documentation

1. **Code Comments:** Inline explanations
2. **API Docs:** Endpoint specifications (`docs/api/`)
3. **Guides:** How-to documents (`docs/guides/`)
4. **Architecture:** System design (`docs/architecture/`)

### Documentation Standards

- Clear, concise writing
- Code examples for complex topics
- Keep docs in sync with code
- Include troubleshooting sections

## Community

### Getting Help

- **Issues:** Bug reports and feature requests
- **Discussions:** General questions and ideas
- **Discord:** Real-time community chat (if available)

### Reporting Bugs

Use the issue template:

```markdown
**Bug Description:**
Clear description of the bug

**To Reproduce:**
1. Step 1
2. Step 2
3. See error

**Expected Behavior:**
What should happen

**Environment:**
- OS: Windows 11
- Node.js: v18.0.0
- Gateway Version: 2.7.0

**Logs:**
Relevant error logs
```

### Suggesting Features

Use the feature request template:

```markdown
**Feature Description:**
What you want to add

**Use Case:**
Why this is useful

**Proposed Solution:**
How it could work

**Alternatives:**
Other approaches considered
```

## Recognition

Contributors will be recognized in:
- `CONTRIBUTORS.md` file
- Release notes
- Project README

## Questions?

Feel free to:
- Open a discussion
- Ask in issues
- Contact maintainers

---

**Thank you for contributing to KiroProxy Gateway!** 🚀
