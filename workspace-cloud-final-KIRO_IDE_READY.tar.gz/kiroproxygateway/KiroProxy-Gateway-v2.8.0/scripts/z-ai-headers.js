#!/usr/bin/env node
/**
 * z-ai-headers.js — refresh-friendly header bridge for the KiroProxy custom
 * provider "zai-backend".
 *
 * The platform refreshes /etc/.z-ai-config with a fresh JWT/chatId/userId on
 * every new chat session. The custom.js provider supports `headers: '/path'`
 * (a JSON file read fresh per request) — but /etc/.z-ai-config has a flat
 * shape (baseUrl/apiKey/token/chatId/userId), not the {headers:{...}} shape
 * custom.js expects.
 *
 * This script watches /etc/.z-ai-config and writes a derived file at
 * /tmp/zai-headers.json in the shape custom.js consumes, mapping the flat
 * fields to the four headers the z-ai backend requires:
 *   X-Z-AI-From: Z
 *   X-Chat-Id:   <chatId>
 *   X-User-Id:   <userId>
 *   X-Token:     <token>
 *
 * The apiKey stays in the provider config (Bearer <apiKey>) since that maps
 * directly to the standard Authorization header custom.js already sends.
 */

'use strict';

const fs = require('fs');
const path = require('path');

const SRC = '/etc/.z-ai-config';
const OUT = '/tmp/zai-headers.json';

function buildHeaders() {
  try {
    if (!fs.existsSync(SRC)) return null;
    const raw = fs.readFileSync(SRC, 'utf-8').replace(/^\uFEFF/, '').trim();
    if (!raw) return null;
    const cfg = JSON.parse(raw);
    const headers = {};
    if (cfg.token)   headers['X-Token']     = String(cfg.token);
    if (cfg.chatId)  headers['X-Chat-Id']   = String(cfg.chatId);
    if (cfg.userId)  headers['X-User-Id']   = String(cfg.userId);
    headers['X-Z-AI-From'] = 'Z';
    return headers;
  } catch (err) {
    console.error('[z-ai-headers] failed to read', SRC, ':', err.message);
    return null;
  }
}

function writeOut() {
  const headers = buildHeaders();
  if (!headers) return;
  try {
    fs.writeFileSync(OUT, JSON.stringify({ headers }, null, 2));
    console.log('[z-ai-headers] refreshed', OUT, '→', Object.keys(headers).join(','));
  } catch (err) {
    console.error('[z-ai-headers] failed to write', OUT, ':', err.message);
  }
}

// Initial write
writeOut();

// Re-build on file change (mTime poll — works across container filesystems
// where inotify may not fire)
let lastMtime = 0;
try { lastMtime = fs.statSync(SRC).mtimeMs; } catch (_) {}

setInterval(() => {
  try {
    const st = fs.statSync(SRC);
    if (st.mtimeMs !== lastMtime) {
      lastMtime = st.mtimeMs;
      writeOut();
    }
  } catch (_) {}
}, 5000).unref();

// Keep the process alive but unref'd so it doesn't block shutdown
console.log('[z-ai-headers] bridge running — watching', SRC, 'for changes');
