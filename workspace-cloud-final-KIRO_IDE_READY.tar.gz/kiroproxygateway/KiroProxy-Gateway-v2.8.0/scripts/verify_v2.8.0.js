#!/usr/bin/env node
/**
 * KiroProxy Gateway v2.8.0 Verification Script
 * Tests dual-layer smart fallback implementation
 */

const http = require('http');

console.log('═══════════════════════════════════════════════════════');
console.log('  KiroProxy Gateway v2.8.0 Verification');
console.log('═══════════════════════════════════════════════════════\n');

const baseUrl = 'http://localhost:8084';

async function makeRequest(endpoint, options = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request(`${baseUrl}${endpoint}`, {
      method: options.method || 'GET',
      headers: options.headers || {},
      timeout: 5000
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: data ? JSON.parse(data) : null });
        } catch {
          resolve({ status: res.statusCode, data: data });
        }
      });
    });
    
    req.on('error', reject);
    req.on('timeout', () => reject(new Error('Timeout')));
    
    if (options.body) {
      req.write(JSON.stringify(options.body));
    }
    req.end();
  });
}

async function runTests() {
  const results = { passed: 0, failed: 0, tests: [] };
  
  const test = (name, condition, message) => {
    if (condition) {
      console.log(`✅ ${name}`);
      results.passed++;
    } else {
      console.log(`❌ ${name}: ${message || 'Failed'}`);
      results.failed++;
    }
    results.tests.push({ name, passed: condition, message });
  };

  try {
    // Test 1: Server is running
    console.log('[1/6] Checking server health...');
    try {
      const health = await makeRequest('/health');
      test('Server is running', health.status === 200, `Status: ${health.status}`);
    } catch (err) {
      test('Server is running', false, `Server not reachable: ${err.message}`);
      console.log('\n⚠️  Start the server first: npm start\n');
      return results;
    }

    // Test 2: Check model count
    console.log('[2/6] Checking model catalog...');
    const models = await makeRequest('/v1/models');
    const modelCount = models.data?.data?.length || 0;
    test('Model count is 182 or more', modelCount >= 182, `Found ${modelCount} models`);

    // Test 3: Verify otomode models exist
    console.log('[3/6] Verifying otomode models...');
    const otomodeModels = models.data?.data?.filter(m => m.id.endsWith('-otomode')) || [];
    const expectedOtomode = ['kilo-otomode', 'cline-otomode', 'openrouter-otomode', 'orca-otomode', 'gemini-otomode', 'ngrok-otomode'];
    const foundOtomode = otomodeModels.map(m => m.id);
    const allPresent = expectedOtomode.every(id => foundOtomode.includes(id));
    test('All 6 otomode models present', allPresent, `Found: ${foundOtomode.join(', ')}`);

    // Test 4: Verify otomode models are free
    console.log('[4/6] Verifying otomode models are free...');
    const allFree = otomodeModels.every(m => {
      const pricing = m.pricing?.find(p => p.unit === 'credit');
      return pricing && pricing.inputCostPer1M === 0 && pricing.outputCostPer1M === 0;
    });
    test('All otomode models are free', allFree, 'Some models have non-zero pricing');

    // Test 5: Test otomode routing (kilo-otomode)
    console.log('[5/6] Testing otomode routing...');
    try {
      const chat = await makeRequest('/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: {
          model: 'kilo-otomode',
          messages: [{ role: 'user', content: 'Say "test"' }],
          max_tokens: 10
        }
      });
      test('kilo-otomode routes correctly', chat.status === 200 || chat.status === 400, `Status: ${chat.status}`);
    } catch (err) {
      test('kilo-otomode routes correctly', false, err.message);
    }

    // Test 6: Verify package.json version
    console.log('[6/6] Checking version...');
    const pkg = require('../package.json');
    test('Version is 2.8.0', pkg.version === '2.8.0', `Version: ${pkg.version}`);

  } catch (err) {
    console.error(`\n❌ Test suite error: ${err.message}`);
    results.failed++;
  }

  // Summary
  console.log('\n═══════════════════════════════════════════════════════');
  console.log('  Summary');
  console.log('═══════════════════════════════════════════════════════');
  console.log(`✅ Passed: ${results.passed}`);
  console.log(`❌ Failed: ${results.failed}`);
  console.log(`📊 Total:  ${results.passed + results.failed}`);
  console.log(`📈 Success: ${Math.round((results.passed / (results.passed + results.failed)) * 100)}%`);
  console.log('═══════════════════════════════════════════════════════\n');

  process.exit(results.failed > 0 ? 1 : 0);
}

runTests().catch(console.error);
