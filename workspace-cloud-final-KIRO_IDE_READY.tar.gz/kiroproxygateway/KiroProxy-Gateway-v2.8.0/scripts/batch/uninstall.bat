@echo off
setlocal EnableDelayedExpansion
:: ============================================================
::  uninstall.bat — KiroProxy Gateway Uninstaller v2.8.0
::  Restores original Kiro IDE extension (removes patches)
:: ============================================================

set "BATCH_DIR=%~dp0"
set "BATCH_DIR=%BATCH_DIR:~0,-1%"
for %%i in ("%BATCH_DIR%\..") do set "SCRIPTS_DIR=%%~fi"
for %%i in ("%SCRIPTS_DIR%\..") do set "ROOT_DIR=%%~fi"

set "PATCH_SCRIPT=%SCRIPTS_DIR%\patch_kiro_extension.js"

echo.
echo  ============================================================
echo   KiroProxy Gateway v2.8.0 — Uninstaller
echo  ============================================================
echo.

:: ── Stop proxy server ─────────────────────────────────────────
echo  [1] Stopping KiroProxy Gateway (port 8084) if running...
for /f "tokens=5" %%p in ('netstat -aon 2^>nul ^| findstr ":8084 "') do (
  taskkill /F /PID %%p >nul 2>&1 && echo      Stopped PID %%p
)

:: ── Restore extension.js ──────────────────────────────────────
echo  [2] Restoring Kiro extension.js from backup...
cd /d "%ROOT_DIR%"
node "%PATCH_SCRIPT%" --restore
if errorlevel 1 (
  echo  [WARN] Restore may have failed. Check if backup exists:
  echo         %LOCALAPPDATA%\Programs\Kiro\resources\app\extensions\kiro.kiro-agent\dist\extension.js.original
)

:: ── Remove env var ────────────────────────────────────────────
echo  Removing CLOUD_CONFIG_ENDPOINT environment variable...
powershell -NoProfile -Command ^
  "[System.Environment]::SetEnvironmentVariable('CLOUD_CONFIG_ENDPOINT',$null,'User')"
echo  [OK] CLOUD_CONFIG_ENDPOINT removed

echo.
echo  Uninstall complete.
echo  Restart Kiro IDE to fully revert to original behavior.
echo.
pause
endlocal
