@echo off
setlocal EnableDelayedExpansion
:: ============================================================
::  launch.bat — KiroProxy Gateway Launcher v2.8.0
::
::  Usage:
::    launch.bat              Start proxy server
::    launch.bat --stop       Stop running proxy
::    launch.bat --status     Show server status
::    launch.bat --test       Run test suite
::    launch.bat --patch      Re-apply Kiro IDE patch
::    launch.bat --restore    Restore original Kiro IDE extension
::    launch.bat --ide        Start proxy and launch Kiro IDE
:: ============================================================

set "BATCH_DIR=%~dp0"
set "BATCH_DIR=%BATCH_DIR:~0,-1%"
for %%i in ("%BATCH_DIR%\..") do set "SCRIPTS_DIR=%%~fi"
for %%i in ("%SCRIPTS_DIR%\..") do set "ROOT_DIR=%%~fi"

set "SERVER_SCRIPT=%ROOT_DIR%\src\index.js"
set "PATCH_SCRIPT=%SCRIPTS_DIR%\patch_kiro_extension.js"
set "TEST_SCRIPT=%ROOT_DIR%\tests\test_gateway.js"
set "PROXY_PORT=8084"
set "KIRO_IDE=%LOCALAPPDATA%\Programs\Kiro\Kiro.exe"

if "%1"=="--stop"    goto :stop
if "%1"=="--status"  goto :status
if "%1"=="--test"    goto :run_test
if "%1"=="--patch"   goto :patch
if "%1"=="--restore" goto :restore
if "%1"=="--ide"     goto :run_ide

:: ── Default: Start server ─────────────────────────────────────
:start
echo.
echo  ============================================================
echo    KiroProxy Gateway v2.8.0
echo  ============================================================
echo.

cd /d "%ROOT_DIR%"

:: Check if already running
powershell -NoProfile -Command "try{Invoke-RestMethod 'http://127.0.0.1:%PROXY_PORT%/health' -TimeoutSec 2|Out-Null;exit 0}catch{exit 1}" >nul 2>&1
if not errorlevel 1 (
    echo  [OK] Gateway already running on port %PROXY_PORT%
    goto :show_status
)

:: Ensure patch applied
if exist "%PATCH_SCRIPT%" (
    node "%PATCH_SCRIPT%" >nul 2>&1
)

:: Start server
start "KiroProxy Gateway" /MIN cmd /c "node "%SERVER_SCRIPT%" 2>&1"
echo  [START] Gateway starting on port %PROXY_PORT%...
powershell -NoProfile -Command "Start-Sleep -Seconds 3" >nul 2>&1

:show_status
powershell -NoProfile -Command ^
  "try{$h=Invoke-RestMethod 'http://127.0.0.1:%PROXY_PORT%/health' -TimeoutSec 3;" ^
  "Write-Host '  Server  :' $h.version;" ^
  "Write-Host '  Tunnel  :' $h.tunnel;" ^
  "$h.providers.PSObject.Properties|%%{$s=if($_.Value.status){$_.Value.status}else{$_.Value};Write-Host ('  Provider: '+$_.Name+'='+$s)}}catch{Write-Host '  [OFFLINE] Server not responding'}"
echo.
echo  Commands:  --stop  --status  --test  --patch  --restore  --ide
echo.
goto :eof

:: ── Status ────────────────────────────────────────────────────
:status
echo.
echo  ============================================================
echo    KiroProxy Gateway v2.8.0 — Status
echo  ============================================================
powershell -NoProfile -Command ^
  "try{$h=Invoke-RestMethod 'http://127.0.0.1:%PROXY_PORT%/health' -TimeoutSec 3;" ^
  "Write-Host '  [ONLINE]';" ^
  "Write-Host '  Version :' $h.version;" ^
  "Write-Host '  Tunnel  :' $h.tunnel;" ^
  "$h.providers.PSObject.Properties|%%{$s=if($_.Value.status){$_.Value.status}else{$_.Value};$icon=if($s-eq'healthy'){'OK'}else{'!!'};Write-Host ('  ['+$icon+'] '+$_.Name+': '+$s)}}catch{Write-Host '  [OFFLINE] Gateway not running'}"
echo.
if exist "%PATCH_SCRIPT%" ( node "%PATCH_SCRIPT%" --check )
echo.
goto :eof

:: ── Run Tests ─────────────────────────────────────────────────
:run_test
echo.
echo  ============================================================
echo    Running Test Suite
echo  ============================================================
echo.
:: Ensure server running
powershell -NoProfile -Command "try{Invoke-RestMethod 'http://127.0.0.1:%PROXY_PORT%/health' -TimeoutSec 2|Out-Null;exit 0}catch{exit 1}" >nul 2>&1
if errorlevel 1 (
    echo  [INFO] Starting server for tests...
    cd /d "%ROOT_DIR%"
    start "KiroProxy Gateway" /MIN cmd /c "node "%SERVER_SCRIPT%" 2>&1"
    powershell -NoProfile -Command "Start-Sleep -Seconds 4" >nul 2>&1
)
cd /d "%ROOT_DIR%"
node "%TEST_SCRIPT%"
echo.
echo  Test run complete.
goto :eof

:: ── Apply patch ────────────────────────────────────────────────
:patch
echo.
echo  Applying patch to Kiro IDE extension...
node "%PATCH_SCRIPT%"
echo  Done. Restart Kiro IDE to apply.
goto :eof

:: ── Restore original extension ─────────────────────────────────
:restore
echo.
echo  Restoring original Kiro IDE extension...
call :stop_silent
node "%PATCH_SCRIPT%" --restore
echo  Done. Restart Kiro IDE to apply.
goto :eof

:: ── Launch IDE ────────────────────────────────────────────────
:run_ide
call :start
echo  Launching Kiro IDE...
if exist "%KIRO_IDE%" (
    start "" "%KIRO_IDE%"
) else (
    echo  [WARN] Kiro IDE not found at %KIRO_IDE%
)
goto :eof

:: ── Stop ──────────────────────────────────────────────────────
:stop
call :stop_silent
echo  Gateway stopped.
goto :eof

:stop_silent
for /f "tokens=5" %%p in ('netstat -aon 2^>nul ^| findstr ":%PROXY_PORT% "') do (
    taskkill /F /PID %%p >nul 2>&1
)
goto :eof

endlocal
