# KiroProxy Gateway — Batch Scripts Documentation

All batch scripts in `scripts/batch/` are designed for Windows environments and resolve root paths dynamically, allowing execution from any directory.

---

## 📄 Available Scripts

### `install.bat`
**Purpose:** Installs dependencies and patches the local Kiro IDE extension for dual-mode operation.

**Usage:**
```cmd
scripts\batch\install.bat
```

**Actions Performed:**
1. Verifies Node.js 18+ installation.
2. Verifies Kiro IDE installation path (`%LOCALAPPDATA%\Programs\Kiro\...`).
3. Installs required npm dependencies.
4. Generates initial `config/kiro_ai_config.json` and `.env` from templates if absent.
5. Runs `node scripts/patch_kiro_extension.js` to enable dual-mode routing.
6. Sets user environment variable `CLOUD_CONFIG_ENDPOINT=http://127.0.0.1:8084`.

---

### `launch.bat`
**Purpose:** Primary operational controller for KiroProxy Gateway.

**Usage:**
```cmd
# Start proxy server (default)
scripts\batch\launch.bat

# Show real-time health and provider status
scripts\batch\launch.bat --status

# Stop running proxy server (frees port 8084)
scripts\batch\launch.bat --stop

# Run test suite
scripts\batch\launch.bat --test

# Re-apply extension patch
scripts\batch\launch.bat --patch

# Restore original unpatched Kiro extension
scripts\batch\launch.bat --restore

# Start proxy and launch Kiro IDE
scripts\batch\launch.bat --ide
```

---

### `start_with_ngrok.bat`
**Purpose:** Starts KiroProxy Gateway with public Ngrok reverse tunnel enabled for remote IDE or mobile access.

**Usage:**
```cmd
scripts\batch\start_with_ngrok.bat
```

**Requirements:**
- `NGROK_AUTHTOKEN` or `NGROK_TOKEN` configured in `.env`.

---

### `test_gateway.bat`
**Purpose:** Automated 12-point health, catalog, and protocol validation harness.

**Usage:**
```cmd
scripts\batch\test_gateway.bat
```

**Tests Performed:**
- **T01:** Server health endpoint (`/health`)
- **T02:** Model catalog free-only pricing verification (`rateMultiplier = 0.0`)
- **T03:** Minimum model count check
- **T04:** OpenAI-compatible `/v1/models` catalog
- **T05:** Ngrok Canvas Bridge `/poll` endpoint
- **T06:** Workflow compatibility graceful fallback
- **T07:** AWS Bedrock Converse protocol emulation
- **T08:** Ngrok tunnel status verification
- **T09:** Kiro IDE extension patch state check
- **T10:** Chat completion via `auto` fallback model
- **T11:** Health provider status structure inspection
- **T12:** Model catalog pricing schema verification

---

### `verify_kiro_ide.bat`
**Purpose:** Diagnostic verification script testing end-to-end Kiro IDE connectivity.

**Usage:**
```cmd
scripts\batch\verify_kiro_ide.bat
```

---

### `uninstall.bat`
**Purpose:** Safely stops KiroProxy Gateway on port 8084 and restores the stock unpatched `extension.js` from `extension.js.original`.

**Usage:**
```cmd
scripts\batch\uninstall.bat
```

---

*KiroProxy Gateway v2.7.0 — Command-line utilities and launchers.*
