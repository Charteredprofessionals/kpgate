@echo off
setlocal EnableDelayedExpansion
:: ============================================================
::  install.bat — KiroProxy Gateway Installer v2.8.0
::  Run from anywhere — paths are derived from this file's location.
::  Safe to re-run (idempotent). No admin rights required.
:: ============================================================

:: Resolve project root (two levels up from scripts\batch\)
set "BATCH_DIR=%~dp0"
set "BATCH_DIR=%BATCH_DIR:~0,-1%"
for %%i in ("%BATCH_DIR%\..") do set "SCRIPTS_DIR=%%~fi"
for %%i in ("%SCRIPTS_DIR%\..") do set "ROOT_DIR=%%~fi"

set "PATCH_SCRIPT=%SCRIPTS_DIR%\patch_kiro_extension.js"
set "SERVER_SCRIPT=%ROOT_DIR%\src\index.js"

echo.
echo  ============================================================
echo   KiroProxy Gateway v2.8.0 — Installation
echo  ============================================================
echo.
echo  Root    : %ROOT_DIR%
echo  Scripts : %SCRIPTS_DIR%
echo.

:: [1] Check Node.js
where node >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Node.js not found. Install from: https://nodejs.org
    pause & exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do set NODE_VER=%%v
echo  [OK] Node.js %NODE_VER%

:: [2] Check Kiro IDE
set "KIRO_EXT=%LOCALAPPDATA%\Programs\Kiro\resources\app\extensions\kiro.kiro-agent\dist\extension.js"
if not exist "%KIRO_EXT%" (
    echo  [ERROR] Kiro IDE not found at expected path:
    echo          %KIRO_EXT%
    echo          Install Kiro from: https://kiro.dev
    pause & exit /b 1
)
echo  [OK] Kiro IDE found

:: [3] Install npm dependencies
cd /d "%ROOT_DIR%"
if not exist node_modules (
    echo  [*] Installing npm dependencies...
    call npm install
    if errorlevel 1 (
        echo  [ERROR] npm install failed
        pause & exit /b 1
    )
)
echo  [OK] Dependencies installed

:: [4] Check config file
if not exist "%ROOT_DIR%\config\kiro_ai_config.json" (
    echo  [*] Creating config from template...
    copy "%ROOT_DIR%\config\kiro_ai_config.template.json" "%ROOT_DIR%\config\kiro_ai_config.json" >nul
    echo  [OK] config\kiro_ai_config.json created — edit or use GUI at http://localhost:8084/config
) else (
    echo  [OK] config\kiro_ai_config.json exists
)

:: [5] Check .env file
if not exist "%ROOT_DIR%\.env" (
    echo  [*] Creating .env from template...
    copy "%ROOT_DIR%\.env.template" "%ROOT_DIR%\.env" >nul
    echo  [OK] .env created — add NGROK_AUTHTOKEN if needed
) else (
    echo  [OK] .env exists
)

:: [6] Patch Kiro extension
echo  [*] Patching Kiro IDE extension...
node "%PATCH_SCRIPT%"
if errorlevel 1 (
    echo  [ERROR] Patch script failed
    pause & exit /b 1
)

:: [7] Set CLOUD_CONFIG_ENDPOINT (user-level env var)
powershell -NoProfile -Command ^
  "[System.Environment]::SetEnvironmentVariable('CLOUD_CONFIG_ENDPOINT','http://127.0.0.1:8084','User')"
echo  [OK] CLOUD_CONFIG_ENDPOINT=http://127.0.0.1:8084 set

echo.
echo  ============================================================
echo   Installation Complete!
echo  ============================================================
echo.
echo   Next steps:
echo     1. Run  start.bat              to launch the gateway
echo     2. Open http://localhost:8084/config  to manage API keys
echo     3. Reload Kiro IDE (press Ctrl+Shift+P -^> "Developer: Reload Window")
echo     4. Pick any FREE model         in the model selector
echo.
echo   Config: config\kiro_ai_config.json
echo   Uninstall: scripts\batch\uninstall.bat
echo   Test:      scripts\batch\test_gateway.bat
echo.
pause
endlocal
