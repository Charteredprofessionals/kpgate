# Configuration Files

All runtime and template configuration lives here.

## Files

| File | Purpose |
|------|---------|
| `kiro_ai_config.json` | **Live config** — API keys, custom providers, settings. Gitignored. |
| `kiro_ai_config.template.json` | Template — copy to `kiro_ai_config.json` to start |
| `kiro_ai_config.example.json` | Annotated example showing all supported fields |
| `.env.template` | Template for `.env` — ngrok token, port overrides |

## Quick Setup

```bash
# 1. Copy template to live config
copy config\kiro_ai_config.template.json config\kiro_ai_config.json

# 2. Edit with your API keys (optional)
notepad config\kiro_ai_config.json

# 3. OR use the GUI to manage keys visually
#    http://localhost:8084/config
```

## Config Lookup Order

The server resolves configuration in this priority order:

```
1. config/kiro_ai_config.local.json   (machine-specific overrides, gitignored)
2. config/kiro_ai_config.json         (project config, gitignored)
3. ~/.kiro/kiro_ai_config.json        (user-global config)
```

Later sources are merged on top of earlier ones.

## Supported Fields

```json
{
  "kiloApiKeys":       ["sk-kilo-..."],
  "clineApiKeys":      ["cline-..."],
  "openrouterApiKeys": ["sk-or-v1-..."],
  "orcarouterApiKeys": ["orca-..."],
  "geminiApiKeys":     ["AIzaSy..."],
  "ngrokAuthtoken":    "your_ngrok_token",
  "customProviders": [
    {
      "name":         "Groq",
      "baseUrl":      "https://api.groq.com/openai/v1",
      "apiKey":       "gsk_...",
      "defaultModel": "llama-3.3-70b-versatile",
      "priority":     "high",
      "enabled":      true
    }
  ]
}
```

## GUI Configuration

Prefer the visual interface for managing keys:

```
http://localhost:8084/config
```

See: `../docs/CONFIGURATION_GUI.md` for full guide.
