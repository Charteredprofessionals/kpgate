/**
 * Custom Provider Auto-Population Test
 * 
 * Verifies that custom providers are:
 * 1. Discovered from config
 * 2. Models auto-populated from /v1/models endpoint
 * 3. Added to MODELS.models catalog
 * 4. Exposed via /v1/models API endpoint
 * 5. Properly filtered (free-only when freeOnly=true)
 */

const http = require('http');

const PROXY_BASE = 'http://localhost:8084';
const TESTS = [];
const RESULTS = { passed: 0, failed: 0 };

function test(name, fn) {
  TESTS.push({ name, fn });
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(`Assertion failed: ${message}`);
  }
}

async function httpGet(path) {
  return new Promise((resolve, reject) => {
    http.get(PROXY_BASE + path, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode >= 400) {
          reject(new Error(`HTTP ${res.statusCode}: ${data}`));
        } else {
          try {
            resolve({ statusCode: res.statusCode, data: JSON.parse(data) });
          } catch (e) {
            resolve({ statusCode: res.statusCode, data: data });
          }
        }
      });
    }).on('error', reject);
  });
}

// ── Tests ──────────────────────────────────────────────────────────────────────

test('Custom providers enabled in config', async () => {
  const res = await httpGet('/api/config');
  assert(res.statusCode === 200, 'Config endpoint should return 200');
  assert(Array.isArray(res.data.customProviders), 'Config should have customProviders array');
  
  const enabled = res.data.customProviders.filter(p => p.enabled !== false);
  assert(enabled.length >= 3, `Expected at least 3 enabled custom providers, got ${enabled.length}`);
  
  const groq = enabled.find(p => p.name === 'Groq');
  assert(groq, 'Groq provider should be enabled');
  assert(groq.freeOnly === true, 'Groq should have freeOnly=true');
  
  const glm = enabled.find(p => p.name === 'GLM');
  assert(glm, 'GLM provider should be enabled');
  assert(glm.apiKey === 'sk-devgw-master-key', 'GLM should have pre-configured API key');
  
  const abhyast = enabled.find(p => p.name === 'Abhyast-Gemini');
  assert(abhyast, 'Abhyast-Gemini provider should be enabled');
  assert(abhyast.baseUrl.includes('ngrok'), 'Abhyast-Gemini should use ngrok tunnel');
});

test('Models catalog includes custom provider models', async () => {
  const res = await httpGet('/v1/models');
  assert(res.statusCode === 200, 'Models endpoint should return 200');
  assert(res.data.object === 'list', 'Response should be OpenAI-compatible list');
  assert(Array.isArray(res.data.data), 'Response should have data array');
  
  const allModels = res.data.data;
  console.log(`   → Total models: ${allModels.length}`);
  
  const customModels = allModels.filter(m => m.id.startsWith('custom-'));
  console.log(`   → Custom provider models: ${customModels.length}`);
  
  assert(customModels.length >= 3, `Expected at least 3 custom models, got ${customModels.length}`);
  
  // Check for specific providers
  const groqModels = customModels.filter(m => m.id.includes('groq'));
  const glmModels = customModels.filter(m => m.id.includes('glm'));
  const abhyastModels = customModels.filter(m => m.id.includes('abhyast'));
  
  console.log(`   → Groq models: ${groqModels.length}`);
  console.log(`   → GLM models: ${glmModels.length}`);
  console.log(`   → Abhyast-Gemini models: ${abhyastModels.length}`);
  
  // At least one model per enabled provider
  assert(groqModels.length >= 1 || glmModels.length >= 1 || abhyastModels.length >= 1, 
    'At least one custom provider should have models');
});

test('Custom models are free-only (rateMultiplier 0.0)', async () => {
  const res = await httpGet('/v1/models');
  const customModels = res.data.data.filter(m => m.id.startsWith('custom-'));
  
  // All models in /v1/models should be free (filtered by endpoint)
  // But let's verify custom models specifically
  for (const model of customModels) {
    console.log(`   → Checking ${model.id}`);
    // The /v1/models endpoint already filters by rateMultiplier === 0.0
    // So if the model appears here, it passed the filter
    assert(model.id.startsWith('custom-'), `Model ${model.id} should have custom prefix`);
  }
  
  console.log(`   → All ${customModels.length} custom models passed free-only filter`);
});

test('Custom provider model IDs are valid', async () => {
  const res = await httpGet('/v1/models');
  const customModels = res.data.data.filter(m => m.id.startsWith('custom-'));
  
  for (const model of customModels) {
    // Valid format: custom-{provider}-{model-id}
    assert(model.id.match(/^custom-[a-z0-9\-]+$/), 
      `Model ID ${model.id} should match pattern custom-{provider}-{model}`);
    
    // Should have descriptive name
    assert(model.name && model.name.length > 0, 
      `Model ${model.id} should have a name`);
  }
});

test('Groq provider specific checks', async () => {
  const res = await httpGet('/v1/models');
  const groqModels = res.data.data.filter(m => m.id.includes('groq'));
  
  if (groqModels.length > 0) {
    console.log(`   → Found ${groqModels.length} Groq models`);
    
    // Check first model structure
    const firstModel = groqModels[0];
    assert(firstModel.id.startsWith('custom-groq-'), 'Groq model should have custom-groq- prefix');
    assert(firstModel.owned_by === 'kiro-proxy', 'Model should be owned by kiro-proxy');
    
    console.log(`   → Sample Groq model: ${firstModel.id}`);
    console.log(`   → Display name: ${firstModel.name}`);
  } else {
    console.warn('   ⚠️ No Groq models found (may need API key or provider may be down)');
  }
});

test('GLM provider specific checks', async () => {
  const res = await httpGet('/v1/models');
  const glmModels = res.data.data.filter(m => m.id.includes('glm'));
  
  if (glmModels.length > 0) {
    console.log(`   → Found ${glmModels.length} GLM models`);
    
    const firstModel = glmModels[0];
    assert(firstModel.id.startsWith('custom-glm-'), 'GLM model should have custom-glm- prefix');
    
    console.log(`   → Sample GLM model: ${firstModel.id}`);
  } else {
    console.warn('   ⚠️ No GLM models found (provider may be down)');
  }
});

test('Abhyast-Gemini provider specific checks', async () => {
  const res = await httpGet('/v1/models');
  const abhyastModels = res.data.data.filter(m => m.id.includes('abhyast'));
  
  if (abhyastModels.length > 0) {
    console.log(`   → Found ${abhyastModels.length} Abhyast-Gemini models`);
    
    const firstModel = abhyastModels[0];
    assert(firstModel.id.startsWith('custom-abhyast-gemini-'), 
      'Abhyast model should have custom-abhyast-gemini- prefix');
    
    console.log(`   → Sample Abhyast model: ${firstModel.id}`);
  } else {
    console.warn('   ⚠️ No Abhyast-Gemini models found (ngrok tunnel may be down)');
  }
});

// ── Test Runner ────────────────────────────────────────────────────────────────

async function runTests() {
  console.log('═══════════════════════════════════════════════════════');
  console.log('   Custom Provider Auto-Population Test Suite');
  console.log('═══════════════════════════════════════════════════════\n');
  
  for (const { name, fn } of TESTS) {
    try {
      await fn();
      console.log(`✅ ${name}`);
      RESULTS.passed++;
    } catch (err) {
      console.log(`❌ ${name}`);
      console.log(`   ${err.message}\n`);
      RESULTS.failed++;
    }
  }
  
  console.log('\n═══════════════════════════════════════════════════════');
  console.log('   Test Summary');
  console.log('═══════════════════════════════════════════════════════');
  console.log(`✅ Passed: ${RESULTS.passed}`);
  console.log(`❌ Failed: ${RESULTS.failed}`);
  console.log(`📊 Total:  ${TESTS.length}`);
  console.log(`📈 Success: ${Math.floor(RESULTS.passed / TESTS.length * 100)}%\n`);
  
  process.exit(RESULTS.failed > 0 ? 1 : 0);
}

runTests().catch(err => {
  console.error('Test runner error:', err);
  process.exit(1);
});
