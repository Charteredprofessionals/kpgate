#!/usr/bin/env node
/**
 * e2e_runner.js - Master 4-Tier Opaque-Box E2E Test Runner for KiroProxy Gateway
 * 
 * Orchestrates comprehensive testing across all 4 tiers:
 *   Tier 1: Feature Coverage (R1, R2, R3, R4)
 *   Tier 2: Boundary & Corner Cases (R1, R2, R3, R4)
 *   Tier 3: Cross-Feature Combinations
 *   Tier 4: Real-World Application Scenarios
 * 
 * Usage:
 *   node tests/e2e/e2e_runner.js [--all] [--tier=1|2|3|4] [--port=8084] [--bail] [--json]
 */

'use strict';

const { HttpClient } = require('./helpers/http_client');
const { ServerManager } = require('./helpers/server_manager');
const { registerTier1Tests } = require('./tier1_features.test');
const { registerTier2Tests } = require('./tier2_boundaries.test');
const { registerTier3Tests } = require('./tier3_combinations.test');
const { registerTier4Tests } = require('./tier4_scenarios.test');

class TestSuite {
  constructor(options = {}) {
    this.options = options;
    this.tests = [];
    this.results = [];
    this.currentTier = 1;
  }

  setTier(tier) {
    this.currentTier = tier;
  }

  test(name, fn) {
    this.tests.push({
      name,
      tier: this.currentTier,
      fn
    });
  }

  async run(bail = false) {
    let passed = 0;
    let failed = 0;
    let skipped = 0;

    const startTime = Date.now();

    for (const t of this.tests) {
      const testStart = Date.now();
      try {
        await t.fn();
        const duration = Date.now() - testStart;
        passed++;
        this.results.push({
          tier: t.tier,
          name: t.name,
          status: 'PASS',
          duration,
          error: null
        });
        console.log(`  ✅ [PASS] (Tier ${t.tier}) ${t.name} (${duration}ms)`);
      } catch (err) {
        const duration = Date.now() - testStart;
        failed++;
        this.results.push({
          tier: t.tier,
          name: t.name,
          status: 'FAIL',
          duration,
          error: err.message || String(err)
        });
        console.error(`  ❌ [FAIL] (Tier ${t.tier}) ${t.name} (${duration}ms)`);
        console.error(`     ↳ Error: ${err.message}`);
        if (bail) {
          console.log('\n[E2E Runner] Aborting further execution due to --bail flag.');
          break;
        }
      }
    }

    const totalDuration = Date.now() - startTime;
    return {
      total: this.tests.length,
      passed,
      failed,
      skipped,
      duration: totalDuration,
      results: this.results
    };
  }
}

async function main() {
  const args = process.argv.slice(2);
  const helpRequested = args.includes('--help') || args.includes('-h');
  if (helpRequested) {
    console.log(`
KiroProxy Gateway 4-Tier E2E Test Runner
========================================
Usage:
  node tests/e2e/e2e_runner.js [options]

Options:
  --tier=1|2|3|4    Run only specific tier (default: runs all tiers)
  --port=<port>     Target gateway port (default: 8084 or env KIRO_TEST_PORT)
  --bail            Exit immediately on first test failure
  --json            Output test results in JSON format
  --help, -h        Show this help message
    `);
    process.exit(0);
  }

  let selectedTier = null;
  const tierArg = args.find(a => a.startsWith('--tier='));
  if (tierArg) {
    selectedTier = parseInt(tierArg.split('=')[1], 10);
  }

  let port = parseInt(process.env.KIRO_TEST_PORT || process.env.KIRO_PROXY_PORT || process.env.PROXY_PORT || process.env.PORT || '8084', 10);
  const portArg = args.find(a => a.startsWith('--port='));
  if (portArg) {
    port = parseInt(portArg.split('=')[1], 10);
  }

  const bail = args.includes('--bail');
  const jsonOutput = args.includes('--json');

  console.log('╔══════════════════════════════════════════════════════════════════════╗');
  console.log('║       KiroProxy Gateway — 4-Tier Opaque-Box E2E Test Suite           ║');
  console.log('╚══════════════════════════════════════════════════════════════════════╝\n');
  console.log(`  Target Host   : 127.0.0.1:${port}`);
  console.log(`  Selected Tier : ${selectedTier ? `Tier ${selectedTier}` : 'All Tiers (1, 2, 3, 4)'}`);
  console.log(`  Bail on Error : ${bail}`);
  console.log(`  Execution Mode: Opaque-Box HTTP/EventStream\n`);

  // Ensure gateway is running
  const serverManager = new ServerManager(port);
  console.log('🔍 Checking gateway readiness...');
  try {
    const launchInfo = await serverManager.ensureRunning(15000);
    console.log(`✅ Gateway is ready (${launchInfo.status}) on ${launchInfo.baseUrl}\n`);
  } catch (err) {
    console.error(`❌ Gateway failed to start: ${err.message}`);
    process.exit(1);
  }

  const client = new HttpClient(`http://127.0.0.1:${port}`);
  const suite = new TestSuite();

  // Register Tier Tests
  if (!selectedTier || selectedTier === 1) {
    console.log('─── Running Tier 1: Feature Coverage (R1, R2, R3, R4) ─────────────');
    suite.setTier(1);
    registerTier1Tests(suite, client);
  }

  if (!selectedTier || selectedTier === 2) {
    console.log('─── Running Tier 2: Boundary & Corner Cases (R1, R2, R3, R4) ──────');
    suite.setTier(2);
    registerTier2Tests(suite, client);
  }

  if (!selectedTier || selectedTier === 3) {
    console.log('─── Running Tier 3: Cross-Feature Combinations ─────────────────────');
    suite.setTier(3);
    registerTier3Tests(suite, client);
  }

  if (!selectedTier || selectedTier === 4) {
    console.log('─── Running Tier 4: Real-World Application Scenarios ───────────────');
    suite.setTier(4);
    registerTier4Tests(suite, client);
  }

  const summary = await suite.run(bail);

  // Stop managed server if spawned by test suite
  await serverManager.stop();

  // Print Summary Table
  console.log('\n══════════════════════════════════════════════════════════════════════');
  console.log('                   E2E TEST EXECUTION SUMMARY                          ');
  console.log('══════════════════════════════════════════════════════════════════════');

  const tierMap = { 1: { pass: 0, fail: 0 }, 2: { pass: 0, fail: 0 }, 3: { pass: 0, fail: 0 }, 4: { pass: 0, fail: 0 } };
  for (const r of summary.results) {
    if (r.status === 'PASS') tierMap[r.tier].pass++;
    else tierMap[r.tier].fail++;
  }

  console.log(`  Tier 1 (Feature Coverage)       : ${tierMap[1].pass} passed, ${tierMap[1].fail} failed (Total: ${tierMap[1].pass + tierMap[1].fail})`);
  console.log(`  Tier 2 (Boundary & Corner Cases): ${tierMap[2].pass} passed, ${tierMap[2].fail} failed (Total: ${tierMap[2].pass + tierMap[2].fail})`);
  console.log(`  Tier 3 (Cross-Feature Combos)   : ${tierMap[3].pass} passed, ${tierMap[3].fail} failed (Total: ${tierMap[3].pass + tierMap[3].fail})`);
  console.log(`  Tier 4 (Real-World Scenarios)   : ${tierMap[4].pass} passed, ${tierMap[4].fail} failed (Total: ${tierMap[4].pass + tierMap[4].fail})`);
  console.log('──────────────────────────────────────────────────────────────────────');
  console.log(`  Total Tests  : ${summary.passed + summary.failed}`);
  console.log(`  ✅ Passed    : ${summary.passed}`);
  console.log(`  ❌ Failed    : ${summary.failed}`);
  console.log(`  ⏱️ Duration   : ${(summary.duration / 1000).toFixed(2)}s`);
  const successRate = summary.passed + summary.failed > 0
    ? Math.round((summary.passed / (summary.passed + summary.failed)) * 100)
    : 0;
  console.log(`  📈 Pass Rate : ${successRate}%\n`);

  if (jsonOutput) {
    console.log('JSON Report:');
    console.log(JSON.stringify(summary, null, 2));
  }

  if (summary.failed > 0) {
    console.log('Failed Tests Detail:');
    summary.results.filter(r => r.status === 'FAIL').forEach(r => {
      console.log(`  ❌ [Tier ${r.tier}] ${r.name}`);
      console.log(`     ↳ ${r.error}`);
    });
    console.log('\n❌ E2E Test Suite FAILED');
    process.exit(1);
  } else {
    console.log('🎉 ALL E2E TESTS PASSED SUCCESSFULLY! Gateway is production ready.\n');
    process.exit(0);
  }
}

main().catch(err => {
  console.error('\n❌ Fatal runner error:', err);
  process.exit(1);
});
