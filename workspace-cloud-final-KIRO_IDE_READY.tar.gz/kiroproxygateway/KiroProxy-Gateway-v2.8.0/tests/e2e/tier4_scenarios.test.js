/**
 * tier4_scenarios.test.js - Tier 4: Real-World Application Scenarios E2E Test Suite
 * 
 * Verifies complete, complex end-to-end workflows matching live Kiro IDE and
 * Gemini Canvas browser bridge interactions:
 * - Scenario 1: Kiro IDE Cold Boot, Model Discovery & Preflight
 * - Scenario 2: Multi-Turn Conversational Coding Session via EventStream
 * - Scenario 3: Kiro Agent Tool Configuration & Invocation Loop
 * - Scenario 4: Workflow Run Interception & Direct Tool Execution Recovery
 * - Scenario 5: Gemini Canvas Browser Bridge Full Cycle (gemini.google.com)
 * 
 * Total: 5 comprehensive real-world scenarios
 */

'use strict';

const assert = require('assert');
const { EventStreamDecoder } = require('./helpers/eventstream_decoder');

function registerTier4Tests(suite, client) {
  // ── Scenario 1: Kiro IDE Cold Boot & Preflight ──────────────────────────────
  suite.test('T4_SCEN_01: Realistic Kiro IDE Cold Boot, Discovery & Preflight Workflow', async () => {
    // Step 1: Health probe
    const health = await client.get('/health');
    assert.strictEqual(health.statusCode, 200);
    assert.strictEqual(health.body.status, 'ok');

    // Step 2: Model catalog discovery
    const models = await client.get('/listAvailableModels');
    assert.strictEqual(models.statusCode, 200);
    assert.ok(models.body.models.length > 0);

    // Step 3: Feature configuration check
    const features = await client.get('/featureconfiguration');
    assert.strictEqual(features.statusCode, 200);
    assert.ok(Array.isArray(features.body.featureEvaluations));

    // Step 4: Usage limits retrieval
    const limits = await client.get('/usagelimits');
    assert.strictEqual(limits.statusCode, 200);
    assert.ok(limits.body.usageLimit >= 10000);

    // Step 5: Profile retrieval
    const profile = await client.get('/getprofile');
    assert.strictEqual(profile.statusCode, 200);
    assert.strictEqual(profile.body.status, 'ACTIVE');

    // Step 6: Workspace spaces discovery
    const spaces = await client.get('/spaces');
    assert.strictEqual(spaces.statusCode, 200);
    assert.ok(Array.isArray(spaces.body.spaces));
  });

  // ── Scenario 2: Multi-Turn Conversation Session ────────────────────────────
  suite.test('T4_SCEN_02: Multi-Turn Conversational Coding Session with EventStream Continuity', async () => {
    const convId = 'multiturn_session_' + Date.now();

    // Turn 1: User asks first question
    const turn1Payload = {
      conversationState: {
        conversationId: convId,
        currentMessage: {
          userInputMessage: {
            modelId: 'kilo-auto/small',
            content: 'Write a JS function to reverse a string'
          }
        }
      }
    };

    const turn1Res = await client.request({
      method: 'POST',
      path: '/generateAssistantResponse',
      body: turn1Payload,
      responseType: 'buffer',
      timeout: 25000
    });
    assert.strictEqual(turn1Res.statusCode, 200);
    const frames1 = EventStreamDecoder.decodeFrames(turn1Res.rawBuffer);
    assert.ok(frames1.length > 0, 'Expected EventStream frames on Turn 1');
    frames1.forEach(f => {
      assert.strictEqual(f.preludeCrcValid, true);
      assert.strictEqual(f.messageCrcValid, true);
    });

    // Turn 2: Follow-up question maintaining conversation history
    const turn2Payload = {
      conversationState: {
        conversationId: convId,
        currentMessage: {
          userInputMessage: {
            modelId: 'kilo-auto/small',
            content: 'Now explain how that works in one sentence'
          }
        }
      }
    };

    const turn2Res = await client.request({
      method: 'POST',
      path: '/generateAssistantResponse',
      body: turn2Payload,
      responseType: 'buffer',
      timeout: 25000
    });
    assert.strictEqual(turn2Res.statusCode, 200);
    const frames2 = EventStreamDecoder.decodeFrames(turn2Res.rawBuffer);
    assert.ok(frames2.length > 0, 'Expected EventStream frames on Turn 2');
    frames2.forEach(f => {
      assert.strictEqual(f.preludeCrcValid, true);
      assert.strictEqual(f.messageCrcValid, true);
    });
  });

  // ── Scenario 3: Kiro Agent Tool Execution Loop ──────────────────────────────
  suite.test('T4_SCEN_03: Kiro Agent Tool Configuration & Invocation Handling Loop', async () => {
    const agentPayload = {
      conversationState: {
        conversationId: 'tool_loop_' + Date.now(),
        currentMessage: {
          userInputMessage: {
            modelId: 'kilo-auto/small',
            content: 'Check the current directory status'
          }
        }
      },
      toolConfiguration: {
        tools: [
          {
            toolSpec: {
              name: 'execute_command',
              description: 'Run a shell command',
              inputSchema: {
                type: 'object',
                properties: {
                  command: { type: 'string', description: 'Command to run' }
                },
                required: ['command']
              }
            }
          },
          {
            toolSpec: {
              name: 'fs_read_file',
              description: 'Read file contents',
              inputSchema: {
                type: 'object',
                properties: {
                  path: { type: 'string' }
                },
                required: ['path']
              }
            }
          }
        ]
      }
    };

    const res = await client.request({
      method: 'POST',
      path: '/generateAssistantResponse',
      body: agentPayload,
      responseType: 'buffer',
      timeout: 25000
    });

    assert.strictEqual(res.statusCode, 200);
    const frames = EventStreamDecoder.decodeFrames(res.rawBuffer);
    assert.ok(frames.length > 0);

    frames.forEach(f => {
      assert.strictEqual(f.preludeCrcValid, true);
      assert.strictEqual(f.messageCrcValid, true);
    });
  });

  // ── Scenario 4: Workflow Run Degradation & Tool Recovery ───────────────────
  suite.test('T4_SCEN_04: Workflow Interception, Direct Execution Steering & Graceful Degradation', async () => {
    // 1. Kiro IDE requests workflow orchestration
    const wfRes = await client.post('/runtime/workflows/run', {
      workflowPrompt: 'Analyze codebase performance',
      runLabel: 'perf-audit-01',
      inputs: { depth: 'full' }
    });
    assert.strictEqual(wfRes.statusCode, 200);
    assert.strictEqual(wfRes.body.fallbackMode, 'direct_execution');

    // 2. Kiro IDE falls back to executing the prompt directly
    const directRes = await client.request({
      method: 'POST',
      path: '/generateAssistantResponse',
      body: {
        conversationState: {
          conversationId: 'wf_recovery_' + Date.now(),
          currentMessage: {
            userInputMessage: {
              modelId: 'kilo-auto/small',
              content: 'Analyze codebase performance directly'
            }
          }
        }
      },
      responseType: 'buffer',
      timeout: 35000
    });
    assert.strictEqual(directRes.statusCode, 200);

    const frames = EventStreamDecoder.decodeFrames(directRes.rawBuffer);
    assert.ok(frames.length > 0);
  });

  // ── Scenario 5: Gemini Canvas Browser Bridge Full Cycle ────────────────────
  suite.test('T4_SCEN_05: Gemini Canvas Browser Bridge Full Session Cycle from gemini.google.com', async () => {
    const origin = 'https://gemini.google.com';

    // 1. Dashboard accessibility
    const canvasRes = await client.request({ path: '/canvas', responseType: 'text' });
    assert.strictEqual(canvasRes.statusCode, 200);

    // 2. Browser preflight check with live Gemini origin
    const preflight = await client.options('/poll', {
      'Origin': origin,
      'Access-Control-Request-Method': 'GET',
      'Access-Control-Request-Headers': 'ngrok-skip-browser-warning'
    });
    assert.strictEqual(preflight.statusCode, 200);
    assert.ok(preflight.headers['access-control-allow-origin']);

    // 3. Browser poll cycle with ngrok skip browser warning
    const pollRes = await client.get('/poll', {
      'Origin': origin,
      'ngrok-skip-browser-warning': '69420'
    }, 7000);
    assert.ok([200, 429].includes(pollRes.statusCode));

    // 4. Ingest tokens / stream chunks from browser
    const simulatedReqId = 'gemini_canvas_' + Date.now();
    const chunkRes = await client.post('/chunk', {
      id: simulatedReqId,
      text: 'Tokens streamed from Gemini Canvas sandbox'
    }, {
      'Origin': origin
    });
    assert.strictEqual(chunkRes.statusCode, 200);
    assert.strictEqual(chunkRes.rawText, 'ok');

    // 5. Finalize inference from browser
    const doneRes = await client.post('/done', {
      id: simulatedReqId,
      text: 'Final response from Gemini Canvas auto-auth',
      functionCalls: []
    }, {
      'Origin': origin
    });
    assert.strictEqual(doneRes.statusCode, 200);
    assert.strictEqual(doneRes.rawText, 'ok');
  });
}

module.exports = { registerTier4Tests };
