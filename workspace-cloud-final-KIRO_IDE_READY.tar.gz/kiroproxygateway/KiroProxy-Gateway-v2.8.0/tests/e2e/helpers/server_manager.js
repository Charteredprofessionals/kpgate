/**
 * server_manager.js - Lifecycle Management for KiroProxy Gateway in E2E Testing
 * 
 * Detects if the gateway is already running on port 8084 (or env port).
 * If not running, launches it as a background process, waits for the readiness
 * probe (/health), and provides graceful teardown.
 */

'use strict';

const http = require('http');
const path = require('path');
const { spawn } = require('child_process');

class ServerManager {
  constructor(port = 8084, host = '127.0.0.1') {
    this.port = parseInt(process.env.KIRO_TEST_PORT || process.env.KIRO_PROXY_PORT || process.env.PROXY_PORT || process.env.PORT || port, 10);
    this.host = host;
    this.baseUrl = `http://${this.host}:${this.port}`;
    this.childProcess = null;
    this.isManaged = false;
  }

  /**
   * Pings /health endpoint
   */
  async checkHealth(timeoutMs = 2000) {
    return new Promise((resolve) => {
      const req = http.get(`${this.baseUrl}/health`, { timeout: timeoutMs }, (res) => {
        let body = '';
        res.on('data', chunk => body += chunk);
        res.on('end', () => {
          try {
            const json = JSON.parse(body);
            resolve({ ok: res.statusCode === 200, statusCode: res.statusCode, data: json });
          } catch {
            resolve({ ok: res.statusCode === 200, statusCode: res.statusCode, data: body });
          }
        });
      });

      req.on('timeout', () => {
        req.destroy();
        resolve({ ok: false, error: 'TIMEOUT' });
      });

      req.on('error', (err) => {
        resolve({ ok: false, error: err.code || err.message });
      });
    });
  }

  /**
   * Ensures the server is active.
   * If already running, marks as unmanaged and returns immediately.
   * If not running, launches `scripts/kiro_proxy_server.js` or `src/index.js` and waits for readiness.
   */
  async ensureRunning(maxWaitMs = 15000) {
    const existing = await this.checkHealth(1500);
    if (existing.ok) {
      this.isManaged = false;
      return { status: 'already_running', baseUrl: this.baseUrl };
    }

    const isSrcServer = this.port === 8085 || process.env.KIRO_USE_SRC === 'true' || process.env.USE_SRC === 'true';
    const serverScript = isSrcServer
      ? path.resolve(__dirname, '../../../src/index.js')
      : path.resolve(__dirname, '../../../scripts/kiro_proxy_server.js');
    const projectRoot = path.resolve(__dirname, '../../../');

    this.childProcess = spawn(process.execPath, [serverScript], {
      cwd: projectRoot,
      env: {
        ...process.env,
        PORT: String(this.port),
        NGROK_AUTHTOKEN: process.env.NGROK_AUTHTOKEN || '' // Avoid starting ngrok if token is missing
      },
      stdio: ['ignore', 'pipe', 'pipe']
    });

    this.isManaged = true;

    this.childProcess.stdout.on('data', (d) => {
      // Optional debug logging if needed
    });

    this.childProcess.stderr.on('data', (d) => {
      // Optional debug logging if needed
    });

    // Poll until healthy
    const startTime = Date.now();
    while (Date.now() - startTime < maxWaitMs) {
      await new Promise(r => setTimeout(r, 400));
      const health = await this.checkHealth(1000);
      if (health.ok) {
        return { status: 'spawned', baseUrl: this.baseUrl };
      }
    }

    // Timed out starting server
    if (this.childProcess) {
      try { this.childProcess.kill(); } catch (e) {}
    }
    throw new Error(`KiroProxy Gateway failed to start on ${this.baseUrl} within ${maxWaitMs}ms`);
  }

  /**
   * Graceful stop if managed by this test run
   */
  async stop() {
    if (this.isManaged && this.childProcess) {
      return new Promise((resolve) => {
        this.childProcess.once('exit', () => resolve());
        this.childProcess.kill('SIGTERM');
        setTimeout(() => {
          try { this.childProcess.kill('SIGKILL'); } catch (e) {}
          resolve();
        }, 3000);
      });
    }
  }
}

module.exports = { ServerManager };
