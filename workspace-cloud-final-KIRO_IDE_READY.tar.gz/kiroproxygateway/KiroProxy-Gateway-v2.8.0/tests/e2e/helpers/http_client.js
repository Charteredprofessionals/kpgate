/**
 * http_client.js - Opaque-Box HTTP Test Client for KiroProxy Gateway E2E Tests
 * 
 * Provides robust HTTP/1.1 request utilities supporting JSON, raw text,
 * binary streams, Server-Sent Events (SSE), and custom header overrides.
 */

'use strict';

const http = require('http');

class HttpClient {
  constructor(baseUrl = 'http://127.0.0.1:8084', defaultTimeoutMs = 15000) {
    this.baseUrl = baseUrl.replace(/\/+$/, '');
    this.defaultTimeoutMs = defaultTimeoutMs;
  }

  request(options = {}) {
    return new Promise((resolve, reject) => {
      const {
        method = 'GET',
        path = '/',
        headers = {},
        body = null,
        timeout = this.defaultTimeoutMs,
        responseType = 'auto' // 'auto' | 'json' | 'text' | 'buffer' | 'sse'
      } = options;

      const url = new URL(path, this.baseUrl);
      let postData = null;

      const reqHeaders = { ...headers };

      if (body !== null && body !== undefined) {
        if (typeof body === 'object' && !Buffer.isBuffer(body)) {
          postData = JSON.stringify(body);
          if (!reqHeaders['Content-Type']) {
            reqHeaders['Content-Type'] = 'application/json';
          }
        } else if (Buffer.isBuffer(body)) {
          postData = body;
        } else {
          postData = String(body);
        }
        if (!reqHeaders['Content-Length']) {
          reqHeaders['Content-Length'] = Buffer.byteLength(postData);
        }
      }

      const reqOptions = {
        hostname: url.hostname,
        port: url.port || 80,
        path: url.pathname + url.search,
        method: method.toUpperCase(),
        headers: reqHeaders,
        timeout
      };

      const req = http.request(reqOptions, (res) => {
        const chunks = [];

        res.on('data', (chunk) => {
          chunks.push(chunk);
        });

        res.on('end', () => {
          const rawBuffer = Buffer.concat(chunks);
          const rawText = rawBuffer.toString('utf-8');
          let parsedData = null;

          if (responseType === 'buffer') {
            parsedData = rawBuffer;
          } else if (responseType === 'text') {
            parsedData = rawText;
          } else {
            // 'auto' or 'json': Try parsing JSON for standard json or AWS json (application/x-amz-json-1.1)
            const contentType = (res.headers['content-type'] || '').toLowerCase();
            const shouldParseJson = contentType.includes('json') || responseType === 'json' || responseType === 'auto';
            if (shouldParseJson && rawText && (rawText.trim().startsWith('{') || rawText.trim().startsWith('['))) {
              try {
                parsedData = JSON.parse(rawText);
              } catch (e) {
                parsedData = rawText;
              }
            } else {
              parsedData = rawText;
            }
          }

          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            body: parsedData,
            rawText,
            rawBuffer
          });
        });
      });

      req.on('timeout', () => {
        req.destroy();
        reject(new Error(`HTTP request timed out after ${timeout}ms: ${method} ${path}`));
      });

      req.on('error', (err) => {
        reject(err);
      });

      if (postData) {
        req.write(postData);
      }
      req.end();
    });
  }

  get(path, headers = {}, timeout = undefined) {
    return this.request({ method: 'GET', path, headers, timeout });
  }

  post(path, body = null, headers = {}, timeout = undefined) {
    return this.request({ method: 'POST', path, body, headers, timeout });
  }

  options(path, headers = {}, timeout = undefined) {
    return this.request({ method: 'OPTIONS', path, headers, timeout });
  }

  /**
   * Collect Server-Sent Events (SSE) from streaming endpoints like /v1/chat/completions (stream: true)
   */
  streamSse(path, body = null, headers = {}, timeout = 20000) {
    return new Promise((resolve, reject) => {
      const url = new URL(path, this.baseUrl);
      const postData = body ? JSON.stringify(body) : null;
      const reqHeaders = {
        'Accept': 'text/event-stream',
        'Content-Type': 'application/json',
        ...headers
      };

      if (postData) {
        reqHeaders['Content-Length'] = Buffer.byteLength(postData);
      }

      const reqOptions = {
        hostname: url.hostname,
        port: url.port || 80,
        path: url.pathname + url.search,
        method: 'POST',
        headers: reqHeaders,
        timeout
      };

      const events = [];
      let fullText = '';

      const req = http.request(reqOptions, (res) => {
        res.on('data', (chunk) => {
          const str = chunk.toString('utf-8');
          fullText += str;
          const lines = str.split('\n');
          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('data:')) {
              const dataPayload = trimmed.replace(/^data:\s*/, '');
              events.push(dataPayload);
            }
          }
        });

        res.on('end', () => {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            events,
            fullText
          });
        });
      });

      req.on('timeout', () => {
        req.destroy();
        reject(new Error(`SSE request timed out after ${timeout}ms: ${path}`));
      });

      req.on('error', reject);

      if (postData) {
        req.write(postData);
      }
      req.end();
    });
  }
}

module.exports = { HttpClient };
