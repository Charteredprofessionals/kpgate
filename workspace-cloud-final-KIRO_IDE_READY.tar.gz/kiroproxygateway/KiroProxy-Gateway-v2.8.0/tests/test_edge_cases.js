#!/usr/bin/env node
/**
 * Edge Case & Failure Mode Test Suite
 * Tests error handling, validation, and edge cases in Kiro Gateway
 */

const http = require('http');

const BASE_URL = 'http://localhost:8084';
let passCount = 0;
let failCount = 0;

function httpRequest(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      method,
      hostname: 'localhost',
      port: 8084,
      path,
      headers: body ? { 'Content-Type': 'application/json' } : {},
      timeout: 15000
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = data ? JSON.parse(data) : {};
          resolve({ statusCode: res.statusCode, data: json });
        } catch (e) {
          resolve({ statusCode: res.statusCode, data: { rawData: data } });
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });

    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function test(name, fn) {
  try {
    await fn();
    console.log(`✅ ${name}`);
    passCount++;
  } catch (err) {
    console.log(`❌ ${name}`);
    console.log(`   ${err.message}`);
    failCount++;
  }
}

async function runTests() {
  console.log('╔══════════════════════════════════════════════════════════════╗');
  console.log('║     Kiro Gateway Edge Case & Failure Mode Test Suite         ║');
  console.log('╚══════════════════════════════════════════════════════════════╝\n');

  // ── 1. Empty/Null Messages ─────────────────────────────────────────
  console.log('[1] EMPTY/NULL MESSAGE VALIDATION');
  
  await test('Empty messages array returns 400', async () => {
    const res = await httpRequest('POST', '/v1/chat/completions', {
      model: 'auto',
      messages: []
    });
    if (res.statusCode !== 400) {
      throw new Error(`Expected 400, got ${res.statusCode}`);
    }
    if (!res.data.error) {
      throw new Error('Expected error object in response');
    }
  });

  await test('Null content passes through', async () => {
    const res = await httpRequest('POST', '/v1/chat/completions', {
      model: 'auto',
      messages: [{ role: 'user', content: null }]
    });
    // Should either work or return proper error, not 502
    if (res.statusCode !== 200 && res.statusCode !== 400) {
      throw new Error(`Unexpected status: ${res.statusCode}`);
    }
  });

  // ── 2. Invalid Model Names ─────────────────────────────────────────
  console.log('\n[2] INVALID MODEL NAME HANDLING');

  await test('Random invalid model name returns error', async () => {
    const res = await httpRequest('POST', '/v1/chat/completions', {
      model: 'xyz-random-12345',
      messages: [{ role: 'user', content: 'hi' }]
    });
    // Should return error, not crash
    if (res.statusCode === 500 || res.statusCode === 502) {
      if (res.data.error && res.data.error.message) {
        // Good - proper error handling
        return;
      }
      throw new Error('Server error without proper error message');
    }
  });

  await test('Empty model uses fallback', async () => {
    const res = await httpRequest('POST', '/v1/chat/completions', {
      model: '',
      messages: [{ role: 'user', content: 'hi' }]
    });
    // Should use 'auto' or return error
    if (res.statusCode !== 200 && res.statusCode !== 400) {
      throw new Error(`Unexpected status: ${res.statusCode}`);
    }
  });

  // ── 3. Missing Fields ──────────────────────────────────────────────
  console.log('\n[3] MISSING REQUIRED FIELDS');

  await test('Missing messages field returns 400', async () => {
    const res = await httpRequest('POST', '/v1/chat/completions', {
      model: 'auto'
    });
    if (res.statusCode !== 400) {
      throw new Error(`Expected 400, got ${res.statusCode}`);
    }
  });

  await test('Missing model field uses default', async () => {
    const res = await httpRequest('POST', '/v1/chat/completions', {
      messages: [{ role: 'user', content: 'hi' }]
    });
    // Should work with default model
    if (res.statusCode !== 200) {
      throw new Error(`Expected 200, got ${res.statusCode}`);
    }
  });

  // ── 4. Request Size Limits ─────────────────────────────────────────
  console.log('\n[4] MESSAGE SIZE HANDLING');

  await test('10KB message handled correctly', async () => {
    try {
      const res = await httpRequest('POST', '/v1/chat/completions', {
        model: 'auto',
        messages: [{ role: 'user', content: 'x'.repeat(10000) }]
      });
      // Should work or return proper error
      if (res.statusCode !== 200 && res.statusCode !== 413) {
        throw new Error(`Unexpected status: ${res.statusCode}`);
      }
    } catch (err) {
      // Timeout is OK for large messages (provider-side delay)
      if (err.message === 'Request timeout') {
        console.log('   ℹ️  Large message caused timeout (provider delay, not gateway error)');
        return; // Pass the test
      }
      throw err;
    }
  });

  // ── 5. Generation Parameters ───────────────────────────────────────
  console.log('\n[5] GENERATION PARAMETERS');

  await test('temperature:0 accepted', async () => {
    const res = await httpRequest('POST', '/v1/chat/completions', {
      model: 'auto',
      messages: [{ role: 'user', content: 'hi' }],
      temperature: 0
    });
    if (res.statusCode !== 200) {
      throw new Error(`Expected 200, got ${res.statusCode}`);
    }
  });

  await test('Invalid temperature handled', async () => {
    const res = await httpRequest('POST', '/v1/chat/completions', {
      model: 'auto',
      messages: [{ role: 'user', content: 'hi' }],
      temperature: 999
    });
    // Provider may reject or accept - both OK
    if (res.statusCode === 500) {
      throw new Error('Server crash instead of proper error handling');
    }
  });

  await test('max_tokens parameter accepted', async () => {
    try {
      const res = await httpRequest('POST', '/v1/chat/completions', {
        model: 'auto',
        messages: [{ role: 'user', content: 'hi' }],
        max_tokens: 100
      });
      if (res.statusCode !== 200) {
        throw new Error(`Expected 200, got ${res.statusCode}`);
      }
    } catch (err) {
      if (err.message === 'Request timeout') {
        console.log('   ℹ️  Provider timeout (not a gateway error)');
        return; // Pass — gateway accepted the parameter
      }
      throw err;
    }
  });

  // ── 6. Health & Monitoring ─────────────────────────────────────────
  console.log('\n[6] HEALTH & MONITORING ENDPOINTS');

  await test('Health endpoint returns provider objects', async () => {
    const res = await httpRequest('GET', '/health');
    if (res.statusCode !== 200) {
      throw new Error(`Expected 200, got ${res.statusCode}`);
    }
    const providers = res.data.providers;
    if (!providers || !providers.kilo || !providers.kilo.status) {
      throw new Error('Health endpoint missing provider status objects');
    }
    // Should have at least 6 providers (core: kilo, cline, openrouter, orcarouter, ngrok, gemini + any custom)
    const providerList = Object.keys(providers);
    if (providerList.length < 6) {
      throw new Error(`Expected at least 6 providers, got ${providerList.length}`);
    }
  });

  await test('Models include pricing information', async () => {
    const res = await httpRequest('GET', '/listAvailableModels');
    if (res.statusCode !== 200) {
      throw new Error(`Expected 200, got ${res.statusCode}`);
    }
    const firstModel = res.data.models[0];
    if (!firstModel.pricing) {
      throw new Error('Model missing pricing field');
    }
    if (!firstModel.pricing.prompt || !firstModel.pricing.completion) {
      throw new Error('Pricing missing prompt/completion fields');
    }
  });

  // ══════════════════════════════════════════════════════════════════
  // Summary
  // ══════════════════════════════════════════════════════════════════
  console.log('\n═══════════════════════════════════════════════════════');
  console.log('   Test Summary');
  console.log('═══════════════════════════════════════════════════════');
  console.log(`✅ Passed:  ${passCount}`);
  console.log(`❌ Failed:  ${failCount}`);
  console.log(`📊 Total:   ${passCount + failCount}`);
  console.log(`📈 Success: ${Math.round(passCount / (passCount + failCount) * 100)}%`);
  
  if (failCount === 0) {
    console.log('\n🎉 All edge case tests passed! Gateway has robust error handling.');
  } else {
    console.log(`\n⚠️  ${failCount} test(s) failed. Review edge case handling.`);
    process.exit(1);
  }
}

runTests().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
