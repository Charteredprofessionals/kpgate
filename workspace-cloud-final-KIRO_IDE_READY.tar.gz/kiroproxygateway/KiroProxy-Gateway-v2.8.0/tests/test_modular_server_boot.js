/**
 * tests/test_modular_server_boot.js
 * Verifies src/index.js starts cleanly on port 8085, serves key endpoints, and shuts down cleanly.
 */

'use strict';

const http = require('http');
process.env.PROXY_PORT = process.env.PROXY_PORT || '8085';
const { server, PROXY_PORT } = require('../src/index');

const TARGET_PORT = PROXY_PORT || 8085;
const BASE_URL = `http://127.0.0.1:${TARGET_PORT}`;

function httpRequest(method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + (url.search || ''),
      method,
      headers: {
        'x-amzn-requestid': 'test_' + Date.now(),
        ...headers
      }
    };

    if (body) {
      const bodyStr = typeof body === 'string' ? body : JSON.stringify(body);
      options.headers['Content-Type'] = 'application/json';
      options.headers['Content-Length'] = Buffer.byteLength(bodyStr);
    }

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, headers: res.headers, data: JSON.parse(data), raw: data });
        } catch {
          resolve({ status: res.statusCode, headers: res.headers, data: null, raw: data });
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(15000, () => {
      req.destroy();
      reject(new Error(`Request timeout for ${method} ${path}`));
    });

    if (body) {
      req.write(typeof body === 'string' ? body : JSON.stringify(body));
    }
    req.end();
  });
}

async function runBootVerification() {
  console.log(`Starting modular server on port ${TARGET_PORT}...`);

  await new Promise((resolve, reject) => {
    server.listen(TARGET_PORT, '127.0.0.1', () => {
      console.log(`✅ Server successfully listening on http://127.0.0.1:${TARGET_PORT}`);
      resolve();
    });
    server.on('error', reject);
  });

  const assertions = [];

  // 1. Health check
  const healthRes = await httpRequest('GET', '/health');
  if (healthRes.status === 200 && healthRes.data?.status === 'ok') {
    assertions.push('✅ GET /health returns 200 ok');
  } else {
    throw new Error(`Health check failed: ${healthRes.status} ${healthRes.raw}`);
  }

  // 2. Metrics check
  const metricsRes = await httpRequest('GET', '/metrics');
  if (metricsRes.status === 200 && metricsRes.raw.includes('kiro_proxy_uptime_seconds')) {
    assertions.push('✅ GET /metrics returns Prometheus text metrics');
  } else {
    throw new Error(`Metrics check failed: ${metricsRes.status}`);
  }

  // 3. Status check
  const statusRes = await httpRequest('GET', '/status');
  if (statusRes.status === 200 && statusRes.data?.proxy === 'KiroProxy Gateway') {
    assertions.push('✅ GET /status returns 200 KiroProxy Gateway info');
  } else {
    throw new Error(`Status check failed: ${statusRes.status}`);
  }

  // 4. ListAvailableModels check
  const modelsRes = await httpRequest('GET', '/listAvailableModels');
  if (modelsRes.status === 200 && Array.isArray(modelsRes.data?.models)) {
    assertions.push(`✅ GET /listAvailableModels returns ${modelsRes.data.models.length} models with rateMultiplier 0.0`);
  } else {
    throw new Error(`Model list check failed: ${modelsRes.status}`);
  }

  // 5. OpenAI /v1/models check
  const v1ModelsRes = await httpRequest('GET', '/v1/models');
  if (v1ModelsRes.status === 200 && v1ModelsRes.data?.object === 'list') {
    assertions.push(`✅ GET /v1/models returns ${v1ModelsRes.data.data.length} free models`);
  } else {
    throw new Error(`/v1/models check failed: ${v1ModelsRes.status}`);
  }

  // 6. Canvas Bridge /canvas check
  const canvasRes = await httpRequest('GET', '/canvas');
  if (canvasRes.status === 200 && (canvasRes.headers['content-type'] || '').includes('text/html')) {
    assertions.push('✅ GET /canvas returns 200 HTML dashboard');
  } else {
    throw new Error(`/canvas check failed: ${canvasRes.status}`);
  }

  // 7. Canvas Bridge OPTIONS /poll check
  const pollOptionsRes = await httpRequest('OPTIONS', '/poll', null, {
    'Origin': 'https://gemini.google.com',
    'Access-Control-Request-Method': 'GET'
  });
  if (pollOptionsRes.status === 200) {
    assertions.push('✅ OPTIONS /poll returns 200 CORS preflight');
  } else {
    throw new Error(`OPTIONS /poll failed: ${pollOptionsRes.status}`);
  }

  // 8. Canvas Bridge GET /poll check
  const pollGetRes = await httpRequest('GET', '/poll');
  if (pollGetRes.status === 200 && 'id' in pollGetRes.data) {
    assertions.push('✅ GET /poll returns 200 queue metadata');
  } else {
    throw new Error(`GET /poll failed: ${pollGetRes.status}`);
  }

  // 9. Workflow run fallback
  const wfRunRes = await httpRequest('POST', '/runtime/workflows/run', { workflowPrompt: 'test' });
  if (wfRunRes.status === 200 && wfRunRes.data?.fallbackMode === 'direct_execution') {
    assertions.push('✅ POST /runtime/workflows/run returns graceful fallback');
  } else {
    throw new Error(`Workflow run failed: ${wfRunRes.status}`);
  }

  // 10. Workflow inspect 404
  const wfInspectRes = await httpRequest('GET', '/runtime/workflows/inspect?workflowId=test');
  if (wfInspectRes.status === 404) {
    assertions.push('✅ GET /runtime/workflows/inspect returns 404');
  } else {
    throw new Error(`Workflow inspect expected 404, got: ${wfInspectRes.status}`);
  }

  // 11. Workflow validate 501
  const wfValRes = await httpRequest('POST', '/runtime/workflows/validate', {});
  if (wfValRes.status === 501) {
    assertions.push('✅ POST /runtime/workflows/validate returns 501');
  } else {
    throw new Error(`Workflow validate expected 501, got: ${wfValRes.status}`);
  }

  // 12. MCP tools list
  const mcpRes = await httpRequest('POST', '/invokemcp', { jsonrpc: '2.0', id: 1, method: 'tools/list' });
  if (mcpRes.status === 200 && Array.isArray(mcpRes.data?.result?.tools)) {
    assertions.push(`✅ POST /invokemcp returns ${mcpRes.data.result.tools.length} tools`);
  } else {
    throw new Error(`MCP tools list failed: ${mcpRes.status}`);
  }

  // 13. Universal AWS Catch-All
  const catchAllRes = await httpRequest('POST', '/unrecognized_endpoint_for_test', {});
  if (catchAllRes.status === 200 && catchAllRes.data?.__type?.includes('Success')) {
    assertions.push('✅ POST /unrecognized_endpoint returns AWS Catch-All Acknowledged');
  } else {
    throw new Error(`AWS Catch-All failed: ${catchAllRes.status}`);
  }

  // Close server cleanly
  await new Promise((resolve) => server.close(resolve));
  console.log('✅ Server shut down cleanly.\n');

  console.log('═══════════════════════════════════════════════════════');
  console.log('   Modular Server Boot & Verification Results');
  console.log('═══════════════════════════════════════════════════════');
  assertions.forEach(a => console.log(a));
  console.log(`\n🎉 ALL ${assertions.length} MODULAR ENDPOINT ASSERTIONS PASSED ON PORT ${TARGET_PORT}!`);
  process.exit(0);
}

runBootVerification().catch(err => {
  console.error('❌ Boot verification error:', err);
  server.close(() => process.exit(1));
});
