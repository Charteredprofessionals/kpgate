/**
 * tests/verify_dual_run_parity.js
 * Comprehensive Dual-Port Parallel Parity Verification Suite
 * 
 * Compares Port 8084 (legacy monolithic server daemon) and Port 8085 (modular src/index.js):
 * 1. Bit-level AWS Bedrock Binary EventStream framing parity:
 *    - 12-byte prelude: [TotalLen (UInt32BE), HeadersLen (UInt32BE), PreludeCRC (UInt32BE)]
 *    - Type 7 String Headers (:event-type, :content-type, :message-type)
 *    - Message Payload integrity & encoding
 *    - Trailing Message CRC32 checksum verification via zlib.crc32
 * 2. Route parity, HTTP status codes, Content-Type, and CORS headers:
 *    - GET /health, GET /status, GET /listAvailableModels, GET /v1/models,
 *      GET /usagelimits, GET /featureconfiguration, GET /canvas,
 *      OPTIONS /poll, OPTIONS /generateAssistantResponse,
 *      POST /runtime/workflows/run, GET /metrics, AWS catch-all
 * 3. Live binary Bedrock converse streaming parity on /generateAssistantResponse
 * 4. Tool Use Event formatting & stringified input contract (INV-06, Format 1b, Format 6b)
 * 
 * Usage:
 *   node tests/verify_dual_run_parity.js
 */

'use strict';

const http = require('http');
const path = require('path');
const zlib = require('zlib');
const assert = require('assert');
const { spawn } = require('child_process');

const { createEventStreamFrame, createConverseEvent } = require('../src/protocol/eventstream');
const { EventStreamDecoder } = require('./e2e/helpers/eventstream_decoder');
const {
  extractToolsAndTextFromProviderResponse,
  extractToolCallsFromResponse,
  sanitizeJsonBackslashes
} = require('../src/translators/tool_extractor');

const PORT_8084 = 8084;
const PORT_8085 = 8085;
const HOST = '127.0.0.1';
const BASE_8084 = `http://${HOST}:${PORT_8084}`;
const BASE_8085 = `http://${HOST}:${PORT_8085}`;

let spawned8085Process = null;

// Test Tracker
const stats = {
  total: 0,
  passed: 0,
  failed: 0,
  failures: []
};

function pass(name, details = '') {
  stats.total++;
  stats.passed++;
  console.log(`  ✅ [PASS] ${name}${details ? ` (${details})` : ''}`);
}

function fail(name, error) {
  stats.total++;
  stats.failed++;
  const errMsg = error ? (error.message || String(error)) : 'Unknown assertion failure';
  console.error(`  ❌ [FAIL] ${name}: ${errMsg}`);
  stats.failures.push({ name, error: errMsg });
}

function assertParity(name, condition, errorMsg = '') {
  try {
    if (!condition) {
      throw new Error(errorMsg || 'Condition evaluated to false');
    }
    pass(name);
  } catch (err) {
    fail(name, err);
  }
}

/**
 * Robust HTTP request helper
 */
function httpRequest(baseUrl, method, reqPath, body = null, customHeaders = {}, timeoutMs = 25000, responseType = 'auto') {
  return new Promise((resolve, reject) => {
    const url = new URL(reqPath, baseUrl);
    const headers = {
      'x-amzn-requestid': 'parity_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      ...customHeaders
    };

    let postData = null;
    if (body !== null && body !== undefined) {
      if (typeof body === 'object' && !Buffer.isBuffer(body)) {
        postData = JSON.stringify(body);
        if (!headers['Content-Type']) {
          headers['Content-Type'] = 'application/json';
        }
      } else if (Buffer.isBuffer(body)) {
        postData = body;
      } else {
        postData = String(body);
      }
      headers['Content-Length'] = Buffer.byteLength(postData);
    }

    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + (url.search || ''),
      method: method.toUpperCase(),
      headers
    };

    const req = http.request(options, (res) => {
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => {
        const rawBuffer = Buffer.concat(chunks);
        const rawText = rawBuffer.toString('utf-8');
        let parsed = null;
        if (responseType === 'json' || responseType === 'auto') {
          try {
            parsed = rawText ? JSON.parse(rawText) : null;
          } catch (_) {}
        }
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          data: parsed,
          rawText,
          rawBuffer
        });
      });
    });

    req.on('error', reject);
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      reject(new Error(`Timeout (${timeoutMs}ms) on ${method} ${url.href}`));
    });

    if (postData) {
      req.write(postData);
    }
    req.end();
  });
}

/**
 * Ping /health endpoint
 */
async function checkHealth(baseUrl) {
  try {
    const res = await httpRequest(baseUrl, 'GET', '/health', null, {}, 2000, 'json');
    return res.statusCode === 200 && res.data && res.data.status === 'ok';
  } catch (_) {
    return false;
  }
}

/**
 * Ensure both port 8084 and port 8085 are ready
 */
async function ensureServersReady() {
  console.log('🔍 Checking dual-server availability (Port 8084 legacy daemon & Port 8085 modular src/)...');

  const healthy8084 = await checkHealth(BASE_8084);
  if (!healthy8084) {
    throw new Error(`Port 8084 (legacy server daemon) is not responding on ${BASE_8084}/health. Please ensure the daemon is running.`);
  }
  console.log(`  ✅ Port 8084 is listening and healthy at ${BASE_8084}`);

  let healthy8085 = await checkHealth(BASE_8085);
  if (!healthy8085) {
    console.log(`  ℹ️ Port 8085 is not running; launching src/index.js child process...`);
    const projectRoot = path.resolve(__dirname, '..');
    const srcEntry = path.join(projectRoot, 'src', 'index.js');

    spawned8085Process = spawn(process.execPath, [srcEntry], {
      cwd: projectRoot,
      env: {
        ...process.env,
        PROXY_PORT: '8085',
        PORT: '8085'
      },
      stdio: ['ignore', 'pipe', 'pipe']
    });

    // Wait for readiness
    const startTime = Date.now();
    while (Date.now() - startTime < 12000) {
      await new Promise(r => setTimeout(r, 400));
      if (await checkHealth(BASE_8085)) {
        healthy8085 = true;
        break;
      }
    }

    if (!healthy8085) {
      if (spawned8085Process) {
        try { spawned8085Process.kill(); } catch (_) {}
      }
      throw new Error(`Port 8085 failed to boot within 12 seconds.`);
    }
    console.log(`  ✅ Port 8085 dynamically launched and healthy at ${BASE_8085}`);
  } else {
    console.log(`  ✅ Port 8085 is listening and healthy at ${BASE_8085}`);
  }
}

function cleanup() {
  if (spawned8085Process) {
    try {
      spawned8085Process.kill('SIGTERM');
    } catch (_) {}
    spawned8085Process = null;
  }
}

process.on('exit', cleanup);
process.on('SIGINT', () => { cleanup(); process.exit(1); });
process.on('SIGTERM', () => { cleanup(); process.exit(1); });

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 1: Spec-Exact Binary EventStream Framing Parity
// ═══════════════════════════════════════════════════════════════════════════════
function verifyBinaryEventStreamFraming() {
  console.log('\n─── SECTION 1: Bit-Level Binary EventStream Framing & CRC32 Parity ───');

  const testVectors = [
    {
      name: 'Standard assistantResponseEvent text chunk',
      headers: {
        ':event-type': 'assistantResponseEvent',
        ':content-type': 'application/json',
        ':message-type': 'event'
      },
      payload: JSON.stringify({ content: 'Hello from KiroProxy Gateway!' })
    },
    {
      name: 'ToolUseEvent with stringified JSON input contract (INV-06)',
      headers: {
        ':event-type': 'toolUseEvent',
        ':content-type': 'application/json',
        ':message-type': 'event'
      },
      payload: JSON.stringify({
        toolUseId: 'tool_call_001',
        name: 'execute_pwsh',
        input: JSON.stringify({ command: 'Get-ChildItem -Path . | Select-Object Name' }),
        stop: true
      })
    },
    {
      name: 'MetadataEvent with token telemetry',
      headers: {
        ':event-type': 'metadataEvent',
        ':content-type': 'application/json',
        ':message-type': 'event'
      },
      payload: JSON.stringify({
        usage: { inputTokens: 42, outputTokens: 128, totalTokens: 170 },
        metrics: { latencyMs: 145 }
      })
    },
    {
      name: 'Unicode UTF-8 characters and Windows paths in payload',
      headers: {
        ':event-type': 'assistantResponseEvent',
        ':content-type': 'application/json',
        ':message-type': 'event'
      },
      payload: JSON.stringify({
        text: 'File path: D:\\sdlc_studio\\projects\\kiro-integration\\src\\index.js 🚀 日本語 testing'
      })
    },
    {
      name: 'Empty payload frame with custom headers',
      headers: {
        ':event-type': 'emptyEvent',
        ':content-type': 'application/json',
        ':message-type': 'event',
        'x-amzn-stream-seq': '0'
      },
      payload: ''
    },
    {
      name: 'Substantial 8KB payload frame',
      headers: {
        ':event-type': 'assistantResponseEvent',
        ':content-type': 'application/json',
        ':message-type': 'event'
      },
      payload: JSON.stringify({
        data: 'A'.repeat(8192)
      })
    }
  ];

  for (const vec of testVectors) {
    const frame = createEventStreamFrame(vec.headers, vec.payload);

    // 1. Minimum frame length is 16 bytes (12 prelude + 0 headers + 0 payload + 4 crc)
    assertParity(
      `Frame length check: ${vec.name}`,
      frame.length >= 16 && Buffer.isBuffer(frame),
      `Expected Buffer length >= 16, got ${frame.length}`
    );

    // 2. 12-byte prelude parsing
    const totalLen = frame.readUInt32BE(0);
    const headersLen = frame.readUInt32BE(4);
    const preludeCrc = frame.readUInt32BE(8);

    assertParity(
      `Prelude totalLen matches buffer length: ${vec.name}`,
      totalLen === frame.length,
      `Expected totalLen ${frame.length}, got ${totalLen}`
    );

    const preludeComputedCrc = zlib.crc32(frame.slice(0, 8));
    assertParity(
      `Prelude CRC32 matches zlib checksum: ${vec.name}`,
      preludeCrc === preludeComputedCrc,
      `Expected ${preludeComputedCrc}, got ${preludeCrc}`
    );

    // 3. Type 7 String Headers structure verification
    const headersBuf = frame.slice(12, 12 + headersLen);
    assertParity(
      `Headers length matches prelude: ${vec.name}`,
      headersBuf.length === headersLen
    );

    let hOffset = 0;
    const parsedHeaders = {};
    while (hOffset < headersBuf.length) {
      const kLen = headersBuf.readUInt8(hOffset++);
      const k = headersBuf.slice(hOffset, hOffset + kLen).toString('utf-8');
      hOffset += kLen;
      const type = headersBuf.readUInt8(hOffset++);
      assert.strictEqual(type, 7, 'All Bedrock headers must be Type 7 String');
      const vLen = headersBuf.readUInt16BE(hOffset);
      hOffset += 2;
      const v = headersBuf.slice(hOffset, hOffset + vLen).toString('utf-8');
      hOffset += vLen;
      parsedHeaders[k] = v;
    }

    for (const [k, v] of Object.entries(vec.headers)) {
      assertParity(
        `Header '${k}' encoded accurately: ${vec.name}`,
        parsedHeaders[k] === v,
        `Expected header ${k}='${v}', got '${parsedHeaders[k]}'`
      );
    }

    // 4. Payload integrity verification
    const payloadBuf = frame.slice(12 + headersLen, frame.length - 4);
    const payloadStr = payloadBuf.toString('utf-8');
    assertParity(
      `Payload UTF-8 bytes match input: ${vec.name}`,
      payloadStr === vec.payload,
      `Payload mismatch`
    );

    // 5. Trailing Message CRC32 checksum verification
    const expectedMsgCrc = zlib.crc32(frame.slice(0, frame.length - 4));
    const actualMsgCrc = frame.readUInt32BE(frame.length - 4);
    assertParity(
      `Message CRC32 trailing checksum matches: ${vec.name}`,
      actualMsgCrc === expectedMsgCrc,
      `Expected message CRC ${expectedMsgCrc}, got ${actualMsgCrc}`
    );

    // 6. Independent decoder roundtrip
    const decodedFrames = EventStreamDecoder.decodeFrames(frame);
    assertParity(
      `Independent EventStreamDecoder roundtrip: ${vec.name}`,
      decodedFrames.length === 1 &&
      decodedFrames[0].preludeCrcValid === true &&
      decodedFrames[0].messageCrcValid === true &&
      decodedFrames[0].payloadText === vec.payload
    );
  }

  // Also verify createConverseEvent helper produces identical format
  const convFrame = createConverseEvent('assistantResponseEvent', { text: 'ConverseEvent parity' });
  const decodedConv = EventStreamDecoder.decodeFrames(convFrame);
  assertParity(
    'createConverseEvent helper generates valid Bedrock frame',
    decodedConv.length === 1 &&
    decodedConv[0].headers[':event-type'] === 'assistantResponseEvent' &&
    decodedConv[0].headers[':content-type'] === 'application/json' &&
    decodedConv[0].headers[':message-type'] === 'event' &&
    decodedConv[0].preludeCrcValid === true &&
    decodedConv[0].messageCrcValid === true
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 2: HTTP Route Parity, Status Codes & Headers (8084 vs 8085)
// ═══════════════════════════════════════════════════════════════════════════════
async function verifyRouteParity() {
  console.log('\n─── SECTION 2: HTTP Routes, Headers & Status Codes Parity (8084 vs 8085) ───');

  // Test 1: GET /health
  const [h8084, h8085] = await Promise.all([
    httpRequest(BASE_8084, 'GET', '/health'),
    httpRequest(BASE_8085, 'GET', '/health')
  ]);
  assertParity('GET /health: Status 200 on both servers', h8084.statusCode === 200 && h8085.statusCode === 200);
  assertParity('GET /health: Content-Type is application/json', (h8084.headers['content-type'] || '').includes('json') && (h8085.headers['content-type'] || '').includes('json'));
  assertParity('GET /health: CORS Access-Control-Allow-Origin parity', h8084.headers['access-control-allow-origin'] === h8085.headers['access-control-allow-origin']);
  assertParity('GET /health: JSON message and proxy identity match', h8084.data?.message === h8085.data?.message && h8084.data?.proxy === h8085.data?.proxy);
  assertParity('GET /health: Key top-level fields parity',
    h8084.data?.status === h8085.data?.status &&
    typeof h8084.data?.modelCount === 'number' && typeof h8085.data?.modelCount === 'number' &&
    typeof h8084.data?.providers === 'object' && typeof h8085.data?.providers === 'object' &&
    typeof h8084.data?.endpoints === 'object' && typeof h8085.data?.endpoints === 'object'
  );

  // Test 2: GET /status
  const [s8084, s8085] = await Promise.all([
    httpRequest(BASE_8084, 'GET', '/status'),
    httpRequest(BASE_8085, 'GET', '/status')
  ]);
  assertParity('GET /status: Status 200 on both servers', s8084.statusCode === 200 && s8085.statusCode === 200);
  assertParity('GET /status: Server version and proxy match', s8084.data?.version === s8085.data?.version && s8084.data?.proxy === s8085.data?.proxy);
  assertParity('GET /status: Summary and metrics telemetry objects present on both',
    typeof s8084.data?.summary === 'object' && typeof s8085.data?.summary === 'object' &&
    typeof s8084.data?.metrics === 'object' && typeof s8085.data?.metrics === 'object' &&
    typeof s8084.data?.circuitBreakers === 'object' && typeof s8085.data?.circuitBreakers === 'object'
  );

  // Test 3: GET /listAvailableModels
  const [m8084, m8085] = await Promise.all([
    httpRequest(BASE_8084, 'GET', '/listAvailableModels'),
    httpRequest(BASE_8085, 'GET', '/listAvailableModels')
  ]);
  assertParity('GET /listAvailableModels: Status 200 on both servers', m8084.statusCode === 200 && m8085.statusCode === 200);
  assertParity('GET /listAvailableModels: Models array present on both', Array.isArray(m8084.data?.models) && Array.isArray(m8085.data?.models));
  assertParity('GET /listAvailableModels: Substantial model catalog (>100 models)', m8084.data.models.length > 100 && m8085.data.models.length > 100);

  // Assert INV-01: rateMultiplier: 0.0 or zero-cost guarantee on free models on both
  const freeModels8084 = m8084.data.models.filter(m => m.rateMultiplier === 0 || (m.pricing && m.pricing.inputMultiplier === 0));
  const freeModels8085 = m8085.data.models.filter(m => m.rateMultiplier === 0 || (m.pricing && m.pricing.inputMultiplier === 0));
  assertParity('GET /listAvailableModels: Free models have rateMultiplier: 0.0 (INV-01) on both', freeModels8084.length > 0 && freeModels8085.length > 0);

  // Check key model presence on both
  const ids8084 = new Set(m8084.data.models.map(m => m.modelId));
  const ids8085 = new Set(m8085.data.models.map(m => m.modelId));
  assertParity('GET /listAvailableModels: kilo-auto/small present on both', ids8084.has('kilo-auto/small') && ids8085.has('kilo-auto/small'));
  assertParity('GET /listAvailableModels: kilo-free present on both', ids8084.has('kilo-free') && ids8085.has('kilo-free'));

  // Test 4: GET /v1/models
  const [v8084, v8085] = await Promise.all([
    httpRequest(BASE_8084, 'GET', '/v1/models'),
    httpRequest(BASE_8085, 'GET', '/v1/models')
  ]);
  assertParity('GET /v1/models: Status 200 on both servers', v8084.statusCode === 200 && v8085.statusCode === 200);
  assertParity('GET /v1/models: OpenAI catalog object is "list" on both', v8084.data?.object === 'list' && v8085.data?.object === 'list');
  assertParity('GET /v1/models: Data array non-empty on both', Array.isArray(v8084.data?.data) && Array.isArray(v8085.data?.data) && v8084.data.data.length > 50 && v8085.data.data.length > 50);

  // Test 5: GET /usagelimits
  const [u8084, u8085] = await Promise.all([
    httpRequest(BASE_8084, 'GET', '/usagelimits'),
    httpRequest(BASE_8085, 'GET', '/usagelimits')
  ]);
  assertParity('GET /usagelimits: Status 200 on both servers', u8084.statusCode === 200 && u8085.statusCode === 200);
  assertParity('GET /usagelimits: Unlimited credits >= 10000 on both', u8084.data?.usageLimit >= 10000 && u8085.data?.usageLimit >= 10000);
  assertParity('GET /usagelimits: Active status and standalone free subscription on both',
    u8084.data?.status === 'ACTIVE' && u8085.data?.status === 'ACTIVE' &&
    u8084.data?.subscriptionInfo?.type === 'Q_DEVELOPER_STANDALONE_FREE' &&
    u8085.data?.subscriptionInfo?.type === 'Q_DEVELOPER_STANDALONE_FREE'
  );

  // Test 6: GET /featureconfiguration
  const [f8084, f8085] = await Promise.all([
    httpRequest(BASE_8084, 'GET', '/featureconfiguration'),
    httpRequest(BASE_8085, 'GET', '/featureconfiguration')
  ]);
  assertParity('GET /featureconfiguration: Status 200 on both servers', f8084.statusCode === 200 && f8085.statusCode === 200);
  assertParity('GET /featureconfiguration: FeatureEvaluations array present on both', Array.isArray(f8084.data?.featureEvaluations) && Array.isArray(f8085.data?.featureEvaluations));

  // Test 7: GET /canvas
  const [c8084, c8085] = await Promise.all([
    httpRequest(BASE_8084, 'GET', '/canvas'),
    httpRequest(BASE_8085, 'GET', '/canvas')
  ]);
  assertParity('GET /canvas: Status 200 on both servers', c8084.statusCode === 200 && c8085.statusCode === 200);
  assertParity('GET /canvas: Content-Type includes text/html on both', (c8084.headers['content-type'] || '').includes('text/html') && (c8085.headers['content-type'] || '').includes('text/html'));
  assertParity('GET /canvas: HTML body serves Canvas dashboard on both', c8084.rawText.includes('Canvas') && c8085.rawText.includes('Canvas'));

  // Test 8: OPTIONS /poll (CORS Preflight)
  const [oPoll8084, oPoll8085] = await Promise.all([
    httpRequest(BASE_8084, 'OPTIONS', '/poll', null, { Origin: 'https://gemini.google.com' }),
    httpRequest(BASE_8085, 'OPTIONS', '/poll', null, { Origin: 'https://gemini.google.com' })
  ]);
  assertParity('OPTIONS /poll: Status 200 on both servers', oPoll8084.statusCode === 200 && oPoll8085.statusCode === 200);
  assertParity('OPTIONS /poll: ngrok-skip-browser-warning 69420 header on both', oPoll8084.headers['ngrok-skip-browser-warning'] === '69420' && oPoll8085.headers['ngrok-skip-browser-warning'] === '69420');
  assertParity('OPTIONS /poll: Access-Control-Allow-Origin preserves origin on both',
    oPoll8084.headers['access-control-allow-origin'] === 'https://gemini.google.com' &&
    oPoll8085.headers['access-control-allow-origin'] === 'https://gemini.google.com'
  );

  // Test 9: OPTIONS /generateAssistantResponse
  const [oConv8084, oConv8085] = await Promise.all([
    httpRequest(BASE_8084, 'OPTIONS', '/generateAssistantResponse'),
    httpRequest(BASE_8085, 'OPTIONS', '/generateAssistantResponse')
  ]);
  assertParity('OPTIONS /generateAssistantResponse: Status 200 on both servers', oConv8084.statusCode === 200 && oConv8085.statusCode === 200);
  assertParity('OPTIONS /generateAssistantResponse: Allowed methods include POST on both',
    (oConv8084.headers['access-control-allow-methods'] || '').includes('POST') &&
    (oConv8085.headers['access-control-allow-methods'] || '').includes('POST')
  );

  // Test 10: POST /runtime/workflows/run
  const wfPayload = { workflowPrompt: 'Parity check', runLabel: 'dual-run', inputs: {} };
  const [wf8084, wf8085] = await Promise.all([
    httpRequest(BASE_8084, 'POST', '/runtime/workflows/run', wfPayload),
    httpRequest(BASE_8085, 'POST', '/runtime/workflows/run', wfPayload)
  ]);
  assertParity('POST /runtime/workflows/run: Status 200 on both servers', wf8084.statusCode === 200 && wf8085.statusCode === 200);
  assertParity('POST /runtime/workflows/run: fallbackMode direct_execution parity',
    wf8084.data?.fallbackMode === 'direct_execution' &&
    wf8085.data?.fallbackMode === 'direct_execution' &&
    wf8084.data?.status === 'not_supported' &&
    wf8085.data?.status === 'not_supported'
  );

  // Test 11: GET /metrics
  const [met8084, met8085] = await Promise.all([
    httpRequest(BASE_8084, 'GET', '/metrics'),
    httpRequest(BASE_8085, 'GET', '/metrics')
  ]);
  assertParity('GET /metrics: Status 200 on both servers', met8084.statusCode === 200 && met8085.statusCode === 200);
  assertParity('GET /metrics: Prometheus metrics lines present on both', met8084.rawText.includes('# HELP') && met8085.rawText.includes('# HELP'));

  // Test 12: Universal AWS Catch-All
  const [ca8084, ca8085] = await Promise.all([
    httpRequest(BASE_8084, 'POST', '/nonexistent_aws_operation', {}, { 'x-amz-target': 'Bedrock.UnknownOperation' }),
    httpRequest(BASE_8085, 'POST', '/nonexistent_aws_operation', {}, { 'x-amz-target': 'Bedrock.UnknownOperation' })
  ]);
  assertParity('Universal AWS Catch-All: Status 200 on both servers', ca8084.statusCode === 200 && ca8085.statusCode === 200);
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 3: Live Bedrock Binary EventStream Parity (8084 vs 8085)
// ═══════════════════════════════════════════════════════════════════════════════
async function verifyLiveEventStreamParity() {
  console.log('\n─── SECTION 3: Live Bedrock Binary EventStream Streaming Parity (8084 vs 8085) ───');

  const conversePayload = {
    conversationState: {
      conversationId: 'dual_parity_conv_' + Date.now(),
      currentMessage: {
        userInputMessage: {
          modelId: 'kilo-auto/small',
          content: 'Dual run parity verification prompt. Reply concisely.'
        }
      }
    }
  };

  console.log('  Sending Bedrock Converse Streaming requests to 8084 and 8085...');
  const [stream8084, stream8085] = await Promise.all([
    httpRequest(BASE_8084, 'POST', '/generateAssistantResponse', conversePayload, {}, 35000, 'buffer'),
    httpRequest(BASE_8085, 'POST', '/generateAssistantResponse', conversePayload, {}, 35000, 'buffer')
  ]);

  assertParity('Converse Streaming: Status 200 on both servers', stream8084.statusCode === 200 && stream8085.statusCode === 200);

  const ct8084 = (stream8084.headers['content-type'] || '').toLowerCase();
  const ct8085 = (stream8085.headers['content-type'] || '').toLowerCase();
  assertParity(
    'Converse Streaming: application/vnd.amazon.eventstream Content-Type parity',
    ct8084.includes('application/vnd.amazon.eventstream') && ct8085.includes('application/vnd.amazon.eventstream'),
    `8084: ${ct8084}, 8085: ${ct8085}`
  );

  assertParity('Converse Streaming: Non-empty binary buffers received on both',
    stream8084.rawBuffer.length > 0 && stream8085.rawBuffer.length > 0,
    `8084: ${stream8084.rawBuffer.length} bytes, 8085: ${stream8085.rawBuffer.length} bytes`
  );

  // Decode frames from both streams
  const frames8084 = EventStreamDecoder.decodeFrames(stream8084.rawBuffer);
  const frames8085 = EventStreamDecoder.decodeFrames(stream8085.rawBuffer);

  assertParity('Converse Streaming: Valid frames decoded on 8084', frames8084.length > 0, `Decoded ${frames8084.length} frames`);
  assertParity('Converse Streaming: Valid frames decoded on 8085', frames8085.length > 0, `Decoded ${frames8085.length} frames`);

  // Verify prelude CRC and message CRC across all frames on both servers
  let all8084Valid = true;
  for (const f of frames8084) {
    if (!f.preludeCrcValid || !f.messageCrcValid) {
      all8084Valid = false;
      break;
    }
  }
  assertParity('Converse Streaming 8084: 100% frame Prelude CRC & Message CRC validity', all8084Valid);

  let all8085Valid = true;
  for (const f of frames8085) {
    if (!f.preludeCrcValid || !f.messageCrcValid) {
      all8085Valid = false;
      break;
    }
  }
  assertParity('Converse Streaming 8085: 100% frame Prelude CRC & Message CRC validity', all8085Valid);

  // Verify header contract on frames from 8085
  const hasAssistantEvents = frames8085.some(f => f.headers[':event-type'] === 'assistantResponseEvent');
  const hasMetadataEvents = frames8085.some(f => f.headers[':event-type'] === 'metadataEvent');
  assertParity('Converse Streaming 8085: Contains assistantResponseEvent frames', hasAssistantEvents);
  assertParity('Converse Streaming 8085: Contains metadataEvent completion frame', hasMetadataEvents);

  const allHeadersType7 = frames8085.every(f =>
    f.headers[':content-type'] === 'application/json' &&
    f.headers[':message-type'] === 'event'
  );
  assertParity('Converse Streaming 8085: All frames contain standard Bedrock Type 7 String Headers', allHeadersType7);
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 4: Tool Use Event Formatting & Parity
// ═══════════════════════════════════════════════════════════════════════════════
function verifyToolUseEventParity() {
  console.log('\n─── SECTION 4: Tool Use Event Formatting, Extraction & Parity ───');

  // Test 1: ToolUseEvent Frame Stringified Input Contract (INV-06)
  // Ensure that toolUseEvent.input is stringified JSON, NEVER an object
  const sampleArgs = { command: 'npm test', explanation: 'Run test suite' };
  const toolPayload = {
    toolUseId: 'call_test_' + Date.now(),
    name: 'execute_pwsh',
    input: JSON.stringify(sampleArgs),
    stop: true
  };

  const toolFrame = createConverseEvent('toolUseEvent', toolPayload);
  const decodedToolFrames = EventStreamDecoder.decodeFrames(toolFrame);
  assertParity('toolUseEvent: Valid EventStream binary frame created', decodedToolFrames.length === 1);

  const decodedPayload = decodedToolFrames[0].payloadJson;
  assertParity('toolUseEvent: Header :event-type is toolUseEvent', decodedToolFrames[0].headers[':event-type'] === 'toolUseEvent');
  assertParity('toolUseEvent: input property MUST be a string (INV-06)', typeof decodedPayload.input === 'string');
  assertParity('toolUseEvent: input is parseable JSON object matching args', JSON.stringify(JSON.parse(decodedPayload.input)) === JSON.stringify(sampleArgs));
  assertParity('toolUseEvent: stop flag is boolean true', decodedPayload.stop === true);

  // Test 2: Format 1b Bare JSON Tool Extraction with Windows single backslashes (INV-07)
  const bareJsonRaw = `{"name": "read_file", "parameters": {"path": "C:\\Users\\cscha\\projects\\app\\main.js", "offset": 0}}`;
  const sanitized = sanitizeJsonBackslashes(bareJsonRaw);
  assertParity('Format 1b: Windows path backslash sanitizer preserves drive and directory', sanitized.includes('C:\\\\Users\\\\cscha\\\\projects\\\\app\\\\main.js'));

  const parsedBare = JSON.parse(sanitized);
  assertParity('Format 1b: Sanitized bare JSON parses cleanly with JSON.parse', parsedBare.name === 'read_file' && parsedBare.parameters.path === 'C:\\Users\\cscha\\projects\\app\\main.js');

  const extractedBare = extractToolCallsFromResponse(bareJsonRaw);
  assertParity('Format 1b: extractToolCallsFromResponse extracts bare JSON tool call', extractedBare.length === 1 && extractedBare[0].name === 'read_file');
  assertParity('Format 1b: Extracted tool arguments contain accurate path', extractedBare[0].args.path === 'C:\\Users\\cscha\\projects\\app\\main.js');

  // Test 3: Format 6b Direct XML Tool Extraction
  const xmlResponse = `<read_file>D:\\sdlc_studio\\projects\\kiro-integration\\package.json</read_file>`;
  const extractedXml = extractToolCallsFromResponse(xmlResponse);
  assertParity('Format 6b: extractToolCallsFromResponse extracts direct XML tags', extractedXml.length === 1 && extractedXml[0].name === 'read_file');
  assertParity('Format 6b: Extracted tool arguments path matches XML inner content', extractedXml[0].args.path.includes('package.json'));

  // Test 4: Provider Response Extraction with mixed tools and text
  const mixedResponse = `I will inspect the directory now.\n{"name":"list_directory","parameters":{"path":"."}}\nLet me know if you need anything else.`;
  const extractedMixed = extractToolsAndTextFromProviderResponse(mixedResponse);
  assertParity('Mixed Response: Extracts tool calls from conversational text', extractedMixed.toolCalls.length === 1 && extractedMixed.toolCalls[0].name === 'list_directory');
  assertParity('Mixed Response: Strips tool block leaving conversational text', extractedMixed.text.includes('I will inspect the directory now') && !extractedMixed.text.includes('list_directory'));
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN RUNNER
// ═══════════════════════════════════════════════════════════════════════════════
async function main() {
  console.log('╔══════════════════════════════════════════════════════════════════════╗');
  console.log('║       KiroProxy Gateway Dual-Port Parallel Parity Suite              ║');
  console.log('║          Comparing Port 8084 (Legacy) vs Port 8085 (Modular src/)    ║');
  console.log('╚══════════════════════════════════════════════════════════════════════╝\n');

  const startTime = Date.now();

  try {
    await ensureServersReady();

    // Section 1: Binary framing & CRC32
    verifyBinaryEventStreamFraming();

    // Section 2: HTTP routes, headers, status codes
    await verifyRouteParity();

    // Section 3: Live Bedrock Converse EventStream parity
    await verifyLiveEventStreamParity();

    // Section 4: Tool Use Event formatting & extraction
    verifyToolUseEventParity();

  } catch (err) {
    console.error(`\n💥 Fatal Parity Suite Error: ${err.message}`);
    if (err.stack) {
      console.error(err.stack);
    }
    stats.failed++;
  } finally {
    cleanup();
  }

  const durationSec = ((Date.now() - startTime) / 1000).toFixed(2);
  const passRate = stats.total > 0 ? ((stats.passed / stats.total) * 100).toFixed(1) : '0.0';

  console.log('\n══════════════════════════════════════════════════════════════════════');
  console.log('                 DUAL-PORT PARITY SUMMARY REPORT                      ');
  console.log('══════════════════════════════════════════════════════════════════════');
  console.log(`  Total Checks Executed : ${stats.total}`);
  console.log(`  ✅ Passed Assertions   : ${stats.passed}`);
  console.log(`  ❌ Failed Assertions   : ${stats.failed}`);
  console.log(`  ⏱️ Duration            : ${durationSec}s`);
  console.log(`  📈 Parity Rate         : ${passRate}%`);
  console.log('══════════════════════════════════════════════════════════════════════\n');

  if (stats.failed > 0) {
    console.error('❌ Parity Verification FAILED! Failures:');
    for (const f of stats.failures) {
      console.error(`   - ${f.name}: ${f.error}`);
    }
    process.exit(1);
  } else {
    console.log('🎉 100% BIT-LEVEL & ROUTE PARITY VERIFIED BETWEEN PORT 8084 AND PORT 8085!\n');
    process.exit(0);
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  verifyBinaryEventStreamFraming,
  verifyRouteParity,
  verifyLiveEventStreamParity,
  verifyToolUseEventParity,
  main
};
