#!/usr/bin/env node
/**
 * Run all test suites and provide summary
 */

const { execSync } = require('child_process');

console.log('╔══════════════════════════════════════════════════════════════╗');
console.log('║          Kiro Gateway — Complete Test Suite                 ║');
console.log('╚══════════════════════════════════════════════════════════════╝\n');

let allPassed = true;

// Test 1: Main Gateway Tests
console.log('[1/2] Running Main Test Suite...');
try {
  execSync('node tests/test_gateway.js', { stdio: 'inherit' });
  console.log('✅ Main tests passed\n');
} catch (e) {
  console.log('❌ Main tests failed\n');
  allPassed = false;
}

// Test 2: Edge Case Tests
console.log('[2/2] Running Edge Case Suite...');
try {
  execSync('node tests/test_edge_cases.js', { stdio: 'inherit' });
  console.log('✅ Edge case tests passed\n');
} catch (e) {
  console.log('❌ Edge case tests failed\n');
  allPassed = false;
}

console.log('╔══════════════════════════════════════════════════════════════╗');
console.log('║                     FINAL RESULT                             ║');
console.log('╚══════════════════════════════════════════════════════════════╝');

if (allPassed) {
  console.log('🎉 ALL TEST SUITES PASSED! Gateway is production-ready.');
  process.exit(0);
} else {
  console.log('⚠️  Some tests failed. Review the output above.');
  process.exit(1);
}
