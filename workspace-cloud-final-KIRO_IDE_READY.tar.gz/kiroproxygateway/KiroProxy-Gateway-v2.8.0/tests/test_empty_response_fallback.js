/**
 * tests/test_empty_response_fallback.js
 * Verifies P0 Empty Response (HTTP 200 with 0 text & 0 tools) Detection & Fallback:
 * 1. tool_extractor: clean handling of null, undefined, empty choices, and empty content
 * 2. Provider adapters: Otomode intra-provider fallback on empty HTTP 200
 * 3. Provider adapters: Rejection with code 'EMPTY_RESPONSE' when Otomode is exhausted
 * 4. Dispatcher: Global Automode 6-tier fallback advance when provider returns empty HTTP 200
 */

'use strict';

const assert = require('assert');
const http = require('http');
const https = require('https');
const { EventEmitter } = require('events');

const { extractToolsAndTextFromProviderResponse } = require('../src/translators/tool_extractor');
const { callKiloGateway } = require('../src/providers/kilo');
const { callClineApi } = require('../src/providers/cline');
const { callOpenRouter } = require('../src/providers/openrouter');
const { callOrcaRouter } = require('../src/providers/orcarouter');
const { callGeminiApi } = require('../src/providers/gemini_direct');
const { callCustomApi } = require('../src/providers/custom');
const { dispatchInference } = require('../src/providers/dispatcher');
const { ProxyError } = require('../src/resilience/errors');

console.log('═══════════════════════════════════════════════════════════════════');
console.log('   P0 Empty Response (HTTP 200) Detection & Fallback Test Suite   ');
console.log('═══════════════════════════════════════════════════════════════════\n');

let passed = 0;
let failed = 0;

async function runAsyncTest(name, fn) {
  try {
    await fn();
    console.log(`✅ [PASS] ${name}`);
    passed++;
  } catch (err) {
    console.error(`❌ [FAIL] ${name}: ${err.message}`);
    if (err.stack) {
      console.error(err.stack.split('\n').slice(1, 4).join('\n'));
    }
    failed++;
  }
}

// Save original request methods
const originalHttpsRequest = https.request;
const originalHttpRequest = http.request;

function mockHttp(mockHandler) {
  https.request = function(options, cb) {
    return mockHandler('https', options, cb);
  };
  http.request = function(options, cb) {
    return mockHandler('http', options, cb);
  };
}

function restoreHttp() {
  https.request = originalHttpsRequest;
  http.request = originalHttpRequest;
}

function makeMockRequest(statusCode, data, cb) {
  const req = new EventEmitter();
  let writtenData = '';
  req.write = (chunk) => {
    if (chunk) writtenData += chunk;
  };
  req.end = () => {
    process.nextTick(() => {
      const res = new EventEmitter();
      res.statusCode = statusCode;
      res.headers = { 'content-type': 'application/json' };
      cb(res);
      process.nextTick(() => {
        const payload = typeof data === 'string' ? data : JSON.stringify(data);
        res.emit('data', payload);
        res.emit('end');
      });
    });
  };
  req.setTimeout = () => {};
  req.destroy = () => {};
  return req;
}

(async () => {
  // ─── SUITE 1: Tool Extractor Edge Cases ───────────────────────────────────
  console.log('--- Suite 1: Tool Extractor Safety with Empty Inputs ---');

  await runAsyncTest('extractToolsAndTextFromProviderResponse handles null and undefined safely', () => {
    const res1 = extractToolsAndTextFromProviderResponse(null);
    assert.strictEqual(res1.text, '');
    assert.deepStrictEqual(res1.toolCalls, []);
    assert.strictEqual(res1.stopReason, 'END_TURN');

    const res2 = extractToolsAndTextFromProviderResponse(undefined);
    assert.strictEqual(res2.text, '');
    assert.deepStrictEqual(res2.toolCalls, []);
  });

  await runAsyncTest('extractToolsAndTextFromProviderResponse handles empty choices array without crashing', () => {
    const res = extractToolsAndTextFromProviderResponse({ choices: [] });
    assert.strictEqual(res.text, '');
    assert.deepStrictEqual(res.toolCalls, []);
    assert.strictEqual(res.stopReason, 'END_TURN');
  });

  await runAsyncTest('extractToolsAndTextFromProviderResponse handles choice with empty message content', () => {
    const res = extractToolsAndTextFromProviderResponse({
      choices: [{ index: 0, message: { role: 'assistant', content: '' } }]
    });
    assert.strictEqual(res.text, '');
    assert.deepStrictEqual(res.toolCalls, []);
    assert.strictEqual(res.stopReason, 'END_TURN');
  });

  await runAsyncTest('extractToolsAndTextFromProviderResponse handles choice with whitespace-only content', () => {
    const res = extractToolsAndTextFromProviderResponse({
      choices: [{ index: 0, message: { role: 'assistant', content: '   \n\t  ' } }]
    });
    assert.strictEqual(res.text, '   \n\t  ');
    assert.deepStrictEqual(res.toolCalls, []);
  });

  await runAsyncTest('extractToolsAndTextFromProviderResponse handles legacy choices[0].text format', () => {
    const res = extractToolsAndTextFromProviderResponse({
      choices: [{ index: 0, text: 'legacy completion text' }]
    });
    assert.strictEqual(res.text, 'legacy completion text');
    assert.deepStrictEqual(res.toolCalls, []);
  });

  // ─── SUITE 2: Provider Otomode Fallback on HTTP 200 Empty Response ─────────
  console.log('\n--- Suite 2: Provider Otomode Fallback on Empty HTTP 200 ---');

  await runAsyncTest('callKiloGateway: Otomode switches model on empty HTTP 200', async () => {
    let callCount = 0;
    mockHttp((proto, options, cb) => {
      callCount++;
      const req = new EventEmitter();
      req.write = () => {};
      req.end = () => {
        process.nextTick(() => {
          const res = new EventEmitter();
          res.statusCode = 200;
          cb(res);
          process.nextTick(() => {
            if (callCount === 1) {
              // First call: empty completion (0 text, 0 tools)
              res.emit('data', JSON.stringify({ choices: [{ message: { content: '' } }] }));
            } else {
              // Second call: successful completion
              res.emit('data', JSON.stringify({ choices: [{ message: { content: 'Recovered in Otomode!' } }] }));
            }
            res.emit('end');
          });
        });
      };
      req.setTimeout = () => {};
      req.destroy = () => {};
      return req;
    });

    try {
      const otomodeContext = {
        _activeModel: 'kilo-model-1',
        _fallbackList: ['kilo-model-2'],
        _providerName: 'kilo'
      };
      const result = await callKiloGateway([{ role: 'user', content: 'hi' }], 'kilo-model-1', [], otomodeContext);
      assert.strictEqual(callCount, 2, 'Should have called twice (initial + fallback)');
      assert.strictEqual(result._kiro.text, 'Recovered in Otomode!');
      assert.strictEqual(otomodeContext._fallbackList.length, 0, 'Fallback list should be consumed');
    } finally {
      restoreHttp();
    }
  });

  await runAsyncTest('callKiloGateway: Throws EMPTY_RESPONSE when Otomode is exhausted', async () => {
    mockHttp((proto, options, cb) => {
      return makeMockRequest(200, { choices: [{ message: { content: '' } }] }, cb);
    });

    try {
      const otomodeContext = {
        _activeModel: 'kilo-final',
        _fallbackList: [],
        _providerName: 'kilo'
      };
      let threw = false;
      try {
        await callKiloGateway([{ role: 'user', content: 'hi' }], 'kilo-final', [], otomodeContext);
      } catch (err) {
        threw = true;
        assert.strictEqual(err.code, 'EMPTY_RESPONSE', `Expected EMPTY_RESPONSE, got: ${err.code}`);
      }
      assert.strictEqual(threw, true, 'Should have thrown when fallback list is empty');
    } finally {
      restoreHttp();
    }
  });

  await runAsyncTest('callClineApi: Otomode switches model on empty HTTP 200', async () => {
    let callCount = 0;
    mockHttp((proto, options, cb) => {
      callCount++;
      return makeMockRequest(200, callCount === 1
        ? { choices: [{ message: { content: '' } }] }
        : { choices: [{ message: { content: 'Cline model 2 output' } }] }, cb);
    });

    try {
      const otomodeContext = {
        _activeModel: 'cline-model-1',
        _fallbackList: ['cline-model-2'],
        _providerName: 'cline'
      };
      const result = await callClineApi([{ role: 'user', content: 'test' }], 'cline-model-1', [], otomodeContext);
      assert.strictEqual(callCount, 2);
      assert.strictEqual(result._kiro.text, 'Cline model 2 output');
    } finally {
      restoreHttp();
    }
  });

  await runAsyncTest('callOpenRouter: Otomode switches model on empty HTTP 200', async () => {
    let callCount = 0;
    mockHttp((proto, options, cb) => {
      callCount++;
      return makeMockRequest(200, callCount === 1
        ? { choices: [{ message: { content: '' } }] }
        : { choices: [{ message: { content: 'OpenRouter model 2 output' } }] }, cb);
    });

    try {
      const otomodeContext = {
        _activeModel: 'openrouter-1',
        _fallbackList: ['openrouter-2'],
        _providerName: 'openrouter'
      };
      const result = await callOpenRouter([{ role: 'user', content: 'test' }], 'openrouter-1', [], otomodeContext);
      assert.strictEqual(callCount, 2);
      assert.strictEqual(result._kiro.text, 'OpenRouter model 2 output');
    } finally {
      restoreHttp();
    }
  });

  await runAsyncTest('callOrcaRouter: Otomode switches model on empty HTTP 200', async () => {
    let callCount = 0;
    mockHttp((proto, options, cb) => {
      callCount++;
      return makeMockRequest(200, callCount === 1
        ? { choices: [{ message: { content: '' } }] }
        : { choices: [{ message: { content: 'OrcaRouter model 2 output' } }] }, cb);
    });

    try {
      const otomodeContext = {
        _activeModel: 'orca-1',
        _fallbackList: ['orca-2'],
        _providerName: 'orcarouter'
      };
      const result = await callOrcaRouter([{ role: 'user', content: 'test' }], 'orca-1', 'test_key', [], otomodeContext);
      assert.strictEqual(callCount, 2);
      assert.strictEqual(result._kiro.text, 'OrcaRouter model 2 output');
    } finally {
      restoreHttp();
    }
  });

  await runAsyncTest('callGeminiApi: Otomode switches model on empty HTTP 200', async () => {
    let callCount = 0;
    mockHttp((proto, options, cb) => {
      callCount++;
      return makeMockRequest(200, callCount === 1
        ? { candidates: [{ content: { parts: [{ text: '' }] } }] }
        : { candidates: [{ content: { parts: [{ text: 'Gemini flash output' }] } }] }, cb);
    });

    try {
      const otomodeContext = {
        _activeModel: 'gemini-model-1',
        _fallbackList: ['gemini-model-2'],
        _providerName: 'gemini'
      };
      const result = await callGeminiApi([{ role: 'user', content: 'test' }], 'gemini-model-1', [], otomodeContext);
      assert.strictEqual(callCount, 2);
      assert.strictEqual(result._kiro.text, 'Gemini flash output');
    } finally {
      restoreHttp();
    }
  });

  await runAsyncTest('callCustomApi: Otomode switches model on empty HTTP 200', async () => {
    let callCount = 0;
    mockHttp((proto, options, cb) => {
      callCount++;
      return makeMockRequest(200, callCount === 1
        ? { choices: [{ message: { content: '' } }] }
        : { choices: [{ message: { content: 'Custom model 2 output' } }] }, cb);
    });

    try {
      const otomodeContext = {
        _activeModel: 'custom-1',
        _fallbackList: ['custom-2'],
        _providerName: 'custom'
      };
      const cfg = { baseUrl: 'https://api.custom.ai/v1', apiKey: 'test_key', model: 'custom-1' };
      const result = await callCustomApi(cfg, [{ role: 'user', content: 'test' }], 'custom-1', [], otomodeContext);
      assert.strictEqual(callCount, 2);
      assert.strictEqual(result._kiro.text, 'Custom model 2 output');
    } finally {
      restoreHttp();
    }
  });

  // ─── SUITE 3: Dispatcher Tier Fallback on Empty Response ──────────────────
  console.log('\n--- Suite 3: Dispatcher Global Automode Tier Fallback ---');

  await runAsyncTest('dispatchInference: Global Automode advances provider tiers when tier 1 returns empty HTTP 200', async () => {
    // We will simulate:
    // Host api.kilo.ai -> HTTP 200 with empty choices
    // Host api.cline.bot -> HTTP 200 with valid content
    let kiloCalls = 0;
    let clineCalls = 0;

    mockHttp((proto, options, cb) => {
      const host = options.hostname || '';
      if (host.includes('kilo')) {
        kiloCalls++;
        return makeMockRequest(200, { choices: [{ message: { content: '' } }] }, cb);
      } else if (host.includes('cline')) {
        clineCalls++;
        return makeMockRequest(200, {
          choices: [{ message: { content: 'Tier 2 Cline responded successfully!' } }]
        }, cb);
      }
      return makeMockRequest(500, { error: 'Unknown host' }, cb);
    });

    try {
      const result = await dispatchInference([{ role: 'user', content: 'test prompt' }], 'global-automode', []);
      assert(kiloCalls > 0, 'Kilo tier 1 should have been attempted');
      assert(clineCalls > 0, 'Cline tier 2 should have been attempted after Kilo empty response');
      assert.strictEqual(result._kiro.text, 'Tier 2 Cline responded successfully!');
    } finally {
      restoreHttp();
    }
  });

  await runAsyncTest('dispatchInference: Verifies non-empty _kiro.text or _kiro.toolCalls and rejects completely empty objects', async () => {
    // If a provider somehow returns 0 text and 0 tools with no error
    mockHttp((proto, options, cb) => {
      return makeMockRequest(200, { choices: [{ message: { content: '' } }] }, cb);
    });

    try {
      let threw = false;
      try {
        await dispatchInference([{ role: 'user', content: 'test' }], 'global-automode', []);
      } catch (err) {
        threw = true;
        assert(err.message.includes('All providers failed') || err.message.includes('EMPTY_RESPONSE'));
      }
      assert.strictEqual(threw, true, 'Should have failed when all tiers return empty');
    } finally {
      restoreHttp();
    }
  });

  // ─── SUMMARY ─────────────────────────────────────────────────────────────
  console.log('\n═══════════════════════════════════════════════════════════════════');
  console.log(`Results: ${passed} passed, ${failed} failed (${passed + failed} total)`);
  console.log('═══════════════════════════════════════════════════════════════════\n');

  if (failed > 0) {
    process.exit(1);
  }
  process.exit(0);
})();
