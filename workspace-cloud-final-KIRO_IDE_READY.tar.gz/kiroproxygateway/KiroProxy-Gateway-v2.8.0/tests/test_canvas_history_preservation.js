/**
 * Test Canvas Bridge Conversation History Preservation
 * 
 * Verifies that prunePayloadForCanvas preserves as much conversation history
 * as possible within Canvas auth limits (1500 chars), rather than only sending
 * the latest user message.
 */

const assert = require('assert');

// ── Mock prunePayloadForCanvas function (copy from server.js) ──────────────────

function prunePayloadForCanvas(messages, maxTotalChars = 1500) {
  if (!Array.isArray(messages) || messages.length === 0) {
    return [{ role: 'user', content: 'Hello' }];
  }

  // Preserve and cap system prompt to max 200 characters
  const systemMsg = messages.find(m => m.role === 'system');
  let sanitizedSystem = '';
  if (systemMsg && typeof systemMsg.content === 'string') {
    sanitizedSystem = systemMsg.content.slice(0, 200).trim();
  }

  const nonSystem = messages.filter(m => m.role !== 'system');
  const chatBudget = Math.max(400, maxTotalChars - sanitizedSystem.length);

  // Build conversation history from most recent backwards until we hit the limit
  const pruned = [];
  let currentLength = 0;
  
  // Start from the end (most recent) and work backwards
  for (let i = nonSystem.length - 1; i >= 0; i--) {
    const msg = nonSystem[i];
    const content = typeof msg.content === 'string' 
      ? msg.content 
      : JSON.stringify(msg.content || '');
    
    // Check if adding this message would exceed the budget
    if (currentLength + content.length > chatBudget) {
      // If this is the only message and it's too long, truncate it
      if (pruned.length === 0) {
        const truncated = content.slice(0, chatBudget - 35) + '... [truncated for canvas limit]';
        pruned.unshift({ role: msg.role, content: truncated });
      }
      break; // Stop adding older messages
    }
    
    // Add this message to the beginning (since we're working backwards)
    pruned.unshift({ role: msg.role, content });
    currentLength += content.length;
  }

  // Ensure we have at least one user message
  if (pruned.length === 0 || !pruned.some(m => m.role === 'user')) {
    const lastUserTurn = nonSystem.find(m => m.role === 'user') || nonSystem[nonSystem.length - 1];
    const userContent = typeof lastUserTurn?.content === 'string'
      ? lastUserTurn.content
      : JSON.stringify(lastUserTurn?.content || 'Hello');
    
    const truncated = userContent.length > chatBudget 
      ? userContent.slice(0, chatBudget - 35) + '... [truncated for canvas limit]'
      : userContent;
    
    pruned.push({ role: 'user', content: truncated });
  }

  // Add system message at the beginning if it exists
  const result = [];
  if (sanitizedSystem) {
    result.push({ role: 'system', content: sanitizedSystem });
  }
  result.push(...pruned);
  
  return result;
}

// ── Test Suite ──────────────────────────────────────────────────────────────────

console.log('═══════════════════════════════════════════════════════');
console.log('   Canvas Bridge History Preservation Test Suite');
console.log('═══════════════════════════════════════════════════════');

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    console.log(`✅ ${name}`);
    passed++;
  } catch (err) {
    console.log(`❌ ${name}`);
    console.log(`   ${err.message}`);
    failed++;
    failures.push({ name, error: err.message });
  }
}

// ── Test 1: Simple 2-turn conversation fits entirely ───────────────────────────

test('Preserves full 2-turn conversation when under limit', () => {
  const messages = [
    { role: 'user', content: 'Hello, how are you?' },
    { role: 'assistant', content: 'I am doing well, thank you!' },
    { role: 'user', content: 'Can you help me with a task?' }
  ];
  
  const result = prunePayloadForCanvas(messages, 1500);
  
  assert.strictEqual(result.length, 3, 'Should preserve all 3 messages');
  assert.strictEqual(result[0].content, 'Hello, how are you?');
  assert.strictEqual(result[1].content, 'I am doing well, thank you!');
  assert.strictEqual(result[2].content, 'Can you help me with a task?');
});

// ── Test 2: Long conversation truncates oldest messages ────────────────────────

test('Truncates oldest messages when conversation exceeds limit', () => {
  const messages = [
    { role: 'user', content: 'Message 1: ' + 'x'.repeat(400) },
    { role: 'assistant', content: 'Response 1: ' + 'y'.repeat(400) },
    { role: 'user', content: 'Message 2: ' + 'z'.repeat(400) },
    { role: 'assistant', content: 'Response 2: ' + 'a'.repeat(400) },
    { role: 'user', content: 'Latest message' }
  ];
  
  const result = prunePayloadForCanvas(messages, 1500);
  
  // Should keep most recent messages that fit
  assert.ok(result.length > 0, 'Should have at least one message');
  assert.ok(result.some(m => m.content === 'Latest message'), 'Should preserve latest message');
  
  // Oldest messages should be dropped
  assert.ok(!result.some(m => m.content.includes('Message 1')), 'Should drop oldest message');
  
  // Total length should be under limit
  const totalChars = result.map(m => m.content).join('').length;
  assert.ok(totalChars <= 1500, `Total chars (${totalChars}) should be under 1500`);
});

// ── Test 3: Preserves system message separately ────────────────────────────────

test('Preserves system message with capped length', () => {
  const messages = [
    { role: 'system', content: 'You are a helpful assistant. ' + 'x'.repeat(300) },
    { role: 'user', content: 'Hello' },
    { role: 'assistant', content: 'Hi there!' },
    { role: 'user', content: 'How are you?' }
  ];
  
  const result = prunePayloadForCanvas(messages, 1500);
  
  assert.strictEqual(result[0].role, 'system', 'System message should be first');
  assert.ok(result[0].content.length <= 200, 'System message should be capped at 200 chars');
  assert.ok(result.length > 1, 'Should have conversation messages after system');
});

// ── Test 4: Handles multi-turn back-and-forth ──────────────────────────────────

test('Preserves multi-turn back-and-forth conversation', () => {
  const messages = [
    { role: 'user', content: 'Turn 1 user' },
    { role: 'assistant', content: 'Turn 1 assistant' },
    { role: 'user', content: 'Turn 2 user' },
    { role: 'assistant', content: 'Turn 2 assistant' },
    { role: 'user', content: 'Turn 3 user' },
    { role: 'assistant', content: 'Turn 3 assistant' },
    { role: 'user', content: 'Turn 4 user' }
  ];
  
  const result = prunePayloadForCanvas(messages, 1500);
  
  // All messages fit, should preserve all
  assert.strictEqual(result.length, 7, 'Should preserve all messages when under limit');
  
  // Verify order is maintained
  assert.strictEqual(result[0].content, 'Turn 1 user');
  assert.strictEqual(result[6].content, 'Turn 4 user');
});

// ── Test 5: Handles edge case of very long single message ──────────────────────

test('Truncates single very long message', () => {
  const messages = [
    { role: 'user', content: 'x'.repeat(3000) } // Way over limit
  ];
  
  const result = prunePayloadForCanvas(messages, 1500);
  
  assert.strictEqual(result.length, 1, 'Should have one message');
  assert.ok(result[0].content.length < 1500, 'Should truncate to under limit');
  assert.ok(result[0].content.includes('[truncated for canvas limit]'), 'Should mark as truncated');
});

// ── Test 6: Preserves most recent N turns that fit ─────────────────────────────

test('Preserves most recent turns that fit within budget', () => {
  const messages = [
    { role: 'user', content: 'Old message 1: ' + 'x'.repeat(100) },
    { role: 'assistant', content: 'Old response 1: ' + 'y'.repeat(100) },
    { role: 'user', content: 'Old message 2: ' + 'z'.repeat(100) },
    { role: 'assistant', content: 'Old response 2: ' + 'a'.repeat(100) },
    { role: 'user', content: 'Recent' },
    { role: 'assistant', content: 'Recent response' },
    { role: 'user', content: 'Latest' }
  ];
  
  const result = prunePayloadForCanvas(messages, 100); // Very tight limit - forces dropping old messages
  
  // Should keep most recent messages
  assert.ok(result.some(m => m.content === 'Latest'), 'Should keep latest');
  
  // Should NOT keep the oldest long messages
  const hasOld = result.some(m => m.content.includes('Old message 1'));
  assert.ok(!hasOld, 'Should drop oldest messages to fit budget');
});

// ── Test 7: Empty messages array ───────────────────────────────────────────────

test('Handles empty messages array gracefully', () => {
  const result = prunePayloadForCanvas([], 1500);
  
  assert.strictEqual(result.length, 1, 'Should return default message');
  assert.strictEqual(result[0].role, 'user');
  assert.strictEqual(result[0].content, 'Hello');
});

// ── Test 8: Realistic Kiro IDE conversation with context ───────────────────────

test('Handles realistic Kiro IDE conversation with tool results', () => {
  const messages = [
    { role: 'system', content: 'You are Kiro, an AI assistant that helps with coding.' },
    { role: 'user', content: 'Read the file main.js' },
    { role: 'assistant', content: '[Reading file...]' },
    { role: 'user', content: 'Now fix the bug on line 42' },
    { role: 'assistant', content: 'I\'ll fix the null reference error.' },
    { role: 'user', content: 'Test the changes' }
  ];
  
  const result = prunePayloadForCanvas(messages, 1500);
  
  // Should preserve system + recent conversation
  assert.strictEqual(result[0].role, 'system', 'System message first');
  assert.ok(result.some(m => m.content === 'Test the changes'), 'Latest user message preserved');
  assert.ok(result.length >= 2, 'Should have system + conversation messages');
});

// ── Summary ─────────────────────────────────────────────────────────────────────

console.log('═══════════════════════════════════════════════════════');
console.log('   Test Summary');
console.log('═══════════════════════════════════════════════════════');
console.log(`✅ Passed:  ${passed}`);
console.log(`❌ Failed:  ${failed}`);
console.log(`📊 Total:   ${passed + failed}`);
console.log(`📈 Success: ${Math.round(passed / (passed + failed) * 100)}%`);

if (failed > 0) {
  console.log('\nFailed Tests:');
  failures.forEach(f => {
    console.log(`  ❌ ${f.name}`);
    console.log(`     ${f.error}`);
  });
  process.exit(1);
} else {
  console.log('\n🎉 All tests passed! Canvas Bridge now preserves conversation history.');
  console.log('\nKey Improvements:');
  console.log('  ✅ Preserves multiple turns when they fit');
  console.log('  ✅ Drops oldest messages first when over limit');
  console.log('  ✅ Always includes latest user message');
  console.log('  ✅ Respects Canvas auth limits (1500 chars)');
  process.exit(0);
}
