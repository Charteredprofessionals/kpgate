@echo off
REM KiroProxy Gateway Launcher v2.8.0
REM Starts the proxy server with ngrok tunnel support

echo ========================================
echo   KiroProxy Gateway Launcher v2.8.0
echo ========================================
echo.

REM Load environment variables from .env
if not exist .env (
    if exist .env.template (
        echo [*] .env not found. Creating from .env.template...
        copy ".env.template" ".env" >nul
        echo [OK] .env created from template.
    )
)

if exist .env (
    echo [*] Loading environment variables from .env...
    for /f "usebackq tokens=1,2 delims==" %%a in (".env") do (
        if not "%%b"=="" (
            set "%%a=%%b"
        )
    )
)

REM Check if node is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] Error: Node.js is not installed
    echo [!] Install from: https://nodejs.org/
    pause
    exit /b 1
)

REM Check if dependencies are installed
if not exist node_modules (
    echo [*] Installing dependencies...
    call npm install
    if %errorlevel% neq 0 (
        echo [!] Error: Failed to install dependencies
        pause
        exit /b 1
    )
)

REM Patch the Kiro IDE extension (re-applies after IDE updates)
echo [*] Patching Kiro IDE extension for proxy routing...
node scripts/patch_kiro_extension.js
if %errorlevel% neq 0 (
    echo [!] Warning: Extension patch failed - proxy may not receive IDE prompts
    echo [!] Try running: node scripts/patch_kiro_extension.js manually
)
echo.

REM Start the modular proxy server
echo [*] Starting KiroProxy Gateway (Modular src/index.js)...
echo [*] Press Ctrl+C to stop
echo [*] In Kiro IDE: Press Ctrl+Shift+P -^> "Developer: Reload Window"
echo.

node src/index.js

pause
