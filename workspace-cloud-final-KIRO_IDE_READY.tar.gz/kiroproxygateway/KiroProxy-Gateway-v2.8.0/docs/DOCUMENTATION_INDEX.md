# KiroProxy Gateway — Documentation Index

**Version:** 2.8.0  
**Status:** ✅ Canonical & Streamlined  
**Last Updated:** October 11, 2026

This central index organizes all project documentation into 4 distinct tiers: AI Maintenance, Developer & Setup Guides, Architecture Deep-Dives, and Project Governance.

---

## 🎯 Quick Navigation

- **For AI Coding Assistants:** Start with [`AGENTS.md`](file:///d:/sdlc_studio/projects/kiro-integration/AGENTS.md) and [`docs/change-impact.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/change-impact.md).
- **For First-Time Developers:** Start with [`docs/guides/QUICK_START_v2.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/guides/QUICK_START_v2.md) and [`start.bat`](file:///d:/sdlc_studio/projects/kiro-integration/start.bat).
- **For Debugging & Incidents:** Check [`docs/troubleshooting.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/troubleshooting.md) and [`docs/invariants-and-gotchas.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/invariants-and-gotchas.md).

---

## 🏛️ Tier 1: AI Maintenance & Core System Contracts

*Every claim is labeled `[FACT]`, `[INFERRED]`, or `[UNKNOWN]` and cites file paths and line numbers.*

| Document | Purpose | Read This When... |
| :--- | :--- | :--- |
| [`AGENTS.md`](file:///d:/sdlc_studio/projects/kiro-integration/AGENTS.md) | Master AI Operating Manual | Opening the project in an AI coding tool (< 150 lines). |
| [`docs/system-map.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/system-map.md) | Component Topology & Data Flow | Understanding the full request lifecycle and module coupling. |
| [`docs/change-impact.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/change-impact.md) | Blast Radius & Regression Matrix | **Before editing any code** — check blast radius and required tests. |
| [`docs/invariants-and-gotchas.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/invariants-and-gotchas.md) | Hard Invariants & Non-Obvious Traps | Understanding CRC32 framing, Windows path escapes, or gotchas. |
| [`docs/troubleshooting.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/troubleshooting.md) | Symptom → Cause → Fix Matrix | Investigating raw tool text leaks, empty responses, or 503 errors. |
| [`docs/data-model.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/data-model.md) | In-Memory State & Queue Models | Working with `MODELS.models`, `geminiQueue`, or circuit breakers. |
| [`docs/api-contracts.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/api-contracts.md) | Wire Protocol Specifications | Modifying AWS Smithy endpoints, EventStream frames, or Canvas Bridge. |
| [`docs/config-and-env.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/config-and-env.md) | Environment Variables & Config Schemas | Adding or modifying API keys, feature flags, or custom providers. |
| [`docs/testing.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/testing.md) | Testing Strategy & Suite Matrix | Executing or updating any of the 17 test suites in `tests/`. |
| [`docs/tech-debt.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/tech-debt.md) | Bottlenecks & Refactoring Roadmap | Identifying technical debt, monolith hotspots, or scaling limits. |
| [`docs/open-questions.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/open-questions.md) | Unresolved Architectural Questions | Reviewing items requiring human engineering confirmation. |
| [`docs/decisions/`](file:///d:/sdlc_studio/projects/kiro-integration/docs/decisions/) | Architecture Decision Records (ADRs) | Reviewing ADR-0001 (Dual Patching), ADR-0002 (EventStream), ADR-0003 (Failover), ADR-0004 (Bare JSON). |

---

## 🚀 Tier 2: Developer & Setup Guides

| Guide | Description |
| :--- | :--- |
| [`docs/guides/QUICK_START_v2.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/guides/QUICK_START_v2.md) | 1-minute launch and extension patching guide. |
| [`docs/CONFIGURATION_GUI.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/CONFIGURATION_GUI.md) | Using the visual browser configuration dashboard (`/config`). |
| [`docs/setup/KIRO_IDE_INTEGRATION_GUIDE.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/setup/KIRO_IDE_INTEGRATION_GUIDE.md) | Step-by-step setup and dual-mode patching instructions. |
| [`docs/setup/NGROK_SETUP_GUIDE.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/setup/NGROK_SETUP_GUIDE.md) | Setting up Ngrok tunnels for remote access and Canvas Bridge. |
| [`docs/setup/GEMINI_CANVAS_BRIDGE_SETUP.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/setup/GEMINI_CANVAS_BRIDGE_SETUP.md) | Browser userscript setup for zero-cost Gemini models. |
| [`docs/guides/MULTI_TOOL_SUPPORT.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/guides/MULTI_TOOL_SUPPORT.md) | Multi-tool invocation and tool translation specifications. |
| [`docs/guides/GLOBAL_AUTOMODE_GUIDE.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/guides/GLOBAL_AUTOMODE_GUIDE.md) | Understanding the 6-tier fallback and Otomode failover. |

---

## 📐 Tier 3: Architecture Deep-Dives

| Deep Dive | Area |
| :--- | :--- |
| [`docs/architecture/KIRO_GATEWAY_ARCHITECTURE_GUIDE.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/architecture/KIRO_GATEWAY_ARCHITECTURE_GUIDE.md) | End-to-end architecture overview. |
| [`docs/architecture/AUTO_FALLBACK_SYSTEM.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/architecture/AUTO_FALLBACK_SYSTEM.md) | Circuit breakers and multi-tier failover mechanics. |
| [`docs/architecture/CUSTOM_PROVIDER_AUTO_DISCOVERY.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/architecture/CUSTOM_PROVIDER_AUTO_DISCOVERY.md) | OpenAI-compatible custom provider auto-discovery. |
| [`docs/architecture/MODEL_AUTO_POPULATION_SPEC.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/architecture/MODEL_AUTO_POPULATION_SPEC.md) | Dynamic upstream model catalog discovery. |
| [`docs/architecture/AWS_PROTOCOL_COMPLIANCE_AUDIT.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/architecture/AWS_PROTOCOL_COMPLIANCE_AUDIT.md) | AWS Smithy / Bedrock compliance verification. |

---

## 📋 Tier 4: Project Governance & Archives

| Document | Topic |
| :--- | :--- |
| [`docs/project-management/HANDOVER.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/project-management/HANDOVER.md) | Complete engineering handover manual. |
| [`docs/project-management/PROJECT_STATUS_v2.8.0.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/project-management/PROJECT_STATUS_v2.8.0.md) | Milestone verification and release status. |
| [`docs/project-management/PROJECT_AUDIT_REPORT.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/project-management/PROJECT_AUDIT_REPORT.md) | Comprehensive security and reliability audit. |
| [`docs/project-management/RELEASE_CHECKLIST.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/project-management/RELEASE_CHECKLIST.md) | Pre-flight release verification checklist. |
| [`docs/project-management/RELEASE_NOTES.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/project-management/RELEASE_NOTES.md) | Current release release notes. |
| [`docs/archive/incident-reports/`](file:///d:/sdlc_studio/projects/kiro-integration/docs/archive/incident-reports/) | Historical incident reports and post-mortems (v2.4 - v2.7). |
| [`docs/archive/`](file:///d:/sdlc_studio/projects/kiro-integration/docs/archive/) | Archived edge case audits and historical research. |
