# Workflows and KiroProxy Gateway - Complete Guide

**Question:** Can I use the `feature-pipeline` workflow with KiroProxy Gateway?  
**Answer:** ❌ NO - Workflows are NOT supported in proxy mode  
**Alternative:** ✅ YES - Use direct execution with Kiro IDE's native capabilities

---

## 🎯 Quick Answer

### Feature-Pipeline Workflow
```
feature-pipeline
├── 6 steps (setup → requirements → design-loop → plan → code-loop → validate)
├── Review loops (max 3 iterations)
├── Parallel reviews (Claude Fable 5 + GPT 5.6)
└── Fail-closed validation gate
```

**Status with KiroProxy Gateway:** ❌ **NOT SUPPORTED**

### Why Not Supported?

Workflows like `feature-pipeline` require:
1. **Cloud Infrastructure** - State storage, job orchestration
2. **Multi-Agent Coordination** - Multiple AI models in parallel
3. **Workflow Runtime** - Session management, loop control
4. **AWS Integration** - Native Kiro Cloud APIs

**KiroProxy Gateway provides:**
- ✅ Model inference (8 providers, 186 models)
- ✅ Tool execution (file ops, terminal, MCP)
- ✅ Direct AI responses
- ❌ **NO workflow orchestration**

---

## 🏗️ Architecture: Why Workflows Don't Work

### Kiro Cloud Mode (Native AWS) ✅

```
┌────────────────────────────────────────────────────────────┐
│                    Kiro IDE Agent                          │
│  "I need to build a complex feature"                       │
└─────────────────────────┬──────────────────────────────────┘
                          ↓
                  run_workflow(feature-pipeline)
                          ↓
┌────────────────────────────────────────────────────────────┐
│            AWS Kiro Runtime Service (Cloud)                │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Workflow Orchestrator                               │  │
│  │  • 

...[content truncated to maintain performance]...
 mode: "cloud")
2. Restart Kiro IDE
3. Sign in to AWS
4. Workflows available ✅

**To Proxy:**
1. Restore `.kiro/config.json` (mode: "proxy")
2. Restart Kiro IDE
3. Proxy-mode steering loads
4. Direct execution active ✅

---

## 📚 Related Documentation

- **[Why Workflows Fail in Proxy](../troubleshooting/WHY_WORKFLOWS_FAIL_IN_PROXY.md)** - Technical deep dive
- **[Proxy Mode Steering](../.kiro/steering/proxy-mode.md)** - Configuration file
- **[Kiro IDE Integration](../setup/KIRO_IDE_INTEGRATION_GUIDE.md)** - Setup guide
- **[Quick Start](QUICK_START_v2.md)** - Getting started

---

## 🎯 Summary

| Question | Answer |
|----------|--------|
| **Can I use feature-pipeline with proxy?** | ❌ NO |
| **Why not?** | Workflows require cloud infrastructure |
| **Alternative?** | ✅ Direct execution (iterative development) |
| **Quality difference?** | Cloud: automated reviews / Proxy: manual reviews |
| **Cost difference?** | Cloud: $$$ subscription / Proxy: FREE |
| **Is direct execution worse?** | Different, not worse - more hands-on |
| **Configuration needed?** | ✅ Already done (proxy-mode.md steering) |
| **Can I switch between modes?** | ✅ YES (change config.json) |

---

**Bottom Line:** 

KiroProxy Gateway provides **FREE AI access** with **direct execution**.  
For **automated workflows**, use **Kiro Cloud subscription**.  
Both are valid - choose based on your needs and budget.

---

**Last Updated:** 2026-10-08  
**Version:** 2.8.0  
**Status:** Proxy mode fully documented ✅