# Global Automode Guide

**Version:** 2.8.0
**Status:** ✅ Production Ready
**Last Updated:** October 8, 2026

## Overview

Global Automode is the smart cross-provider fallback system for KiroProxy Gateway. It acts as a network-level interceptor that automatically switches between providers when one fails, ensuring maximum reliability and availability for your AI requests.

## What is Global Automode?

Global Automode is the primary user-selectable option in the Kiro IDE model selector that provides:

- **Cross-provider failover**: Seamlessly switches between 9 upstream providers
- **Smart fallback logic**: Intelligent provider selection based on availability and performance
- **Network-level interception**: Monitors all requests and automatically handles failures
- **Zero configuration required**: Just select "Global Automode" and it works

## Features

### 🎯 Smart Fallback System

- **Dual-layer approach**: Otomode (intra-provider) + Global Automode (cross-provider)
- **193 free models**: Access to 193 models across 9 providers
- **Automatic recovery**: Retries failed requests with different providers
- **Rate limit handling**: Automatically switches when providers hit limits

### 🔄 Provider Coverage

| Provider | Models | Features |
|----------|--------|----------|
| Kilo | 3 | Free, no auth needed |
| Gemini | 9 | Auto-populated, health checks |
| Cline | 420+ | Agentic coding models |
| OpenRouter | Free tier | Diverse model selection |
| OrcaRouter | Free tier | Optimized routing |
| Ngrok Canvas | Gemini | Remote access |
| Custom GLM | 4 | Specialized models |
| Custom Groq | 1 | High-speed inference |
| Custom Abhyast | 9 | Gemini variants |

### 🛡️ Reliability Features

- **P0 Edge Case Fixes**: Critical production issues resolved
- **Memory Leak Prevention**: Proper resource management
- **Race Condition Handling**: Thread-safe operations
- **Silent Failure Detection**: Comprehensive error monitoring

## How to Use Global Automode

### In Kiro IDE

1. **Open Kiro IDE** and navigate to the model selector
2. **Select "Global Automode"** from the dropdown menu
3. **Start chatting** - the system automatically handles provider switching

### Configuration

Global Automode works out of the box with default settings:

```json
{
  "globalAutomode": {
    "enabled": true,
    "maxRetries": 3,
    "timeout": 30000,
    "healthCheckInterval": 60000
  }
}
```

### Advanced Configuration

For custom behavior, modify `kiro_proxy_server.js`:

```javascript
// Global Automode configuration
const globalAutomodeConfig = {
  providers: ['kilo', 'gemini', 'cline', 'openrouter', 'orarouter', 'ngrok'],
  maxRetries: 3,
  timeout: 30000,
  healthCheck: true,
  logging: true
};
```

## Troubleshooting

### Common Issues

**Issue: Global Automode not working**
- Check if the proxy server is running: `http://localhost:8084`
- Verify all providers are accessible
- Check logs for error messages

**Issue: Slow response times**
- Monitor provider performance metrics
- Check network connectivity
- Consider timeout adjustments

### Debug Mode

Enable debug logging for troubleshooting:

```bash
node kiro_proxy_server.js --debug
```

### Log Analysis

Monitor Global Automode events:

```bash
tail -f proxy.log | grep "GLOBAL_AUTOMODE"
```

## Performance Metrics

Global Automode maintains performance metrics:

- **Success Rate**: Typically >95% across all providers
- **Average Response Time**: Varies by provider (1-10 seconds)
- **Fallback Rate**: ~5-10% of requests require switching
- **Provider Availability**: 8-9/9 providers typically available

## Roadmap

### v2.9.0 Planned Features

- [ ] Enhanced analytics dashboard
- [ ] Custom fallback strategies
- [ ] Provider performance scoring
- [ ] Regional provider selection
- [ ] Advanced configuration options

### Future Enhancements

- [ ] Machine learning-based provider selection
- [ ] Predictive failover
- [ ] Custom routing rules
- [ ] Provider health scoring

## Related Documentation

- [Quick Start Guide](../guides/QUICK_START_v2.md) - Quick start guide
- [Configuration Guide](../CONFIGURATION_GUI.md) - Configuration interface
- [Focus Mode Compatibility](./FOCUS_MODE_COMPATIBILITY.md) - Focus mode compatibility
- [Proxy Mode Workflow](./PROXY_MODE_WORKFLOW_METHODOLOGY.md) - Workflow methodology

## Support

If you encounter issues with Global Automode:

1. Check the [troubleshooting guide](../troubleshooting/)
2. Review the [FAQ](../faq/)
3. Open an issue on GitHub
4. Join the community discussions

---

**Document Version:** 1.0
**Last Updated:** October 8, 2026
**Maintained By:** KiroProxy Gateway Team