# Proxy Mode Workflow Methodology Guide

**Date:** October 8, 2026  
**Version:** 2.7.0+  
**Status:** ✅ Active in `.kiro/steering/proxy-mode.md`

---

## 🎯 Overview

When using KiroProxy Gateway (local port 8084), programmatic workflow orchestration (`run_workflow`) is not available. However, AI agents can still follow **structured workflow discipline** through direct tool execution.

This guide documents the **5-Phase Manual Workflow Pattern** that agents follow when connected to the proxy.

---

## 🔄 The 5-Phase Workflow Pattern

```
┌─────────────────────────────────────────────────────────────┐
│                     USER REQUEST                            │
│              "Fix the bug in utils.js"                      │
└────────────────────┬────────────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────────────┐
│         PHASE 1: INVESTIGATION                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ • read_file("utils.js")                              │   │
│  │ • grep_search(query="error pattern")                 │   │
│  │ • read_code(path="utils.js", selector="function")    │   │
│  └──────────────────────────────────���───────────────────┘   │
│  Result: Problem identified, root cause understood          │
└────────────────────┬────────────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────────────┐
│         PHASE 2: PLANNING (Mental)                          │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ Agent thinks:                                        │   │
│  │ "This requires:                                      │   │
│  │  1. Fix type validation in parseInput()            

...[content truncated to maintain performance]...
3. **Follow the phases**: Agents will follow this pattern automatically
4. **Trust the process**: Investigation → Planning → Implementation → Verification

### For Agents
1. **Load steering**: `.kiro/steering/proxy-mode.md` auto-included
2. **Check condition**: If model is gateway provider, workflow tools forbidden
3. **Follow 5 phases**: Always investigate before implementing
4. **Use direct tools**: read_file, str_replace, execute_pwsh, etc.
5. **Verify thoroughly**: Run tests before reporting success

---

## 📖 Related Documentation

- **[Why Workflows Fail in Proxy](../troubleshooting/WHY_WORKFLOWS_FAIL_IN_PROXY.md)** - Technical explanation
- **[Proxy Mode Restored](PROXY_MODE_RESTORED.md)** - Compatibility layer details
- **[Unsupported Features](../UNSUPPORTED_FEATURES.md)** - Complete limitations list
- **[Kiro IDE Integration Guide](../setup/KIRO_IDE_INTEGRATION_GUIDE.md)** - Setup instructions

---

## 🎉 Summary

**Problem:** Proxy mode lacks programmatic workflow orchestration

**Solution:** Structured 5-phase manual workflow pattern via steering files

**Result:** Professional, organized, verifiable task completion without workflow engine

**User Experience:** Seamless - agents follow structured methodology automatically when connected to proxy

---

**Status:** ✅ **ACTIVE**  
**Location:** `.kiro/steering/proxy-mode.md`  
**Version:** 2.7.0+  
**Last Updated:** October 8, 2026

🎯 **KiroProxy Gateway: Direct execution with workflow discipline.**