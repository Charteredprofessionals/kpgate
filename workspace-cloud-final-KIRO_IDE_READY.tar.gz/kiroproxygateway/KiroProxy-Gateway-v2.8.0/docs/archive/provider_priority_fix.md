# Provider Priority Fix for global automode

### **Correct Implementation (v2.8.0-beta):**
```
1. Kilo ✅
2. Cline ✅
3. OpenRouter ✅
4. OrcaRouter ✅
5. Gemini ✅
6. Custom Providers (Groq, GLM, Abhyast-Gemini) ✅
```
#### **Global Automode order:**
> "Priority: Primary → Kilo free models→ Clinefree models → OpenRouter free models → OrcaRouter free models → Gemini free models → Custom Providers free models"

