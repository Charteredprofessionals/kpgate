# Model Selector Not Showing in Kiro IDE

## Problem

The model selector dropdown in Kiro IDE is empty or doesn't show the 436+ proxy models.

## Root Cause

Kiro IDE extension is not patched to use the proxy server. By default, Kiro IDE only shows AWS Cloud native models.

## Solution

### Step 1: Verify Proxy Server is Running

```bash
curl http://127.0.0.1:8084/health
```

Expected response:
```json
{
  "status": "ok",
  "providers": {
    "kilo": "healthy",
    "cline": "healthy",
    ...
  }
}
```

### Step 2: Check Patch Status

```bash
node scripts/patch_kiro_extension.js --check
```

**If you see:**
```
Patch 1 (Model list dynamic fallback) : ❌ NOT applied
```

Then continue to Step 3.

### Step 3: Apply the Patch

```bash
node scripts/patch_kiro_extension.js
```

**Expected output:**
```
✅ Backup created at: ...extension.js.original
✅ Patch 1: Dynamic dual-mode model list applied
✅ Patch 3B: Replaced runtime URL construction(s)
🎉 extension.js successfully patched (2 patches applied)
```

### Step 4: Restart Kiro IDE

1. **Close Kiro IDE completely**
   - Close all windows
   - Check Task Manager to ensure no Kiro processes are running
   
2. **Start Kiro IDE**

3. **Open a chat session**

4. **Click the model selector dropdown**

### Step 5: Verify Models Appear

You should now see 436+ models including:

- **auto** - Smart auto-fallback across all providers
- **kilogateway** - Free Gemma 4 26B (no API key needed)
- **kilo/*** - Kilo Gateway models
- **cline/*** - Cline agentic coding models
- **openrouter-free/*** - OpenRouter free tier
- **orca-*** - OrcaRouter free tier
- **ngrok-gemini-flash** - Zero-cost Gemini via Canvas Bridge

## Troubleshooting

### Models Still Not Showing After Patch

**Check if proxy is actually running:**
```bash
curl http://127.0.0.1:8084/listAvailableModels
```

This should return a large JSON with 436 models.

**Check Kiro IDE console logs:**
1. Open Kiro IDE
2. Press `Ctrl+Shift+I` (Developer Tools)
3. Go to Console tab
4. Look for errors related to model fetching

**Verify patch was applied correctly:**
```bash
node scripts/patch_kiro_extension.js --check
```

All patches should show ✅ APPLIED.

### Patch Command Fails

**Error: "extension.js not found"**

The patcher is looking for Kiro IDE at:
```
C:\Users\<username>\AppData\Local\Programs\Kiro\resources\app\extensions\kiro.kiro-agent\dist\extension.js
```

If Kiro IDE is installed elsewhere, you need to update the `EXT_DIR` path in `scripts/patch_kiro_extension.js`.

**Error: "Access denied"**

Run PowerShell or Command Prompt as Administrator.

### Restore Original Extension

If something goes wrong, restore the original:
```bash
node scripts/patch_kiro_extension.js --restore
```

This restores from the backup created before patching.

## How It Works

The patch modifies Kiro IDE's extension to:

1. **Check if proxy is running** (port 8084)
2. **If proxy is online:** Fetch models from `http://127.0.0.1:8084/listAvailableModels`
3. **If proxy is offline:** Use native AWS Cloud models (graceful fallback)

This is a **dynamic dual-mode** system - no manual switching needed!

## Testing Without Restarting IDE

After patching, you can test the endpoint directly:

```bash
# Test from PowerShell
Invoke-RestMethod -Uri "http://127.0.0.1:8084/listAvailableModels" | ConvertTo-Json -Depth 1
```

You should see:
```json
{
  "models": [
    {
      "modelId": "auto",
      "modelName": "AUTO Mode (Smart Fallback)",
      ...
    },
    ...
  ],
  "defaultModel": {
    "modelId": "auto"
  }
}
```

## Related Files

- `scripts/patch_kiro_extension.js` - The patcher script
- `docs/setup/KIRO_IDE_INTEGRATION_GUIDE.md` - Full integration guide
- `docs/CRITICAL_ROUTING_ORDER.md` - Server architecture

## Quick Fix Summary

```bash
# 1. Start proxy server
start.bat

# 2. Apply patch
node scripts/patch_kiro_extension.js

# 3. Restart Kiro IDE

# 4. Select a model and start chatting!
```

---

**Last Updated:** January 6, 2025  
**Status:** ✅ Working Solution
