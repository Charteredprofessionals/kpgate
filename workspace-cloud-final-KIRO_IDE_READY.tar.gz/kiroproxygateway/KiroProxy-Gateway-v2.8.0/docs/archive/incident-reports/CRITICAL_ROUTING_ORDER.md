# ⚠️ CRITICAL: REQUEST ROUTING ORDER — KiroProxy Gateway

## **DO NOT MODIFY WITHOUT READING THIS FIRST**

The order of endpoint handlers in `scripts/kiro_proxy_server.js` is **CRITICAL**. Incorrect ordering will break the Canvas Bridge and cause silent failures where requests are intercepted by AWS catch-all handlers and never reach the browser bridge.

---

## 🔴 MANDATORY ROUTING ORDER

The request handlers in `scripts/kiro_proxy_server.js` **MUST** follow this exact sequence:

### 1. **CORS Preflight (OPTIONS)**
```javascript
if (method === 'OPTIONS') {
  // Handle CORS preflight requests first (with dynamic origin reflection and 69420 header)
}
```

### 2. **AWS Bedrock Specific Endpoints**
```javascript
// /v1/messages (AWS converse endpoint)
// /generateAssistantResponse (Converse binary streaming)
// /taskassist/* (task management)
// /spaces, /userdata, etc.
```

### 3. **🚨 CANVAS BRIDGE ENDPOINTS 🚨**
```javascript
// ── Browser Bridge Endpoints (Gemini Userscript / Canvas Protocol) ──────
// CRITICAL: These MUST come BEFORE the AWS Bedrock catch-all!

// /canvas - Serve Canvas Bridge dashboard (with inline HTML fallback)
// /poll   - Canvas polls for work
// /chunk  - Canvas sends streaming chunks  
// /done   - Canvas signals completion ⚠️ CRITICAL
// /cancel - Canvas cancels request
```

**⚠️ WARNING:** If these endpoints come AFTER the AWS catch-all, they will NEVER execute!

### 4. **AWS Universal Catch-All Handler**
```javascript
// 12. Universal AWS Cloud Catch-All (Zero 404s, 100% Protocol Compliance)
// Positioned AFTER Canvas Bridge endpoints to avoid intercepting them
if (shouldLogAwsCatchall) {
  console.log(`[KiroProxy] AWS Catch-all handler for ${method} ${req.url}`);
}
```

### 5. **Health, Status & Config Endpoints**
```javascript
// /health, /status, /config
```

---

## 🔥 WHAT HAPPENS IF ORDER IS WRONG

**Symptom:** Canvas Bridge silently hangs or times out after 120 seconds.
- Canvas polls `/poll` successfully ✅
- Canvas receives work from queue ✅
- Canvas processes request and calls `/done` ❌
- Server logs: `[KiroProxy] AWS Catch-all handler for POST /done`
- Request **NEVER** reaches `handleBridgeDone()`
- User sees: "Failed to fetch" or hanging prompt in Kiro IDE.

**Invariant:** In `scripts/kiro_proxy_server.js`, every `/canvas` route is explicitly return-terminated (`return;`), guaranteeing that it never falls into `sendAwsResponse`.

---

## 📋 VERIFICATION COMMANDS

Verify Canvas Bridge routing and health:
```bash
# Verify health
curl -s http://127.0.0.1:8084/health

# Verify /canvas returns HTML dashboard (not AWS JSON)
curl -s -I http://127.0.0.1:8084/canvas

# Verify /poll responds with HTTP 200 JSON
curl -s http://127.0.0.1:8084/poll -H "Origin: https://gemini.google.com" -H "ngrok-skip-browser-warning: 69420"
```

---

*KiroProxy Gateway v2.7.0 — Architectural Invariants & Routing Governance.*
