# Ngrok Architecture - Port 8084 Architecture & Port 8083 Decommissioning ✅

**Date:** October 7, 2026  
**Status:** ✅ **PORT 8084 EXCLUSIVE - PORT 8083 FULLY REMOVED**

---

## TL;DR - Current Architecture

1. **The proxy runs exclusively on Port 8084**: Main server, endpoints, and ngrok tunnel forward port 8084.
2. **Legacy Port 8083 has been completely removed**: All references to `Legacy Port 8083: Forwards to main server on port 8084` and the secondary compatibility bridge server have been permanently removed from the codebase.
3. **No secondary port listening**: KiroProxy Gateway binds only to `127.0.0.1:8084`.

---

## Port Architecture

```
┌─────────────────────────────────────────────┐
│  Kiro Proxy Server Architecture             │
├─────────────────────────────────────────────┤
│                                             │
│  Port 8084 (Main Server - Exclusive)        │
│  ├─ GenerateAssistantResponse               │
│  ├─ ListAvailableModels                     │
│  ├─ InvokeMCP                               │
│  ├─ Health, Status, Metrics                 │
│  ├─ Canvas Bridge Dashboard & Endpoints     │
│  └─ Workflow Compatibility Layer            │
│                                             │
│  ↑                                          │
│  │ Ngrok tunnels THIS port (8084)           │
│  │                                          │
│  🌐 https://xxxx.ngrok-free.app → 8084      │
│                                             │
└─────────────────────────────────────────────┘
```

---

## Code Status

### Main Server Configuration

```javascript
server.listen(PROXY_PORT, '127.0.0.1', async () => {
  console.log(`Running at http://127.0.0.1:${PROXY_PORT}`);
});
```

### Ngrok Tunnel Configuration

```javascript
const listener = await ngrok.forward({ 
  addr: PROXY_PORT,  // PROXY_PORT = 8084
  authtoken: token 
});
```

### Legacy Port 8083 Bridge

- **Status**: Completely removed.
- **Reason**: Redundant and caused confusion regarding which port ngrok was exposing.
- **Current Behavior**: Port 8083 is no longer bound or referenced anywhere in server startup or logs.

---

## Summary Table

| Aspect | Port 8084 | Port 8083 (Legacy) |
|--------|-----------|-------------------|
| **Status** | Active (Primary) | Decommissioned / Removed |
| **Purpose** | Main proxy server | Formerly compatibility forwarder |
| **Ngrok Tunnel** | ✅ YES (Tunneled) | ❌ N/A (Removed) |
| **Features** | All proxy features | None |
| **Access** | localhost + ngrok | None |

---

**Status:** ✅ **PORT 8084 SINGLE PORT ARCHITECTURE CONFIRMED**  
