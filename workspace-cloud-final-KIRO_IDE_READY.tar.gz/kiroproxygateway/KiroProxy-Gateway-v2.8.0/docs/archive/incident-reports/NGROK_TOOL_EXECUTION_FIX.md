# Ngrok Tool Execution Fix

## Issue Description
When using the Ngrok-Gemini bridge with Kiro IDE, tool executions (specifically `list_directory`) were failing repeatedly with the error:
```
Invalid input for list_directory — path: expected string, received null
```

The tool was being called 7+ times in a loop without success.

## Root Cause
The issue was in the **Gemini-to-Kiro translation layer** in `kiro_proxy_server.js`:

1. **Missing `.env` loading**: The `dotenv` package was installed but never loaded, so `process.env.WORKSPACE_ROOT` was always undefined
2. **Invalid default path**: When Gemini sent `list_directory` without a path parameter (or with `.`), the normalization function defaulted to `'.'` (relative path)
3. **Kiro requirement**: Kiro's `list_directory` tool requires an **absolute path**, not a relative one

## The Fix

### 1. Load Environment Variables
Added `dotenv` configuration at the top of `kiro_proxy_server.js`:

```javascript
'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const zlib = require('zlib');
const os = require('os');

// ── Load environment variables from .env file ──────────────────────────────────
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
```

### 2. Fixed Path Normalization
Updated the `normalizeGeminiToolCalls()` function (around line 3410):

**Before:**
```javascript
if (name === 'list_directory') {
  const p = args.path || args.directory || args.dir || args.folder || args.target;
  if (!p) {
    console.warn(`[KiroProxy] ⚠️  list_directory missing path from Gemini — defaulting to "."`);
    args.path = '.';  // ❌ INVALID - relative path
  } else {
    args.path = p;
  }
  if (!args.explanation) args.explanation = `Listing ${args.path}`;
}
```

**After:**
```javascript
if (name === 'list_directory') {
  const p = args.path || args.directory || args.dir || args.folder || args.target;
  if (!p || p === '.') {
    // list_directory requires absolute path - default to workspace root
    const workspaceRoot = process.env.WORKSPACE_ROOT || process.cwd();
    console.warn(`[KiroProxy] ⚠️  list_directory missing/relative path from Gemini — defaulting to workspace root: ${workspaceRoot}`);
    args.path = workspaceRoot;  // ✅ VALID - absolute path
  } else {
    args.path = p;
  }
  if (!args.explanation) args.explanation = `Listing contents of ${args.path}`;
}
```

### 3. Added WORKSPACE_ROOT Configuration
Updated `.env` file:

```env
# Workspace Configuration
WORKSPACE_ROOT=d:\sdlc_studio\projects\kiro-integration
```

Updated `.env.template` file:

```env
# Workspace Configuration
# Set this to your project's root directory (where Kiro IDE operates)
WORKSPACE_ROOT=d:\your\project\path
```

## Testing the Fix

1. **Stop the current proxy server** (if running):
   ```powershell
   Get-Process -Name node -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*kiro_proxy_server.js*" } | Stop-Process -Force
   ```

2. **Start the proxy server**:
   ```powershell
   cd d:\sdlc_studio\projects\kiro-integration
   .\start.bat
   ```

3. **Verify the fix**:
   - Check the console logs for: `[KiroProxy] ⚠️  list_directory missing/relative path from Gemini — defaulting to workspace root: d:\sdlc_studio\projects\kiro-integration`
   - Tool calls should now succeed instead of looping

## Technical Details

### Why This Happens with Gemini
Gemini's function calling API sometimes omits optional parameters or sends simplified arguments. The translation layer needs to:
1. **Detect missing/invalid arguments**
2. **Apply sensible defaults** that match Kiro's requirements
3. **Normalize aliases** (e.g., `directory`, `dir`, `folder` → `path`)

### Fallback Strategy
```javascript
const workspaceRoot = process.env.WORKSPACE_ROOT || process.cwd();
```

- **Primary**: Use `WORKSPACE_ROOT` from `.env`
- **Fallback**: Use Node.js `process.cwd()` (current working directory)

This ensures the fix works even if `.env` is misconfigured.

## Related Files Modified
- `scripts/kiro_proxy_server.js` - Added dotenv loading and fixed path normalization
- `.env` - Added `WORKSPACE_ROOT` configuration
- `.env.template` - Added `WORKSPACE_ROOT` documentation

## Version
- **Fixed in**: v2.7.1
- **Date**: 2026-10-06
- **Issue**: Ngrok tool execution loop failure
- **Impact**: High (blocked all Gemini-Canvas bridge tool usage)
