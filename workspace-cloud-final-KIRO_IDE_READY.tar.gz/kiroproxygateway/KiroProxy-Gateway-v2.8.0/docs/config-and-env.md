# Configuration and Environment Variables — KiroProxy Gateway v2.8.0

**Target Application:** `kiroproxy-gateway`  
**Primary Files:** [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), `config/*.json`, `.kiro/config.json`, `.env`  
**Config Precedence:** Local Config (`config/custom_config.json`) > Project Config (`.kiro/config.json`) > Environment Variables (`process.env`) > Defaults.

---

## 1. Environment Variables Specification

*Never commit actual secret values to source control. Use `.env` or system environment variables.*

| Variable Name | Purpose | Where Used (Code Ref) | Required? | What Breaks if Missing or Wrong |
| :--- | :--- | :--- | :--- | :--- |
| `PROXY_PORT` | HTTP port on which the local gateway listens. | [`scripts/kiro_proxy_server.js#L66`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No (Default: `8084`) | If set to an invalid port or in-use port, server crashes on startup with `EADDRINUSE`. If changed without updating `config/kiro_ai_config.json`, Kiro IDE cannot connect. |
| `KILO_API_KEY` | Optional bearer token for Kilo Gateway upstream. | [`scripts/kiro_proxy_server.js#L609`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No (Kilo supports zero-key free tier) | If wrong, Kilo returns 401 Unauthorized; gateway fails over to Cline. |
| `CLINE_API_KEY` | Authentication key for Cline API upstream. | [`scripts/kiro_proxy_server.js#L615`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No (Required only for `cline-*` tier) | If missing when `cline-*` model selected, calls fail with 401; Global Automode skips to OpenRouter. |
| `OPENROUTER_API_KEY` | Authentication key for OpenRouter upstream. | [`scripts/kiro_proxy_server.js#L621`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No (Required only for `openrouter-*` tier) | If missing, OpenRouter models return 401; Global Automode skips to OrcaRouter. |
| `ORCAROUTER_API_KEY` | Primary API key for OrcaRouter upstream. | [`scripts/kiro_proxy_server.js#L627`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No (Required only for `orca-*` tier) | If missing, OrcaRouter models return 401; Global Automode skips to Gemini. |
| `ORCAROUTER_API_KEY_2` | Secondary backup API key for OrcaRouter rotation. | [`scripts/kiro_proxy_server.js#L628`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No | If omitted, key rotation has only 1 key for OrcaRouter; quota limit trips breaker immediately. |
| `GEMINI_API_KEY` | Google Gemini API key (supports comma-separated list). | [`scripts/kiro_proxy_server.js#L236, L720`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No (Required for direct `gemini-*` tier) | If missing, direct Gemini API calls fail with 401; Canvas Bridge is untouched (Canvas uses browser auth). |
| `NGROK_AUTHTOKEN` | Auth token for opening Ngrok tunnel for Canvas Bridge. | [`scripts/kiro_proxy_server.js#L6810`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No (Can use `NGROK_TOKEN` alias) | If missing, Ngrok cannot establish a public HTTPS tunnel; Canvas userscript must connect to local `127.0.0.1:8084`. |
| `NGROK_TOKEN` | Fallback alias for `NGROK_AUTHTOKEN`. | [`scripts/kiro_proxy_server.js#L6811`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No | See `NGROK_AUTHTOKEN`. |
| `AI_PROVIDER` | Generic provider override for single-model proxying. | [`scripts/kiro_proxy_server.js#L601`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No | If set to unknown provider, routing falls back to default catalog. |
| `AI_BASE_URL` | Base URL for generic OpenAI-compatible upstream. | [`scripts/kiro_proxy_server.js#L602`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No | If set to malformed URL, HTTP client throws `ERR_INVALID_URL`. |
| `AI_MODEL` | Default model identifier when none is provided in request. | [`scripts/kiro_proxy_server.js#L603`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No (Default: `global-automode`) | If set to invalid model slug, upstream returns 404 model not found. |
| `AI_API_KEY` | Generic API key fallback when provider-specific key missing. | [`scripts/kiro_proxy_server.js#L621`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No | If missing and provider-specific key missing, request fails with 401. |
| `GROQ_API_KEY` | Authentication key for custom Groq endpoint. | [`config/kiro_ai_config.json#L49`](file:///d:/sdlc_studio/projects/kiro-integration/config/kiro_ai_config.json) | No | If omitted, Groq requests fall back to zero-key or fail if authentication is enforced. |
| `GLM_API_KEY` | Authentication key for custom GLM DevGateway provider. | [`config/kiro_ai_config.json#L59`](file:///d:/sdlc_studio/projects/kiro-integration/config/kiro_ai_config.json) | No (Default: `sk-devgw-master-key`) | If wrong, GLM endpoint rejects requests with 401. |
| `ABHYAST_GEMINI_API_KEY` | Authentication key for custom Abhyast-Gemini endpoint. | [`config/kiro_ai_config.json#L69`](file:///d:/sdlc_studio/projects/kiro-integration/config/kiro_ai_config.json) | No (Default: `sk-devgw-master-key`) | If wrong, Abhyast endpoint rejects requests with 401. |
| `WORKSPACE_ROOT` | Absolute root directory of active Kiro IDE workspace. | [`scripts/kiro_proxy_server.js#L5374`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | No (Default: `process.cwd()`) | If set to non-existent directory, agent tool path resolution and `.kiro/steering/` loading fails. |

---

## 2. Configuration Files & Feature Flags

### 2.1 Extension Gateway Config: `config/kiro_ai_config.json`
- **Location:** Project root `config/kiro_ai_config.json`
- **Target:** Read by Kiro IDE patched extension host.
- **Fields:**
  | Field | Type | Default | Description |
  | :--- | :--- | :--- | :--- |
  | `mode` | String | `"proxy"` | Toggles between `"proxy"` (local gateway) and `"native"` (AWS Bedrock direct). |
  | `proxy.enabled` | Boolean | `true` | Enables local endpoint redirection. |
  | `proxy.url` | String | `"http://127.0.0.1:8084"` | Gateway URL intercepted by Kiro extension. |
  | `proxy.port` | Integer | `8084` | Listening port matching `PROXY_PORT`. |

### 2.2 Workspace Steering Config: `.kiro/config.json`
- **Location:** Project root `.kiro/config.json`
- **Target:** Read by Kiro IDE AI workspace agent.
- **Fields:**
  | Field | Type | Default | Description |
  | :--- | :--- | :--- | :--- |
  | `mode` | String | `"proxy"` | Activates proxy-specific prompt templates and rules. |
  | `steering.autoInject` | Boolean | `true` | Automatically injects rules from `.kiro/steering/` into the chat prompt. |

### 2.3 Custom Provider Catalog: `config/custom_config.json`
- **Location:** Project root `config/custom_config.json`
- **Target:** Read by `loadCustomConfig()` ([`scripts/kiro_proxy_server.js#L588`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)).
- **Fields:**
  | Field | Type | Required | Description |
  | :--- | :--- | :--- | :--- |
  | `customProviders` | Array of Objects | No | List of third-party OpenAI-compatible endpoints. |
  | `customProviders[].name` | String | Yes | Provider prefix identifier (e.g., `"groq"`, `"glm"`). |
  | `customProviders[].baseUrl` | String | Yes | Base URL (e.g., `"https://api.groq.com/openai/v1"`). |
  | `customProviders[].apiKey` | String | No | Bearer API token for authentication. |
  | `customProviders[].models` | Array of Strings | Yes | List of model slugs to register under `custom-<name>-<model>`. |
  | `customProviders[].supportsTools` | Boolean | No | Declares whether provider supports function calling (default: `true`). |

---

## 3. Operational Invariants and Thresholds

| Invariant / Flag | Hardcoded Value | Location in Code | Impact if Modified |
| :--- | :--- | :--- | :--- |
| **Max Request Body Size** | `10 * 1024 * 1024` (10 MB) | [`scripts/kiro_proxy_server.js#L4555`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Requests exceeding this size are aborted with HTTP 413 to prevent memory exhaustion. |
| **Circuit Breaker Trip Threshold** | `5` consecutive errors | [`scripts/kiro_proxy_server.js#L312`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Lower values cause hypersensitive tripping; higher values delay automated failover. |
| **Circuit Breaker Reset Timeout** | `60,000` ms (60 seconds) | [`scripts/kiro_proxy_server.js#L315`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Duration breaker remains in `OPEN` state before allowing 1 probe in `HALF_OPEN`. |
| **Max Cumulative Request Timeout** | `180,000` ms (180 seconds) | [`scripts/kiro_proxy_server.js#L402`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Hard ceiling across all retry hops. Prevents infinite cascading loops. |
| **Canvas Queue Max Depth** | `100` items | [`scripts/kiro_proxy_server.js#L452`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Beyond 100 queued items, new Canvas requests are rejected with HTTP 429. |
| **Canvas Queue Item TTL** | `300,000` ms (5 minutes) | [`scripts/kiro_proxy_server.js#L454`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Requests not popped by `/poll` within 5 minutes expire and return HTTP 504. |
| **Context Pruning Threshold** | `0.85` (85% of window) | [`scripts/kiro_proxy_server.js#L3800`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | When message tokens exceed 85% of `contextWindow`, oldest turns are pruned. |
