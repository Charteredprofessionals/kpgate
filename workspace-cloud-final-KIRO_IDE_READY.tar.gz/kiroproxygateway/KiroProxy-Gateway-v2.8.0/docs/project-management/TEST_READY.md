# KiroProxy Gateway — End-to-End Test Suite Ready (`TEST_READY.md`)

## 1. Test Suite Status: **READY & VERIFIED**

The comprehensive 4-Tier End-to-End Opaque-Box Test Suite for **KiroProxy Gateway** is fully implemented and operational under `tests/e2e/`.

- **Test Suite Location**: `tests/e2e/`
- **Master Test Runner**: `tests/e2e/e2e_runner.js`
- **Total Test Cases**: **58 tests** (Tiers 1–4)
- **Architecture**: Opaque-box HTTP/1.1 & AWS Bedrock EventStream protocol validation with zero internal implementation coupling.

---

## 2. Runner Command

To run the complete E2E test suite against the local gateway (auto-starts if not running):
```bash
node tests/e2e/e2e_runner.js
```

### Granular Execution Options
```bash
# Run specific tiers
node tests/e2e/e2e_runner.js --tier=1    # Tier 1: Feature Coverage (R1, R2, R3, R4)
node tests/e2e/e2e_runner.js --tier=2    # Tier 2: Boundary & Corner Cases (R1, R2, R3, R4)
node tests/e2e/e2e_runner.js --tier=3    # Tier 3: Cross-Feature Combinations
node tests/e2e/e2e_runner.js --tier=4    # Tier 4: Real-World Application Scenarios

# Custom port or fail-fast mode
node tests/e2e/e2e_runner.js --port=8084 --bail

# Export JSON report
node tests/e2e/e2e_runner.js --json
```

---

## 3. Complete Coverage Summary Table

| Requirement | Tier | Test ID | Description | Target Endpoint / Artifact | Expected Contract |
|-------------|------|---------|-------------|----------------------------|-------------------|
| **R1** | Tier 1 | `T1_R1_01` | Models endpoint discovery | `GET /listAvailableModels` | HTTP 200, non-empty `models` array, pricing object |
| **R1** | Tier 1 | `T1_R1_02` | OpenAI models format | `GET /v1/models` | HTTP 200, `object: "list"`, model items with `id` |
| **R1** | Tier 1 | `T1_R1_03` | Multi-provider free tiers | `GET /listAvailableModels` | Contains Kilo, Cline, OpenRouter, OrcaRouter, Gemini |
| **R1** | Tier 1 | `T1_R1_04` | Non-streaming chat completions | `POST /v1/chat/completions` | HTTP 200, valid OpenAI completion schema or 502 fallback |
| **R1** | Tier 1 | `T1_R1_05` | Streaming SSE chat completions | `POST /v1/chat/completions` (stream) | HTTP 200, `text/event-stream`, terminates with `[DONE]` |
| **R1** | Tier 1 | `T1_R1_06` | Reliability & Metrics telemetry | `GET /status`, `GET /metrics` | HTTP 200, uptime, version, Prometheus metrics |
| **R1** | Tier 2 | `T2_R1_01` | Empty messages validation | `POST /v1/chat/completions` | HTTP 400, `invalid_request_error` |
| **R1** | Tier 2 | `T2_R1_02` | Null message content validation | `POST /v1/chat/completions` | HTTP 400, content cannot be null |
| **R1** | Tier 2 | `T2_R1_03` | Missing messages property | `POST /v1/chat/completions` | HTTP 400 |
| **R1** | Tier 2 | `T2_R1_04` | Unknown model fallback | `POST /v1/chat/completions` | HTTP 200 via auto-fallback or structured 502 |
| **R1** | Tier 2 | `T2_R1_05` | Extreme payload size | `POST /v1/chat/completions` | Process survives 15KB text without buffer crash |
| **R1** | Tier 2 | `T2_R1_06` | Malformed non-JSON payload | `POST /v1/chat/completions` | Server process isolates error and remains alive |
| **R2** | Tier 1 | `T1_R2_01` | Canvas Bridge Dashboard delivery | `GET /canvas` | HTTP 200 |
| **R2** | Tier 1 | `T1_R2_02` | Preflight CORS headers | `OPTIONS /poll` | HTTP 200, allows `ngrok-skip-browser-warning` |
| **R2** | Tier 1 | `T1_R2_03` | Reverse polling queue contract | `GET /poll` | HTTP 200, returns `id`, `_meta.serverTime`, `queueDepth` |
| **R2** | Tier 1 | `T1_R2_04` | Token chunk streaming ingestion | `POST /chunk` | HTTP 200, returns 'ok' |
| **R2** | Tier 1 | `T1_R2_05` | Completion signal ingestion | `POST /done` | HTTP 200, returns 'ok' |
| **R2** | Tier 1 | `T1_R2_06` | Request cancellation | `POST /cancel` | HTTP 200, returns `{ success: true }` |
| **R2** | Tier 2 | `T2_R2_01` | Foreign & sub-domain origins | `OPTIONS /poll` | HTTP 200, permissive CORS headers |
| **R2** | Tier 2 | `T2_R2_02` | Rapid concurrent polling | `GET /poll` | Long-polling engine handles concurrent calls |
| **R2** | Tier 2 | `T2_R2_03` | Orphan chunk handling | `POST /chunk` | HTTP 200, no unhandled rejection |
| **R2** | Tier 2 | `T2_R2_04` | Orphan done signal | `POST /done` | HTTP 200, no unhandled rejection |
| **R2** | Tier 2 | `T2_R2_05` | Empty cancel signal | `POST /cancel` | HTTP 200, `{ success: true, cancelled: null }` |
| **R2** | Tier 2 | `T2_R2_06` | Malformed non-JSON chunk body | `POST /chunk` | Server isolates malformed chunk payload |
| **R3** | Tier 1 | `T1_R3_01` | Workflow run compatibility stub | `POST /runtime/workflows/run` | HTTP 200, `fallbackMode: "direct_execution"` |
| **R3** | Tier 1 | `T1_R3_02` | Workflow inspect & validate stubs | `GET /runtime/workflows/inspect` | HTTP 404 (inspect), HTTP 501 (validate) |
| **R3** | Tier 1 | `T1_R3_03` | Unlimited usage limits | `GET /usagelimits` | HTTP 200, `usageLimit >= 10000`, `ACTIVE` |
| **R3** | Tier 1 | `T1_R3_04` | Feature configurations | `GET /featureconfiguration` | HTTP 200, AWS treatment feature evaluations |
| **R3** | Tier 1 | `T1_R3_05` | EventStream binary frames | `POST /generateAssistantResponse` | HTTP 200, valid EventStream frames, valid CRC32 |
| **R3** | Tier 1 | `T1_R3_06` | Steering file enforcement | `.kiro/steering/proxy-mode.md` | `inclusion: auto`, direct tool execution |
| **R3** | Tier 2 | `T2_R3_01` | Empty conversation state | `POST /generateAssistantResponse` | HTTP 200 EventStream with safe guidance |
| **R3** | Tier 2 | `T2_R3_02` | Extreme AWS header sizes | `GET /usagelimits` | HTTP 200, immunity to header splitting |
| **R3** | Tier 2 | `T2_R3_03` | Deeply nested tool schemas | `POST /generateAssistantResponse` | Schema sanitization without call stack overflow |
| **R3** | Tier 2 | `T2_R3_04` | Universal AWS catch-all | `POST /runtime/unknown-action` | HTTP 200, standard AWS envelope |
| **R3** | Tier 2 | `T2_R3_05` | Concurrent Bedrock streams | `POST /generateAssistantResponse` | Parallel streams maintain CRC32 frame integrity |
| **R4** | Tier 1 | `T1_R4_01` | Health endpoint rebranding | `GET /health` | HTTP 200, `message: "KiroProxy Active"` |
| **R4** | Tier 1 | `T1_R4_02` | Status endpoint metadata | `GET /status` | HTTP 200, uptime, version string |
| **R4** | Tier 1 | `T1_R4_03` | Package metadata rebranding | `package.json` | Package metadata reflects KiroProxy branding |
| **R4** | Tier 1 | `T1_R4_04` | Launcher rebranding | `start.bat` | Identifies as KiroProxy Gateway |
| **R4** | Tier 1 | `T1_R4_05` | Documentation disambiguation | `README.md` | Uniform KiroProxy Gateway identity |
| **R4** | Tier 1 | `T1_R4_06` | Server header compliance | `GET /usagelimits` | `Server: Amazon.com` compliance |
| **R4** | Tier 2 | `T2_R4_01` | Case-insensitive URL routes | `/HEALTH`, `/Status`, `/v1/MODELS` | HTTP 200 across all casing variants |
| **R4** | Tier 2 | `T2_R4_02` | Query parameter immunity | `GET /health?filter=all` | HTTP 200, unaffected schema |
| **R4** | Tier 2 | `T2_R4_03` | Legacy path aliases | `GET /api/health`, `/api/hello` | HTTP 200, serves health payload |
| **R4** | Tier 2 | `T2_R4_04` | Server metadata verification | `GET /status` | Clean version string and telemetry |
| **R4** | Tier 2 | `T2_R4_05` | Error response headers | `POST /v1/chat/completions` (400) | `application/json` error envelope |
| **All** | Tier 3 | `T3_COMB_01` | Fallback + Streaming | `POST /v1/chat/completions` (auto+stream) | Streaming fallback maintains SSE protocol |
| **All** | Tier 3 | `T3_COMB_02` | CORS + Ngrok Queueing | `OPTIONS /poll` -> `GET /poll` | Negotiation with `gemini.google.com` origin |
| **All** | Tier 3 | `T3_COMB_03` | Steering + Bedrock Converse | `POST /generateAssistantResponse` | Tool execution context emitted in EventStream |
| **All** | Tier 3 | `T3_COMB_04` | Canvas Bridge Queue Lifecycle | `POST /chunk` -> `POST /done` | Token streaming and done ingestion |
| **All** | Tier 3 | `T3_COMB_05` | Telemetry under Concurrent Load | `/health` + `/v1/chat/completions` | Atomic telemetry updates under load |
| **All** | Tier 3 | `T3_COMB_06` | Workflow Degradation + Converse | `/runtime/workflows/run` -> Converse | Workflow fallback followed by direct stream |
| **All** | Tier 4 | `T4_SCEN_01` | Kiro IDE Cold Boot Sequence | Health -> Models -> Config -> Limits -> Spaces | Complete preflight sequence |
| **All** | Tier 4 | `T4_SCEN_02` | Multi-Turn Coding Assistant | Turn 1 -> Turn 2 Converse Streaming | Maintains conversation history and CRC32 |
| **All** | Tier 4 | `T4_SCEN_03` | Agent Tool Execution Loop | Converse with toolSpec | Bedrock frames for direct execution |
| **All** | Tier 4 | `T4_SCEN_04` | Workflow Interception Recovery | Workflow run -> Fallback -> Converse | Seamless workflow avoidance |
| **All** | Tier 4 | `T4_SCEN_05` | Gemini Canvas Browser Cycle | `gemini.google.com` -> Poll -> Chunk -> Done | Full browser bridge loop |

---

## 4. Verification Instructions for Dispatcher

To independently verify the test suite:
1. Ensure Node.js 18+ is available.
2. Run: `node tests/e2e/e2e_runner.js`
3. Observe summary table output and exit code `0`.
