# Project Management Documentation

This section contains project management and maintenance documentation.

## 📄 Available Documents

- **[Changelog](CHANGELOG.md)** - Version history and changes
- **[Release Checklist](RELEASE_CHECKLIST.md)** - Release verification process
- **[Handover Guide](HANDOVER.md)** - Project transfer documentation
- **[Roadmap](ROADMAP.md)** - Future plans and features

## 🎯 Purpose

These documents help maintainers manage releases, track changes, and ensure smooth project handover.

---

**Part of KiroProxy Gateway Documentation**