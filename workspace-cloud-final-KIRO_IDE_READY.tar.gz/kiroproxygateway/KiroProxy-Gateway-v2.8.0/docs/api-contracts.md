# API Contracts — KiroProxy Gateway v2.8.0

**Target Application:** `kiroproxy-gateway`  
**Primary File:** [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)  
**Port:** Default `8084` (`http://127.0.0.1:8084`)  
**Protocols:** HTTP/1.1 REST, AWS Smithy JSON, AWS Binary EventStream, Server-Sent Events (SSE)

---

## 1. AWS Smithy / Bedrock Emulation Layer

These endpoints emulate AWS Bedrock and AWS Q Developer backend services intercepted from the patched Kiro IDE extension (`kiro.kiro-agent`).

### 1.1 `POST /generateAssistantResponse`
- **`[FACT]`**: Intercepted at [`scripts/kiro_proxy_server.js#L5971`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), handled by `handleConverseStreaming` ([`L4644`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)).
- **Consumers:** Kiro IDE Assistant Chat, Agent mode, Inline code editing.
- **Headers Required:**
  ```http
  Content-Type: application/json
  x-amzn-target: AmazonBedrockService.GenerateAssistantResponse
  ```
- **Request Body (Smithy Schema):**
  ```json
  {
    "conversationState": {
      "conversationId": "uuid-string",
      "currentMessage": {
        "userInputMessage": {
          "content": "User prompt text",
          "modelId": "kilo-deepseek-v3"
        }
      },
      "history": [
        { "userInputMessage": { "content": "Previous prompt" } },
        { "assistantResponseMessage": { "content": "Previous response" } }
      ]
    },
    "userInputMessageContext": {
      "tools": [
        {
          "toolSpecification": {
            "name": "execute_bash",
            "description": "Execute terminal shell command",
            "inputSchema": {
              "json": {
                "type": "object",
                "properties": { "command": { "type": "string" } },
                "required": ["command"]
              }
            }
          }
        }
      ]
    }
  }
  ```
- **Response Format:** Binary AWS EventStream (`Content-Type: application/vnd.amazon.eventstream`).
- **Binary Event Types:**
  1. `assistantResponseEvent`: Text delta chunk:
     ```json
     { "content": "Generated text chunk" }
     ```
  2. `toolUseEvent`: Tool invocation request:
     ```json
     {
       "toolUseId": "tooluse_123456789",
       "name": "execute_bash",
       "input": "{\"command\":\"ls -la\"}"
     }
     ```
     *(CRITICAL: `input` MUST be a JSON-serialized string, not an object literal).*
  3. `metadataEvent`: Final usage metrics:
     ```json
     {
       "usage": { "inputTokens": 120, "outputTokens": 45, "totalTokens": 165 },
       "stopReason": "END_TURN"
     }
     ```

---

### 1.2 `GET /listAvailableModels`
- **`[FACT]`**: Handled at [`scripts/kiro_proxy_server.js#L5769`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Consumers:** Kiro IDE model selector dropdown.
- **Response Body:**
  ```json
  {
    "models": [
      {
        "modelId": "kilo-deepseek-v3",
        "modelName": "DeepSeek V3 (Kilo)",
        "rateMultiplier": 0.0,
        "contextWindow": 131072,
        "capabilities": { "tools": true, "vision": false, "reasoning": true }
      },
      {
        "modelId": "global-automode",
        "modelName": "Global AutoMode (6-Tier Failover)",
        "rateMultiplier": 0.0,
        "contextWindow": 128000,
        "capabilities": { "tools": true, "vision": true, "reasoning": true }
      }
    ]
  }
  ```

---

### 1.3 `GET /featureconfiguration`
- **`[FACT]`**: Handled at [`scripts/kiro_proxy_server.js#L5717`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Consumers:** Kiro IDE capability negotiation.
- **Response Body:**
  ```json
  {
    "features": {
      "tools": { "status": "ENABLED" },
      "codeGeneration": { "status": "ENABLED" },
      "chat": { "status": "ENABLED" },
      "proxy": { "status": "ENABLED", "version": "2.8.0" }
    }
  }
  ```

---

### 1.4 `GET /usagelimits`
- **`[FACT]`**: Handled at [`scripts/kiro_proxy_server.js#L5903`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Consumers:** Kiro IDE quota meter & status bar.
- **Response Body:**
  ```json
  {
    "daysUntilReset": 999,
    "nextResetDate": "2099-01-01T00:00:00.000Z",
    "usageBreakdown": [
      {
        "resourceType": "CREDIT",
        "currentUsage": 0,
        "maxUsage": 999999,
        "unit": "CREDIT"
      }
    ]
  }
  ```

---

### 1.5 `POST /runtime/workflows/*` (Stubbed)
- **`[FACT]`**: Handled at [`scripts/kiro_proxy_server.js#L5984-L6020`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Sub-paths:** `/run`, `/inspect`, `/update`, `/validate`.
- **Consumers:** Kiro IDE workflow executor.
- **Response:** HTTP 501 Not Implemented or HTTP 404:
  ```json
  {
    "error": "Workflows unsupported in proxy mode. Use direct agent tool execution."
  }
  ```

---

## 2. OpenAI Compatible Endpoints

For standard AI clients, external plugins, or local testing tools.

### 2.1 `GET /v1/models`
- **`[FACT]`**: Handled at [`scripts/kiro_proxy_server.js#L5791`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Response Body:**
  ```json
  {
    "object": "list",
    "data": [
      {
        "id": "kilo-deepseek-v3",
        "object": "model",
        "created": 1728000000,
        "owned_by": "kilo"
      }
    ]
  }
  ```

### 2.2 `POST /v1/chat/completions`
- **`[FACT]`**: Handled at [`scripts/kiro_proxy_server.js#L6270`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Supports:** Streaming (`stream: true`) via SSE or single response (`stream: false`).
- **Response:** Standard OpenAI chat completion format.

---

## 3. Canvas Bridge Control Protocol

Used to orchestrate browser-based inference via the Gemini Web UI userscript.

| Endpoint | Method | Consumer | Request Body | Response Body | Code Citation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/canvas` | `GET` | Web Browser | None | HTML Web Dashboard | [`L6401`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) |
| `/poll` | `GET` | Userscript | None | `{ "hasRequest": true, "request": { ... } }` or `{ "hasRequest": false }` | [`L6475`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) |
| `/chunk` | `POST` | Userscript | `{ "id": "uuid", "delta": "text" }` | `{ "status": "ok" }` | [`L6550`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) |
| `/done` | `POST` | Userscript | `{ "id": "uuid", "content": "text", "status": "completed" }` | `{ "status": "ok" }` | [`L6612`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) |
| `/cancel` | `POST` | Userscript | `{ "id": "uuid", "reason": "timeout" }` | `{ "status": "ok" }` | [`L6650`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) |

---

## 4. Diagnostics & System Endpoints

### 4.1 `GET /health`
- **`[FACT]`**: Handled at [`scripts/kiro_proxy_server.js#L5690`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Response Body:**
  ```json
  {
    "status": "healthy",
    "uptime": 3600,
    "providers": {
      "kilo": { "status": "healthy", "circuitBreaker": "CLOSED" },
      "cline": { "status": "healthy", "circuitBreaker": "CLOSED" },
      "openrouter": { "status": "healthy", "circuitBreaker": "CLOSED" },
      "gemini": { "status": "healthy", "circuitBreaker": "CLOSED" },
      "canvas": { "status": "healthy", "queueDepth": 0 }
    }
  }
  ```

### 4.2 `GET /metrics`
- **`[FACT]`**: Handled at [`scripts/kiro_proxy_server.js#L5695`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Response Body:** Real-time metrics counters (`requestsTotal`, `providerCalls`, `errorCounts`, `latencies`).
