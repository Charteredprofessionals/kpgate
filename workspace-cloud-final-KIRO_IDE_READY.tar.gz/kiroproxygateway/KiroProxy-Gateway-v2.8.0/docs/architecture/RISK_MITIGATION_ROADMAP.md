# Architectural Risk Mitigation Roadmap - KiroProxy Gateway v2.7.0

**Status:** Proposed  
**Created:** 2026-10-08  
**Author:** Architecture Review  
**Next Review:** Before v2.8.0

## Identified Risks

| # | Risk | Severity | Likelihood | Impact |
|---|------|----------|------------|--------|
| R1 | Monolithic `kiro_proxy_server.js` | 🟡 HIGH | Certain | Every change touches multiple features |
| R2 | Global state — no persistence | 🟡 HIGH | Certain | Restart loses circuit state, metrics, queue |
| R3 | IDE extension patching is position-based | 🔴 EXTREME | Every IDE update | Full proxy outage until re-patched |
| R4 | Provider coupling via model name prefix | 🟢 MEDIUM | On every new provider | Routing breaks if prefix wrong |

---

## R1: Monolithic Server File

### Problem

`scripts/kiro_proxy_server.js` is ~3,200 lines. Every change — adding a provider, fixing a tool format, adjusting a circuit breaker threshold — touches this file. Merge conflicts, hard to review, hard to test in isolation.

### Recommended Fix: Split into Modules

**Effort:** 2 days  
**Risk:** Low (same code, different files — no behavior change)  
**Immediate benefit:** Each area independently editable and testable

**Target structure:**
```
scripts/
├── kiro_proxy_server.js        # Entry point only (~100 lines)
├── core/
│   ├── config.js               # loadCustomConfig() + validation
│   ├── router.js               # HTTP handler + endpoint dispatch
│   └── eventstream.js          # createEventStreamFrame() + createConverseEvent()
├── reliability/
│   ├── circuit-breaker.js      # CIRCUIT_BREAKERS + record*() + isCircuitOpen()
│   ├── retry.js                # executeWithRetry()
│   └── health.js               # runHealthChecks() + HEALTH_STATUS
├── providers/
│   ├── kilo.js                 # callKiloGateway() + fetchKiloGatewayModels()
│   ├── gemini.js               # callGeminiApi() + fetchGeminiModels()
│   ├── cline.js                # callClineApi() + fetchClineFreeModels()
│   ├── openrouter.js           # callOpenRouter() + fetchOpenRouterFreeModels()
│   ├── orcarouter.js           # callOrcaRouter() + fetchOrcaRouterFreeModels()
│   ├── ngrok.js                # callNgrokGemini()
│   └── custom.js               # callCustomApi() + fetchCustomProviderModels()
├── tools/
│   ├── translator.js           # translateToolsToUpstream() + extractToolMetadata()
│   ├── extractor.js            # extractToolCallsFromResponse() + all 5 format regexes
│   └── schema.js               # sanitizeSchemaForUpstream()
└── catalog/
    └── models.js               # MODELS object + auto-population orchestrator
```

**Migration approach — zero-risk:**
1. Create new files, copy functions verbatim (no changes)
2. Add `module.exports` at bottom of each new file
3. `require()` them in `kiro_proxy_server.js`
4. Run `npm run test:all` — must still be 55/55
5. Delete original functions from monolith

**Do NOT:**
- Refactor while splitting — split first, refactor after
- Split and change behavior in same commit
- Skip the test run between steps

---

## R2: Global State — No Persistence

### Problem

All runtime state lives in memory. A server restart resets:
- **Circuit breakers** → Providers that were failing get a clean slate; may cascade again
- **Metrics** → Lost forever; no historical data
- **Gemini queue** → All queued requests dropped silently
- **Key rotation index** → Back to key 1 even if it was rate-limited

### Recommended Fix: File-Based State Snapshots

**Effort:** 1 day  
**Risk:** Low (additive change, fallback to defaults if file missing)  
**No external dependencies** (no Redis, no database)

**Implementation:**

```javascript
// scripts/core/state-persistence.js

const STATE_FILE = path.join(__dirname, '..', '..', 'logs', 'runtime-state.json');

function saveState() {
  const snapshot = {
    savedAt: Date.now(),
    circuitBreakers: CIRCUIT_BREAKERS,
    providerKeyIndex: providerCurrentKeyIndex,
    providerKeyFailures: providerKeyFailures,
    metrics: {
      sessionStart: METRICS.sessionStart,
      providerCalls: METRICS.providerCalls  // counts only, not latency arrays
    }
  };
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(snapshot, null, 2));
  } catch (e) {
    console.warn('[State] Could not save state:', e.message);
  }
}

function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return;
    const raw = fs.readFileSync(STATE_FILE, 'utf8');
    const snapshot = JSON.parse(raw);

    // Only restore if snapshot is < 5 minutes old
    if (Date.now() - snapshot.savedAt > 300000) {
      console.log('[State] Snapshot too old, starting fresh');
      return;
    }

    // Restore circuit breakers (most important)
    for (const [name, state] of Object.entries(snapshot.circuitBreakers || {})) {
      if (CIRCUIT_BREAKERS[name]) {
        CIRCUIT_BREAKERS[name] = { ...CIRCUIT_BREAKERS[name], ...state };
      }
    }

    // Restore key rotation
    Object.assign(providerCurrentKeyIndex, snapshot.providerKeyIndex || {});
    Object.assign(providerKeyFailures, snapshot.providerKeyFailures || {});

    console.log('[State] Runtime state restored from snapshot');
  } catch (e) {
    console.warn('[State] Could not restore state (starting fresh):', e.message);
  }
}

// Save every 60 seconds
setInterval(saveState, 60000);

// Save on graceful shutdown
process.on('SIGTERM', saveState);
process.on('SIGINT', saveState);

module.exports = { saveState, loadState };
```

**Add to server startup:**
```javascript
// Near top of startup, after globals are initialized
const { loadState } = require('./core/state-persistence');
loadState(); // Restore state if recent snapshot exists
```

**What this solves:**
- Circuit breakers survive restarts → no re-cascading
- Key rotation survives restarts → rate-limited key stays rotated
- Metrics persist across restarts → historical data available

**What it does NOT solve:**
- Queue (Gemini) — in-flight requests still drop. Acceptable tradeoff.
- Horizontal scaling — still in-process state. Use Redis for that.

**State file location:** `logs/runtime-state.json` (already gitignored)

---

## R3: IDE Extension Patching (Highest Priority)

### Problem

`patch_kiro_extension.js` uses string replacement on minified, position-dependent code. Every Kiro IDE update shuffles the minified output → patches silently fail or hit the wrong location → proxy mode breaks completely.

**Current failure mode:**
1. User updates Kiro IDE
2. `extension.js` regenerated/minified differently
3. Patch applies to wrong location (or fails)
4. Proxy completely stops working
5. User has no indication why

### Recommended Fix: Pattern-Based Patching + Auto-Verify Hook

**Effort:** 1 day for pattern matching; 2 hours for auto-verify  
**Risk:** Medium (test thoroughly, keep `--restore` as fallback)

**Replace position-based patching with regex patterns:**

```javascript
// BEFORE (fragile — breaks on minification changes)
const target = 'kilogateway_models_endpoint_v3';  // positional string
content = content.slice(0, pos) + patch + content.slice(pos + target.length);

// AFTER (resilient — matches semantic pattern regardless of position)
// Patch 1: Model list dynamic fallback
const MODEL_LIST_PATTERN = /function\s+\w+\s*\(\s*\)\s*\{[\s\S]{0,200}kilogateway/;
if (!MODEL_LIST_PATTERN.test(content)) {
  throw new Error('Patch 1: Model list function not found — IDE may have changed');
}
content = content.replace(
  MODEL_LIST_PATTERN,
  (match) => match.replace('kilogateway', '/*[WHGW]*/ whgwListModels() || kilogateway')
);
```

**Add startup auto-verify:**

```javascript
// In kiro_proxy_server.js startup block
const { execSync } = require('child_process');
try {
  const result = execSync('node scripts/patch_kiro_extension.js --check', { encoding: 'utf8' });
  const patchCount = (result.match(/✅ APPLIED/g) || []).length;
  if (patchCount < 4) {
    console.warn(`⚠️  [Patch] Only ${patchCount}/4 IDE patches active. Run: npm run patch`);
  } else {
    console.log('[Patch] ✅ All 4 IDE patches active');
  }
} catch (e) {
  console.warn('[Patch] Could not verify IDE patches:', e.message);
}
```

**Add a PostFileSave hook** (already have hook infrastructure):

```json
// .kiro/hooks/patch-check.json
{
  "version": "v1",
  "hooks": [{
    "name": "Verify IDE patches after extension.js changes",
    "trigger": "PostFileSave",
    "matcher": "extension\\.js$",
    "action": {
      "type": "command",
      "command": "node scripts/patch_kiro_extension.js --check"
    }
  }]
}
```

**Longer term:** Maintain a version-tagged patch matrix:

```javascript
const PATCH_VERSIONS = {
  '1.14.0': { patch1: /pattern-for-v1.14/, patch2: /pattern-for-v1.14/ },
  '1.15.0': { patch1: /pattern-for-v1.15/, patch2: /pattern-for-v1.15/ },
};

function selectPatchSet(ideVersion) {
  return PATCH_VERSIONS[ideVersion] || PATCH_VERSIONS['latest'];
}
```

---

## R4: Provider Coupling via Model Name Prefix

### Problem

The routing logic is a hard-coded if/else chain (line ~2850):

```javascript
if (requestedModel.startsWith('kilo-')) { ... }
else if (requestedModel.startsWith('cline-')) { ... }
// ...
```

Adding a provider requires touching the routing code. A typo in the prefix silently routes to the wrong provider. No single source of truth for the prefix→provider mapping.

### Recommended Fix: Config-Driven Router

**Effort:** 1 day  
**Risk:** Low (same behavior, centralized mapping)

**Replace the if/else chain with a lookup table:**

```javascript
// scripts/core/router.js

// Single source of truth: prefix → provider function
const PROVIDER_ROUTES = {
  'kilo-':        { name: 'kilo',        fn: callKiloGateway },
  'cline-':       { name: 'cline',       fn: callClineApi },
  'openrouter-':  { name: 'openrouter',  fn: callOpenRouter },
  'orca-':        { name: 'orcarouter',  fn: callOrcaRouter },
  'ngrok-':       { name: 'ngrok',       fn: callNgrokGemini },
  'gemini-':      { name: 'gemini',      fn: callGeminiApi },
  'custom-':      { name: 'custom',      fn: callCustomApi },
};

function resolveProvider(modelId) {
  for (const [prefix, route] of Object.entries(PROVIDER_ROUTES)) {
    if (modelId.startsWith(prefix)) return route;
  }
  return null; // Unknown model
}
```

**Usage in main handler:**
```javascript
const route = resolveProvider(requestedModel);
if (!route) {
  return sendError(res, 400, 'INVALID_MODEL', `Unknown model: ${requestedModel}`);
}
const { name: provider, fn: providerFn } = route;
```

**Benefits:**
- Adding provider = one line in the table (not scattered code changes)
- Prefix duplication detected at startup (can add validation)
- Easy to unit test prefix resolution
- `docs/change-impact.md` §1 becomes much simpler

**Add prefix validation at startup:**
```javascript
// Catch duplicate prefixes at startup, not at runtime
const prefixes = Object.keys(PROVIDER_ROUTES);
const duplicates = prefixes.filter((p, i) => prefixes.indexOf(p) !== i);
if (duplicates.length > 0) {
  throw new Error(`Duplicate provider prefixes: ${duplicates.join(', ')}`);
}
console.log(`[Router] ${prefixes.length} provider routes registered`);
```

---

## Implementation Priority

| Priority | Risk | Fix | Effort | Why This Order |
|----------|------|-----|--------|----------------|
| 1 | R3 IDE Patching | Pattern-based matching + auto-verify | 1 day | Highest pain, breaks on every IDE update |
| 2 | R1 Monolith | Split into 5 module directories | 2 days | Foundation for everything else |
| 3 | R4 Prefix Coupling | Config-driven PROVIDER_ROUTES table | 1 day | Easy win after split |
| 4 | R2 Global State | File-based state snapshots | 1 day | Low risk, meaningful reliability gain |

**Total estimated effort:** 5 days  
**Total estimated benefit:** 80% reduction in maintenance friction

---

## What NOT to Do

- **Do NOT rewrite in TypeScript** — too much churn, same logic problems
- **Do NOT add Redis** unless you need horizontal scaling (overkill for local proxy)
- **Do NOT break the module apart and refactor at the same time** — split first, refactor after tests pass
- **Do NOT version-bump for purely internal refactoring** — behavior unchanged, v2.7.0 stays

---

## Success Criteria

After implementing all 4 fixes:

- [ ] Kiro IDE update no longer breaks proxy (R3)
- [ ] `npm run patch:check` shows 4/4 after IDE update without re-patching (R3)
- [ ] Any single module file is < 300 lines (R1)
- [ ] Adding a new provider requires changes to exactly 1 table + 1 new file (R4)
- [ ] Server restart restores circuit breaker state within 5min window (R2)
- [ ] All 55 tests still pass after each fix (baseline unchanged)

---

**Related docs:**
- `docs/ai-maintenance/change-impact.md` — Blast radius for each module
- `docs/ai-maintenance/invariants-and-gotchas.md` — Constraints to preserve during refactor
- `docs/ai-maintenance/system-map.md` — Module dependency diagram
- `docs/open-questions.md` — Q2 (scaling), Q12 (persistence), Q16 (IDE updates)
