# Forensic Audit: AWS Cloud Protocol Compliance & Autonomous Development Agent Parity

**Date:** 2026-10-10  
**Status:** ✅ AUDITED & REMEDIATED (v2.8.1)  
**Target Components:**
- [`scripts/kiro_proxy_server.js`](../../scripts/kiro_proxy_server.js)
- [`extension.js`](file:///C:/Users/cscha/AppData/Local/Programs/Kiro/resources/app/extensions/kiro.kiro-agent/dist/extension.js) (`com.amazon.kiro.runtimeservice` Smithy Client)
- Historical Baseline: `luck-literature` worktree (`scripts/kiro_proxy_server.js`)
- Documentation Suite: [`docs/ai-maintenance/api-contracts.md`](../ai-maintenance/api-contracts.md), [`docs/ai-maintenance/MULTI_TOOL_SUPPORT.md`](../ai-maintenance/MULTI_TOOL_SUPPORT.md), [`docs/troubleshooting/AWS_CLOUD_COMPATIBILITY_REPORT.md`](../troubleshooting/AWS_CLOUD_COMPATIBILITY_REPORT.md)

---

## 1. Executive Summary

An end-to-end forensic audit was conducted across the KiroProxy Gateway codebase, Kiro IDE's compiled `extension.js` binary (`com.amazon.kiro.runtimeservice` Smithy schemas at offsets `5713800–5812000`), project documentation, and the working `luck-literature` worktree to answer two core questions:
1. **Why did KiroProxy Gateway fail to act as a native AWS Cloud (`KiroRuntimeService`) endpoint?**
2. **Why did upstream providers act like passive text chatbots instead of autonomous software development agents?**

### Summary of the 7 Root Causes Discovered

| # | Severity | Root Cause | Impact | Status |
|---|----------|------------|--------|--------|
| **RC-1** | **CRITICAL** | **Wrong Tool Payload Path (`body.toolConfiguration.tools` vs Smithy `userInputMessageContext.tools`)** | `hasTools` was always `false` and `kiroTools` was always `[]` (`Forwarding 0 tools to upstream`). Neither native function schemas nor the system-prompt tool guide were ever sent to upstream models. | ✅ Fixed |
| **RC-2** | **CRITICAL** | **Smithy `toolSpecification` vs Bedrock `toolSpec` & Unwrapped `inputSchema.json`** | Kiro IDE sends `{ toolSpecification: { name, description, inputSchema: { json: {...} } } }`. The proxy only checked `t.toolSpec`, turning every tool into `name: "unknown"` with empty/wrapped parameters. | ✅ Fixed |
| **RC-3** | **CRITICAL** | **Gated & Stripped Kiro Agent System Prompt (Regression from `luck-literature`)** | The 12-tool Kiro Agent System Prompt, **Kiro Native 3-Spec Method** (`.kiro/specs/<feature>/requirements.md`, `design.md`, `tasks.md`), and **Executive Documentation Standard** were gated behind `if (hasTools)` (always `false`) and stripped down to 5 tools. | ✅ Fixed |
| **RC-4** | **HIGH** | **Broken `GetFeatureConfiguration` Contract (`featureEvaluations` vs Salted SHA-256 `configuration` Map)** | Kiro IDE's `ExperimentConfigService` (`vMi`) looks up `configuration[sha256("kiro-feature-config-key-salt-3e9b1d7a" + flag)]`. Because `configuration` was missing, `system_field_injection` defaulted to `false`, stuffing Kiro's 15KB system prompt into `history[0]` where `pruneMessages()` truncated it to 3,500 chars. | ✅ Fixed |
| **RC-5** | **HIGH** | **Dropped Smithy Workspace Context (`envState`, `editorState`, `additionalContext`)** | `extractMessagesFromKiroPayload()` ignored `userInputMessageContext.envState` (`currentWorkingDirectory`, `operatingSystem`), `editorState` (`workspaceFolders`, active open `document`), and `additionalContext` (`.kiro/steering/*.md`, `#file`, `#folder`, `#codebase`). | ✅ Fixed |
| **RC-6** | **HIGH** | **Lazy Regex Truncation on Nested Braces (`{...}`) & Destructive Format 5 Code-Block Hijacking** | PowerShell script blocks (`Where-Object { $_... }`) and JS/TS code inside tool arguments caused lazy regexes `(\{[\s\S]*?\})` with optional suffixes to truncate at the first `}`, producing empty `{}` arguments. Format 5 hijacked normal markdown code snippets into fake `generated_file_1.js` `fs_write` calls. | ✅ Fixed |
| **RC-7** | **HIGH** | **Missing Tool-less Retry on Free Upstream Endpoints & Incomplete `callGeminiApi` Tool/System Handling** | Free models on OpenRouter/Kilo/Cline that reject `requestBody.tools` with HTTP 400/404 failed instead of falling back to prompt-driven `<|tool_call>`. `callGeminiApi` mapped `system` role to `user`, omitted `systemInstruction` and `functionDeclarations`, and ignored `part.functionCall`. | ✅ Fixed |

---

## 2. Detailed Forensic Evidence

### RC-1 & RC-2: Smithy `GenerateAssistantResponseRequest` Tool Path & `toolSpecification` Union
In Kiro IDE's `extension.js` (offsets `5735011–5770150` and `5806800`, `convertToGenerateAssistantMessages`), `GenerateAssistantResponseCommand` (`VUu` / schema `ABu`) serializes tools inside the nested Smithy structure:
```json
{
  "conversationState": {
    "conversationId": "conv_...",
    "history": [...],
    "currentMessage": {
      "userInputMessage": {
        "content": "...",
        "modelId": "...",
        "userInputMessageContext": {
          "envState": { "operatingSystem": "windows", "currentWorkingDirectory": "d:\\..." },
          "editorState": { "workspaceFolders": ["d:\\..."], "document": { "relativeFilePath": "...", "text": "..." } },
          "additionalContext": [{ "name": "...", "description": "...", "innerContext": "..." }],
          "toolResults": [...],
          "tools": [
            {
              "toolSpecification": {
                "name": "fs_write",
                "description": "...",
                "inputSchema": {
                  "json": {
                    "type": "object",
                    "properties": { "path": { "type": "string" }, "text": { "type": "string" } },
                    "required": ["path", "text"]
                  }
                }
              }
            }
          ]
        }
      }
    }
  },
  "profileArn": "arn:aws:kiro:...",
  "systemPrompt": "..."
}
```
Because [`docs/ai-maintenance/api-contracts.md`](../ai-maintenance/api-contracts.md) inaccurately documented standard AWS Bedrock Converse format (`body.toolConfiguration.tools` and `toolSpec`), `kiro_proxy_server.js` checked only `body.toolConfiguration?.tools || body.tools`. As a result, **0 tools** were extracted on every real Kiro IDE request.

### RC-3: Regression Against `luck-literature` Worktree
Diffing `scripts/kiro_proxy_server.js` against the working `luck-literature` worktree revealed that `luck-literature` **unconditionally** injected the full 12-tool Kiro Agent System Prompt (`fs_write`, `str_replace`, `read_file`, `list_directory`, `grep_search`, `file_search`, `execute_pwsh`, `invoke_sub_agent`, `validate_spec_format`, `task_list`, `task_update`, `task_get`), the **Kiro Native 3-Spec Method**, and the **Executive Documentation Standard**, and formatted historical `assistantResponseMessage.toolUses` as `<|tool_call>call:NAME{...}<tool_call|>`.

### RC-4: `GetFeatureConfiguration` Salted SHA-256 Protocol (`vMi` in `extension.js`)
In `extension.js` (offset `5746560`):
```javascript
RUu = "kiro-feature-config-key-salt-3e9b1d7a";
vMi = class {
  source = "experiment";
  get(t) {
    let e = this.service.getConfiguration(),
        r = createHash("sha256").update(RUu + t).digest("hex");
    return Object.prototype.hasOwnProperty.call(e, r) ? e[r] : ioe;
  }
};
```
`TUu` (offset `5720740`) extracts `(await f.send(new SUu(...))).configuration`. Returning `{ featureEvaluations: [...] }` caused `configuration` to be `{}` and `system_field_injection` to evaluate to `false`.

### RC-6: Balanced JSON Brace Extraction (`extractBalancedJson`)
When an agent executes PowerShell commands containing script blocks (`Get-ChildItem | Where-Object { $_.Length -gt 0 }`) or writes source files containing `{ ... }` blocks via `<|tool_call>call:TOOL{ARGS}<tool_call|>`, any regex relying on lazy `(\{[\s\S]*?\})` with an optional suffix stops at the first `}` inside the string literal. Replacing lazy brace regexes with `extractBalancedJson(str, openBraceIdx)` (which tracks string quotes `"..."`, backslash escapes `\"`, and brace depth) guarantees 100% lossless extraction of arbitrarily nested tool arguments.
