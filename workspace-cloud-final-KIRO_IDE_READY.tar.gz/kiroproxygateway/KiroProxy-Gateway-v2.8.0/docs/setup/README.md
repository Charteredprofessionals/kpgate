# Setup Documentation

This section contains setup and configuration guides.

## 📄 Available Documents

- **[Kiro IDE Integration Guide](KIRO_IDE_INTEGRATION_GUIDE.md)** - IDE setup and configuration
- **[Environment Setup](ENVIRONMENT_SETUP.md)** - Development environment setup

## 🎯 Purpose

These documents help users set up and configure the KiroProxy Gateway with Kiro IDE.

---

**Part of KiroProxy Gateway Documentation**