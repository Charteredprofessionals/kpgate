# Ngrok Setup Guide - Port 8084 Configuration

**Target:** Configure Ngrok tunnel for KiroProxy Gateway on primary port 8084

**Configuration:** The proxy runs exclusively on port 8084; configure your ngrok authtoken to enable remote access

---

## Solution: Add Your Ngrok Token

### Option 1: Add to User Config (Recommended)

Edit `~/.kiro/kiro_ai_config.json` and add your ngrok token:

```json
{
  "ngrokAuthtoken": "YOUR_NGROK_TOKEN_HERE",
  "provider": "auto",
  ...
}
```

### Option 2: Add to .env File

Edit `.env` in project root:

```env
NGROK_TOKEN=YOUR_NGROK_TOKEN_HERE
NGROK_AUTHTOKEN=YOUR_NGROK_TOKEN_HERE
```

### Option 3: Add to Project Config

Edit `scripts/kiro_ai_config.json`:

```json
{
  "ngrokAuthtoken": "YOUR_NGROK_TOKEN_HERE",
  "provider": "auto",
  ...
}
```

---

## Get Your Ngrok Token

1. Go to: https://dashboard.ngrok.com/get-started/your-authtoken
2. Sign in (free account)
3. Copy your authtoken
4. Add it using one of the options above

---

## How It Works

### Port Configuration

```
Main Proxy Server:     Port 8084  ← Ngrok tunnels THIS port
```

### Ngrok Configuration in Code

```javascript
const listener = await ngrok.forward({ 
  addr: PROXY_PORT,  // This is 8084
  authtoken: token 
});
```

**This is CORRECT** - ngrok forwards port 8084.

---

## Verify It's Working

### 1. Start the server with your token configured:

```powershell
node scripts/kiro_proxy_server.js
```

### 2. You should see:

```
══════════════════════════════════════════════════════════════════════
  🌐 REMOTE ACCESS ENABLED
══════════════════════════════════════════════════════════════════════
  Public URL: https://xxxx-xx-xx-xx-xx.ngrok-free.app
  
  Configure Kiro IDE to use this URL:
  AWS Base URL: https://xxxx-xx-xx-xx-xx.ngrok-free.app
  OpenAI Base URL: https://xxxx-xx-xx-xx-xx.ngrok-free.app/v1
══════════════════════════════════════════════════════════════════════
```

### 3. Test the tunnel:

```powershell
# Get your tunnel URL from the startup message, then:
curl https://YOUR-NGROK-URL/health
```

Should return: `{"status":"ok","message":"KiroProxy Active",...}`

---

## Troubleshooting

### Issue: "No authtoken configured"

**Solution:** Add token using one of the 3 options above

### Issue: "Ngrok not installed"

**Solution:**
```powershell
npm install @ngrok/ngrok
```

### Issue: "Address already in use"

**Solution:** Kill existing ngrok process:
```powershell
Get-Process | Where-Object {$_.ProcessName -match "ngrok"} | Stop-Process
```

### Issue: Token not being read

**Check priority order:**
1. Project config: `scripts/kiro_ai_config.json`
2. User config: `~/.kiro/kiro_ai_config.json`
3. Environment: `process.env.NGROK_AUTHTOKEN`
4. Environment: `process.env.NGROK_TOKEN`

The code checks in this order and uses the first valid token found.

---

## Quick Fix Script

Run this to add your token to the user config:

```powershell
$token = Read-Host "Enter your ngrok authtoken"

# Create user config directory if needed
$configDir = "$env:USERPROFILE\.kiro"
if (!(Test-Path $configDir)) {
    New-Item -ItemType Directory -Path $configDir -Force
}

# Update or create config
$configPath = "$configDir\kiro_ai_config.json"
if (Test-Path $configPath) {
    $config = Get-Content $configPath | ConvertFrom-Json
} else {
    $config = @{
        provider = "auto"
        providers = @{}
    }
}

$config.ngrokAuthtoken = $token

$config | ConvertTo-Json -Depth 10 | Set-Content $configPath

Write-Host "✅ Ngrok token added to $configPath" -ForegroundColor Green
Write-Host "Restart the proxy server to activate the tunnel" -ForegroundColor Cyan
```

---

## Expected Behavior

### Without Token (Current State)
```
[Ngrok] No authtoken configured — running on localhost only.
  Get free token: https://dashboard.ngrok.com/get-started/your-authtoken
  Add to ~/.kiro/kiro_ai_config.json: { "ngrokAuthtoken": "your_token" }
```

### With Token (Desired State)
```
[Ngrok] Starting tunnel...

══════════════════════════════════════════════════════════════════════
  🌐 REMOTE ACCESS ENABLED
══════════════════════════════════════════════════════════════════════
  Public URL: https://xxxx.ngrok-free.app
  
  Configure Kiro IDE to use this URL:
  AWS Base URL: https://xxxx.ngrok-free.app
  OpenAI Base URL: https://xxxx.ngrok-free.app/v1
══════════════════════════════════════════════════════════════════════
```

---

## Summary

**The code is CORRECT** - ngrok tunnels port 8084 (the main server).

**What you need to do:**
1. Get your ngrok authtoken from https://dashboard.ngrok.com
2. Add it to `~/.kiro/kiro_ai_config.json` as `"ngrokAuthtoken": "YOUR_TOKEN"`
3. Restart the proxy server
4. Ngrok will tunnel port 8084 and give you a public URL
