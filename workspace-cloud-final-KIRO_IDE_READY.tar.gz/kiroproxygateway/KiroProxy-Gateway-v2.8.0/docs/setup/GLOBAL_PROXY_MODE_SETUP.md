# Global Proxy Mode Setup Guide

**Purpose:** Configure Kiro IDE to use direct execution (no workflows) across ALL projects when using KiroProxy Gateway  
**Location:** `~/.kiro/steering/proxy-mode.md` (Global user settings)  
**Status:** ✅ Configured and Active

---

## 🎯 What This Does

The `proxy-mode.md` steering file in your **global Kiro settings** automatically:

1. ✅ **Detects proxy models** - Activates when using `kilo-*`, `cline-*`, `openrouter-*`, `orca-*`, `gemini-*`, `ngrok-*`, `custom-*`, or `auto`
2. ✅ **Disables workflows** - Prevents `run_workflow` calls that would fail with proxy
3. ✅ **Enables direct execution** - Uses file operations, terminal commands, MCP tools instead
4. ✅ **Provides structured pipeline** - Guides AI through 13-turn feature implementation process
5. ✅ **Applies to ALL projects** - Works in every workspace without per-project configuration

---

## 📁 File Location

```
Windows:
C:\Users\<YourUsername>\.kiro\steering\proxy-mode.md

Linux/macOS:
~/.kiro/steering/proxy-mode.md
```

**Current location:** `C:\Users\cscha\.kiro\steering\proxy-mode.md` ✅

---

## 🔄 How It Works

### Automatic Activation

```
┌─────────────────────────────────────────────────────────────┐
│  User selects model: "kilo-auto" (or any proxy model)       │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  Kiro IDE Agent starts session                              │
│  • Checks model name                                        │
│  • Matches pattern: kilo-* ✅                               │
│  • Loads: ~/.kiro/steering/proxy-mode.md                    │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  Agent reads steering content                               │
│  • Sees: "Workflow Tools STRICTLY FORBIDDEN"                │
│  • Sees: "MANDATORY DIRECT EXECUTION"                       │
│  • Sees: 13-turn implementation pipeline                    │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  Agent behavior changes                                     │
│  ❌ Will NOT try run_workflow                              │
│  ✅ Will use read_file, str_replace, execute_pwsh, etc.    │
│  ✅ Will follow structured 13-turn pipeline                 │
└─────────────────────────────────────────────────────────────┘
```

### Model Pattern Matching

The steering file activates for these model patterns:

| Pattern | Examples | Activation |
|---------|----------|------------|
| `auto` | `auto` | ✅ Always |
| `kilo-*` | `kilo-auto`, `kilo-free`, `kilogateway` | ✅ All Kilo |
| `cline-*` | `cline-auto`, `cline-free`, `cline-deepseek-v4-flash` | ✅ All Cline |
| `openrouter-*` / `or-*` | `openrouter-free`, `or-claude` | ✅ All OpenRouter |
| `orca-*` / `orcarouter` | `orca-free`, `orcarouter/auto` | ✅ All OrcaRouter |
| `gemini-*` | `gemini-2.5-flash`, `gemini-2.0-flash` | ✅ All Gemini |
| `ngrok-*` | `ngrok-gemini-flash` | ✅ All Ngrok/Canvas |
| `custom-*` | `custom-groq`, `custom-glm` | ✅ All Custom |

**Native Cloud models:** `claude-3-7-sonnet`, `claude-3-5-sonnet` (no prefix) → ❌ Steering does NOT activate, workflows available

---

## 📋 What's Included

### 1. Workflow Tool Blocking
```markdown
### ⛔ RULES FOR GATEWAY PROVIDERS:
1. **Workflow Tools STRICTLY FORBIDDEN:** 
   DO NOT call run_workflow, inspect_workflow, update_workflow, validate_workflow
```

### 2. Direct Execution Tools
```markdown
3. **MANDATORY DIRECT EXECUTION:**
   - File Operations: read_file, str_replace, fs_write, fs_append
   - Code Analysis: grep_search, file_search, read_code
   - Terminal: execute_pwsh, control_pwsh_process
   - MCP Tools: Any configured MCP tools
```

### 3. Structured 13-Turn Pipeline

**Phase 1: Setup & Requirements (Turns 1-2)**
- Turn 1: Project analysis
- Turn 2: Requirements discussion

**Phase 2: Design & Planning (Turns 3-5)**
- Turn 3: Design proposal
- Turn 4: Design refinement
- Turn 5: Implementation plan

**Phase 3: Implementation (Turns 6-10)**
- Turn 6: Core data structures
- Turn 7: Business logic
- Turn 8: API/interface layer
- Turn 9: Integration
- Turn 10: Error handling

**Phase 4: Validation (Turns 11-13)**
- Turn 11: Testing
- Turn 12: Bug fixes
- Turn 13: Final verification

### 4. Key Principles
- Incremental progress
- Transparency
- User collaboration
- Iterative refinement
- Verification first

---

## ✅ Benefits of Global Setup

### Compared to Project-Level Configuration

| Aspect | Project-Level | Global Level (Current) |
|--------|---------------|------------------------|
| **Scope** | Single project only | ALL projects |
| **Maintenance** | Update each project | Update once |
| **New projects** | Must configure each time | Works immediately |
| **Consistency** | May vary per project | Consistent everywhere |
| **Setup effort** | High (repeated) | Low (one-time) |

### User Experience

**Before Global Setup:**
```
New Project 1: ❌ Workflows fail → Must add .kiro/steering/proxy-mode.md
New Project 2: ❌ Workflows fail → Must add .kiro/steering/proxy-mode.md
New Project 3: ❌ Workflows fail → Must add .kiro/steering/proxy-mode.md
```

**After Global Setup:**
```
New Project 1: ✅ Direct execution works automatically
New Project 2: ✅ Direct execution works automatically
New Project 3: ✅ Direct execution works automatically
```

---

## 🔧 Verification

### Check Installation
```powershell
# Windows
Test-Path "$env:USERPROFILE\.kiro\steering\proxy-mode.md"
# Expected: True

# Linux/macOS
test -f ~/.kiro/steering/proxy-mode.md
# Expected: (no output = success)
```

### View Content
```powershell
# Windows
Get-Content "$env:USERPROFILE\.kiro\steering\proxy-mode.md" | Select-Object -First 20

# Linux/macOS
head -20 ~/.kiro/steering/proxy-mode.md
```

### Test Activation
1. **Restart Kiro IDE** (important - loads new steering on startup)
2. **Select proxy model:** Choose `kilo-auto` or `auto`
3. **Ask complex question:** "Implement a new feature"
4. **Observe behavior:**
   - ✅ Agent reads project files directly
   - ✅ Agent proposes design and plan
   - ✅ Agent asks for user review
   - ❌ NO `run_workflow` attempts

---

## 🔄 Switching Between Modes

### Use Proxy Mode (Direct Execution)
**Already active!** Just use proxy models:
- Select: `kilo-auto`, `cline-free`, `openrouter-free`, `auto`, etc.
- Result: Direct execution, no workflows

### Use Cloud Mode (Workflows Available)
1. Select native cloud model: `claude-3-7-sonnet` (no prefix)
2. Sign in to AWS/Kiro Cloud
3. Result: Workflows available, steering does NOT activate

### Override for Specific Project
If you want workflows in ONE project while using proxy:
1. Create `.kiro/config.json` in that project:
   ```json
   {
     "mode": "cloud",
     "features": {
       "workflows": true
     }
   }
   ```
2. Project-level config overrides global steering

---

## 📊 What Happens in Each Mode

### Proxy Mode (Current Setup)
```
User: "Build authentication system"
  ↓
Agent sees: proxy-mode.md steering
  ↓
Agent follows: 13-turn pipeline
  ↓
Turn 1-2:   Analyze project, discuss requirements
Turn 3-5:   Design & planning
Turn 6-10:  Incremental implementation
Turn 11-13: Testing & validation
  ↓
Result: ✅ Feature implemented (30-45 min, FREE)
```

### Cloud Mode (Without Steering)
```
User: "Build authentication system"
  ↓
Agent decides: "This needs feature-pipeline workflow"
  ↓
Agent calls: run_workflow({
  workflowPath: "bundled://feature-pipeline",
  inputs: { task: "...", workdir: "..." }
})
  ↓
Cloud runs: 6-step automated workflow
  ↓
Result: ✅ Feature implemented (10 min, requires subscription)
```

---

## 🛠️ Customization

### Edit Global Steering
```powershell
# Windows
notepad "$env:USERPROFILE\.kiro\steering\proxy-mode.md"

# Linux/macOS
nano ~/.kiro/steering/proxy-mode.md
# or
code ~/.kiro/steering/proxy-mode.md
```

### Common Customizations

**1. Add More Model Patterns:**
```markdown
* **Your Custom Pattern:** `mycustom-*`
```

**2. Adjust Pipeline Turns:**
```markdown
#### **Phase 3: Implementation (Turns 6-15)**
- (Expand to 15 turns for very complex features)
```

**3. Add Project-Specific Instructions:**
```markdown
### 🎯 PROJECT-SPECIFIC GUIDANCE:
- For React projects: Use hooks, not class components
- For Node.js: Prefer async/await over callbacks
```

**4. Change Principles:**
```markdown
### 🎯 KEY PRINCIPLES:
1. Security First: Always validate inputs
2. Performance: Optimize database queries
3. (Your custom principles here)
```

**After editing:** Restart Kiro IDE to load changes

---

## 🚨 Troubleshooting

### Issue: Workflows Still Attempted

**Symptoms:**
- Agent tries to call `run_workflow`
- Error: "Not supported in proxy mode"

**Solutions:**
1. **Restart Kiro IDE** - Steering loads on startup
2. **Check model name** - Must match proxy patterns (kilo-*, etc.)
3. **Verify file exists:**
   ```powershell
   Test-Path "$env:USERPROFILE\.kiro\steering\proxy-mode.md"
   ```
4. **Check frontmatter:**
   ```markdown
   ---
   inclusion: auto
   ---
   ```
   Must have `inclusion: auto` for automatic loading

---

### Issue: Direct Execution Not Structured

**Symptoms:**
- Agent works directly but doesn't follow pipeline
- Implementation is unorganized

**Solutions:**
1. **Explicitly request structure:**
   ```
   "Follow the 13-turn implementation pipeline for this feature"
   ```
2. **Check steering is loaded:**
   - Agent should mention phases/turns in responses
   - If not, steering may not be active

---

### Issue: Want Workflows Back

**Solution:**
1. **Use native cloud model:** Select `claude-3-7-sonnet` (no prefix)
2. **Or temporarily disable:**
   ```powershell
   # Rename to disable
   Rename-Item "$env:USERPROFILE\.kiro\steering\proxy-mode.md" `
                "$env:USERPROFILE\.kiro\steering\proxy-mode.md.disabled"
   
   # Restart Kiro IDE
   ```
3. **Re-enable later:**
   ```powershell
   Rename-Item "$env:USERPROFILE\.kiro\steering\proxy-mode.md.disabled" `
                "$env:USERPROFILE\.kiro\steering\proxy-mode.md"
   ```

---

## 📚 Related Documentation

- **[Direct Execution Pipeline Guide](../guides/WORKFLOWS_AND_PROXY_MODE.md)** - Complete usage guide
- **[Why Workflows Fail in Proxy](../troubleshooting/WHY_WORKFLOWS_FAIL_IN_PROXY.md)** - Technical explanation
- **[Kiro IDE Integration Guide](KIRO_IDE_INTEGRATION_GUIDE.md)** - Initial setup
- **[Quick Start](../guides/QUICK_START_v2.md)** - Getting started

---

## 🎓 Best Practices

### 1. Always Restart After Changes
```
Edit proxy-mode.md → Restart Kiro IDE → Changes active
```

### 2. Use Project Config for Exceptions
```
Most projects: Global steering (direct execution)
Special project: .kiro/config.json (enable workflows)
```

### 3. Document Your Customizations
```markdown
<!-- Custom Addition: 2026-10-08 -->
<!-- Reason: Our team prefers TypeScript strict mode -->
* **TypeScript Projects:** Always use strict mode
```

### 4. Keep Backup
```powershell
# Before major changes
Copy-Item "$env:USERPROFILE\.kiro\steering\proxy-mode.md" `
          "$env:USERPROFILE\.kiro\steering\proxy-mode.md.backup"
```

---

## 📊 Summary

| Aspect | Status |
|--------|--------|
| **Location** | `~/.kiro/steering/proxy-mode.md` |
| **Scope** | All projects globally |
| **Activation** | Automatic (inclusion: auto) |
| **Model patterns** | kilo-*, cline-*, openrouter-*, orca-*, gemini-*, ngrok-*, custom-*, auto |
| **Workflow tools** | Blocked (run_workflow, etc.) |
| **Direct execution** | Enabled (file ops, terminal, MCP) |
| **Pipeline** | 13-turn structured implementation |
| **Maintenance** | One-time setup, update once for all projects |
| **User action** | None (already configured ✅) |

---

## ✅ Current Status

**Installation:** ✅ Complete  
**Location:** `C:\Users\cscha\.kiro\steering\proxy-mode.md`  
**Activation:** ✅ Automatic for all proxy models  
**Coverage:** ✅ All projects in your workspace  
**Next step:** Restart Kiro IDE to activate  

---

**Last Updated:** 2026-10-08  
**Version:** 2.8.0  
**Configuration:** Global (user-level)
