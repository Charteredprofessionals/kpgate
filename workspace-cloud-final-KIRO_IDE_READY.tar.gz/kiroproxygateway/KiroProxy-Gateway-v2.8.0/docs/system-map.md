# System Map — KiroProxy Gateway

```mermaid
flowchart TD
    subgraph Client ["IDE Layer"]
        KIRO["Kiro IDE (VS Code Fork)"]
        EXT["kiro.kiro-agent Extension\n(patched dist/extension.js)"]
        KIRO --> EXT
    end

    subgraph Gateway ["KiroProxy Gateway (127.0.0.1:8084)"]
        HTTP["HTTP Router (Line 5609)"]
        AUTH["AWS Auth Bypass & Synthetic Profile"]
        CATALOG["Dynamic Model Catalog (MODELS)"]
        QUEUE["Gemini In-Memory Queue (geminiQueue)"]
        CIRCUIT["Circuit Breakers (CIRCUIT_BREAKERS)"]
        DISPATCH["Inference Dispatcher (dispatchInference)"]
        STREAM["EventStream Binary Encoder (createEventStreamFrame)"]
        PARSER["Multi-Format Tool Parser (extractToolCallsFromResponse)"]

        HTTP --> AUTH
        HTTP --> CATALOG
        HTTP --> QUEUE
        HTTP --> DISPATCH
        DISPATCH --> CIRCUIT
        DISPATCH --> PARSER
        DISPATCH --> STREAM
    end

    subgraph Upstream ["Upstream Providers"]
        KILO["Tier 1: Kilo Gateway (api.kilo.ai)"]
        CLINE["Tier 2: Cline API (api.cline.bot)"]
        OPENROUTER["Tier 3: OpenRouter (openrouter.ai)"]
        ORCAROUTER["Tier 4: OrcaRouter (api.orcarouter.ai)"]
        GEMINI["Tier 5: Gemini API (generativelanguage.googleapis.com)"]
        CUSTOM["Tier 6: Custom APIs (Groq / GLM / Abhyast)"]
        BRIDGE["Fallback: Ngrok Canvas Bridge (gemini.google.com)"]
    end

    EXT -->|"Converse / Models Probe"| HTTP
    STREAM -->|"EventStream frames (CRC32)"| EXT

    DISPATCH --> KILO
    DISPATCH --> CLINE
    DISPATCH --> OPENROUTER
    DISPATCH --> ORCAROUTER
    DISPATCH --> GEMINI
    DISPATCH --> CUSTOM
    QUEUE <-->|"Long-Poll (/poll, /chunk, /done)"| BRIDGE
```

## Module Directory

| Module Path | Responsibility | Depends On | Depended On By | Classification |
| :--- | :--- | :--- | :--- | :--- |
| [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Central server: routes HTTP requests, emulates AWS Bedrock Smithy protocol, encodes EventStream frames, handles multi-provider dispatching, parses tool calls. | Node `http`, `https`, `zlib`, `@ngrok/ngrok`, `dotenv`, [`scripts/utils/global_automode_interceptor.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/global_automode_interceptor.js) | Kiro IDE, Canvas Userscript | `[FACT]` |
| [`scripts/patch_kiro_extension.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/patch_kiro_extension.js) | Dual-mode AST patcher for Kiro IDE's `kiro.kiro-agent/dist/extension.js`. Redirects `listAvailableModels`, `getTarget()`, and Bedrock clients when port 8084 is live. | Node `fs`, `path` | Kiro IDE startup | `[FACT]` |
| [`scripts/utils/global_automode_interceptor.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/global_automode_interceptor.js) | Monkey-patches `global.fetch` to parse comma-separated multi-provider URLs and execute two-tier retry failovers. | Global `fetch` | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | `[FACT]` |
| [`scripts/utils/request_queue.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/request_queue.js) | Standalone priority request queue (`high`, `normal`, `low`) capping concurrency to 10 in-flight jobs. | Node `events` | Standalone utility / Tests | `[FACT]` |
| [`scripts/utils/api_key_rotator.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/api_key_rotator.js) | Standalone round-robin and least-used key rotation manager with cooldown periods. | Node `events`, [`scripts/utils/validators.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/validators.js) | Standalone utility / Tests | `[FACT]` |
| [`scripts/utils/smart_retry_engine.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/smart_retry_engine.js) | Exponential backoff retry engine with ±20% jitter and cross-provider sequential fallback. | Node timers | Standalone utility / Tests | `[FACT]` |
| [`scripts/utils/validators.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/validators.js) | Schema enforcement and parameter bound validation for tools, model IDs, and queue configs. | Node `Error` | Standalone utility / Tests | `[FACT]` |
| [`scripts/utils/structured_logger.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/structured_logger.js) | Leveled JSON logger with performance timers and correlation tracking. | Node `console` | Standalone utility / Tests | `[FACT]` |
| [`scripts/utils/verify_proxy_mode.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/verify_proxy_mode.js) | Health verification script validating configuration files, steering documents, and proxy port 8084. | Node `http`, `fs` | Batch scripts, CI checks | `[FACT]` |

## Entry Points

1. **CLI / Daemon Server**:
   - Command: `node scripts/kiro_proxy_server.js` or `npm start`
   - Port: `127.0.0.1:8084` (`process.env.PROXY_PORT || 8084`)
   - Initialization: Loads configuration, starts HTTP server, initialises circuit breakers, starts Ngrok tunnel (if authtoken present), syncs model catalog.
2. **Kiro Extension Dual-Mode Patcher**:
   - Command: `node scripts/patch_kiro_extension.js` (`--check`, `--restore`)
   - Target: `%LOCALAPPDATA%\Programs\Kiro\resources\app\extensions\kiro.kiro-agent\dist\extension.js`
   - Mechanism: Replaces minified functions with probe checks to `http://127.0.0.1:8084`.
3. **Web Interfaces**:
   - Canvas Dashboard: `http://127.0.0.1:8084/canvas`
   - Config Management GUI: `http://127.0.0.1:8084/config.html`
   - Userscript CDN: `http://127.0.0.1:8084/gemini_bridge.user.js`

## Background Jobs & Periodic Timers

| Job Function | Interval | Purpose | File & Line |
| :--- | :--- | :--- | :--- |
| `cleanStaleQueueEntries()` | Every 60,000ms | Sweeps `geminiQueue` and rejects requests older than `MAX_QUEUE_AGE` (300,000ms / 5 min). | [`kiro_proxy_server.js:457-482, 518`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L457) |
| `pollRateLimiter` cleanup | Every 120,000ms | Prunes sliding window IP rate limiting maps for Canvas Bridge long-poll requests. | [`kiro_proxy_server.js:512-515`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L512) |
| `autoPopulateFreeModels()` | Throttled (15 min) | Fetches live free model lists from Kilo, OpenRouter, and custom endpoints; syncs into `globalAutomodeInterceptor`. | [`kiro_proxy_server.js:2054-2074`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L2054) |

## External Services & Network Dependencies

- **Local Host**: `127.0.0.1:8084`
- **Ngrok Ingress**: `https://<subdomain>.ngrok-free.dev` via `@ngrok/ngrok` Node SDK.
- **Provider API Endpoints**:
  - Kilo Gateway: `https://api.kilo.ai/api/v1`
  - Cline API: `https://api.cline.bot/api/v1`
  - OpenRouter: `https://openrouter.ai/api/v1`
  - OrcaRouter: `https://api.orcarouter.ai/api/v1`
  - Gemini Direct: `https://generativelanguage.googleapis.com/v1beta`
  - Custom Groq: `https://api.groq.com/openai/v1`
  - Custom GLM: `https://devgateway.space-z.ai/api/v1`
  - Custom Abhyast: `https://corset-decipher-vocation.ngrok-free.dev/api/v1`
  - Gemini Canvas Bridge: WebSocket/HTTP browser session at `https://gemini.google.com`
