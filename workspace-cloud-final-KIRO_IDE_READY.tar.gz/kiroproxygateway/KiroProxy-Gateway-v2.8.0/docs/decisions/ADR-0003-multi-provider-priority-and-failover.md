# ADR-0003: Multi-Provider Priority and Global Automode Failover Hierarchy

- **Status:** Accepted
- **Date:** 2026-09-10
- **Deciders:** Core Architecture Team
- **Component:** [`scripts/kiro_proxy_server.js#L4199-L4256`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), [`scripts/utils/global_automode_interceptor.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/global_automode_interceptor.js)

---

## Context
Third-party free LLM endpoints (Kilo Gateway, Cline API, OpenRouter free models, OrcaRouter, Gemini API) experience frequent rate-limiting (HTTP 429), quota depletion, model deprecations, and upstream outages. If the proxy relies on a single upstream provider, developers encounter repeated work interruptions.

Furthermore, different providers have distinct cost profiles: Kilo Gateway offers a completely keyless free tier, whereas Cline, OpenRouter, and Gemini require personal API keys with strict token quotas.

## Decision
Implement a deterministic 6-tier fallback hierarchy under the virtual model `global-automode` (Mode 3):
1. **Tier 1 — Kilo Gateway:** Zero-key required, primary free tier.
2. **Tier 2 — Cline API:** Requires `CLINE_API_KEY`, secondary high-reliability tier.
3. **Tier 3 — OpenRouter:** Requires `OPENROUTER_API_KEY`, wide model selection.
4. **Tier 4 — OrcaRouter:** Requires `ORCAROUTER_API_KEY`, multi-key rotating backup tier.
5. **Tier 5 — Gemini API:** Requires `GEMINI_API_KEY`, direct Google AI endpoint.
6. **Tier 6 — Custom Providers:** User-configured endpoints (Groq, GLM, Abhyast).

**Exclusion Rule:** The Ngrok Canvas Bridge (`ngrok-*`) is **strictly excluded** from Global Automode. Because Canvas Bridge relies on browser userscript DOM scraping, routing automatic failovers into Canvas would block requests for up to 120s if the user's browser tab is idle.

Each provider is guarded by an independent Circuit Breaker (5 consecutive failures trip to `OPEN` for 60 seconds). If a provider fails, the failover engine seamlessly transitions to the next available provider within the same HTTP session.

## Alternatives (Evidenced in Code/Docs)
1. **Random Round-Robin Load Balancing:** Rejected because it exhausts quota-limited personal API keys when zero-key free providers are fully operational.
2. **Including Canvas Bridge in Automode:** Evaluated in early v2.4 builds and rejected due to unacceptable 30-120s browser throttling latency freezing IDE chat.

## Consequences
- **Positive:** Maximum session continuity. If Kilo Gateway experiences downtime, the user's coding prompt succeeds automatically via Cline or OpenRouter without user intervention.
- **Negative:** If all configured upstream providers fail, total failover evaluation can consume up to 180s (enforced by `MAX_CUMULATIVE_TIMEOUT_MS`).

## Do Not Change Unless
Do not change the provider order unless Kilo Gateway introduces mandatory credit billing or restricts free usage, or a new zero-key provider offers superior latency and reliability.

## Evidence
- Implementation: [`scripts/kiro_proxy_server.js#L4199-L4256`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), [`scripts/utils/global_automode_interceptor.js#L50-L90`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/global_automode_interceptor.js)
- Test Verification: [`tests/test_provider_inference.js#L231`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_provider_inference.js), [`tests/e2e/tier1_features.test.js#L50`](file:///d:/sdlc_studio/projects/kiro-integration/tests/e2e/tier1_features.test.js)
