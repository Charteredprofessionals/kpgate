# ADR-0002: AWS EventStream CRC32 Binary Protocol Emulation

- **Status:** Accepted
- **Date:** 2026-08-25
- **Deciders:** Core Architecture Team
- **Component:** [`scripts/kiro_proxy_server.js#L2077-L2150`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)

---

## Context
When Kiro IDE sends a `POST /generateAssistantResponse` request, its underlying AWS SDK client expects responses formatted strictly as binary `application/vnd.amazon.eventstream` packets. Each packet contains a 12-byte prelude, typed headers (string headers of type 7), payload bytes, and two separate 32-bit CRC checksums (Prelude CRC32 and Message CRC32).

If the proxy server returns standard OpenAI Server-Sent Events (`data: {"choices": ...}`), plain text, or corrupted binary frames with invalid CRC checksums, the IDE's Smithy deserializer throws fatal parse errors and immediately drops the connection.

## Decision
Implement a native binary frame builder (`createEventStreamFrame`) in pure Node.js using Buffer manipulation and standard IEEE 802.3 CRC32 polynomial table calculation (`0xEDB88320`).
- **Prelude (12 bytes):**
  - Bytes 0..3: Total byte length (BE UInt32)
  - Bytes 4..7: Headers byte length (BE UInt32)
  - Bytes 8..11: CRC32 of bytes 0..7 (BE UInt32)
- **Headers:** String headers encoded with length prefix and header type `7`.
- **Payload:** JSON string payload (`assistantResponseEvent`, `toolUseEvent`, or `metadataEvent`).
- **Trailing (4 bytes):** CRC32 calculated over the entire frame (bytes 0 to end of payload).
- **Stringified Tool Input:** The `toolUseEvent` payload `input` attribute MUST be serialized as a JSON string (`JSON.stringify(args)`), as required by the AWS Bedrock Smithy specification.

## Alternatives (Evidenced in Code/Docs)
1. **Adopting `@aws-sdk/eventstream-codec`:** Rejected to keep the proxy server zero-dependency and lightweight, eliminating external build or bundling constraints.
2. **Translating IDE to SSE:** Rejected because modifying Kiro IDE's low-level deserialization pipeline inside `extension.js` requires altering compiled native C++ bindings and minified network clients.

## Consequences
- **Positive:** Perfect 100% protocol compatibility with Kiro IDE chat, agent mode, and streaming responses without modifying IDE protocol decoders.
- **Negative:** Bit-level buffer offsets and CRC calculations are fragile. Any modification without byte-level unit tests can break streaming.

## Do Not Change Unless
Do not change unless AWS Bedrock deprecates the EventStream binary format in favor of standard HTTP/2 Server-Sent Events in Kiro IDE, and Kiro IDE stops checking Prelude and Message CRC32 checksums.

## Evidence
- Implementation: [`scripts/kiro_proxy_server.js#L2077-L2150`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)
- Test Verification: [`tests/test_kiro_tool_events.js#L72`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_kiro_tool_events.js), [`tests/e2e/tier1_features.test.js#L140`](file:///d:/sdlc_studio/projects/kiro-integration/tests/e2e/tier1_features.test.js)
