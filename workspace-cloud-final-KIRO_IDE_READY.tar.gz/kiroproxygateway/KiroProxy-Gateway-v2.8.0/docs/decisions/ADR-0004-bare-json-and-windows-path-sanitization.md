# ADR-0004: Inbound Bare JSON/XML Tool Parsing and Windows Path Sanitization

- **Status:** Accepted
- **Date:** 2026-10-10
- **Deciders:** Core Architecture Team
- **Component:** [`scripts/kiro_proxy_server.js#L2276-L2510`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)

---

## Context
When upstream models (DeepSeek V3, Kilo models, GLM-4, Gemini) execute tool calls, they frequently diverge from standard OpenAI structured `tool_calls` payloads:
1. **Unfenced Bare JSON (Format 1b):** DeepSeek models often output raw JSON objects directly in message text without markdown code blocks (` ```json `) or tool names.
2. **Direct XML Tags (Format 6b):** GLM-4 and Gemini models output raw XML tool tags like `<read_file>path/to/file</read_file>` without wrapper function syntax.
3. **Shell Command Aliases:** Models output natural terminal commands (`ls`, `dir`, `cat`, `read`, `grep`) instead of Kiro's formal tool names (`list_directory`, `read_file`, `grep_search`).
4. **Windows Path Backslash Invalidation:** Windows filesystem paths inside JSON strings (e.g., `"d:\sdlc_studio\tests"`) contain unescaped single backslashes. Calling standard `JSON.parse()` crashes with `SyntaxError: Bad escape sequence in string` (e.g. `\s` or `\t`).

Without robust sanitization and heuristic extraction, tool invocations fail, leaking raw JSON or XML into the user's chat window as text, and breaking autonomous agent execution.

## Decision
Implement a multi-stage inbound tool recovery pipeline in `extractToolCallsFromResponse()`:
1. **Windows Path Sanitization (`sanitizeJsonBackslashes`):** Pre-process raw JSON text using regular expressions with negative lookahead (`/(?<!\\)\\(?!["\\\/bfnrtu]|u[0-9a-fA-F]{4})/g`) to double unescaped backslashes before calling `JSON.parse()`.
2. **Format 1b (Bare JSON Recovery):** Heuristically detect unfenced JSON objects in message text, extract balanced braces, and infer tool names from property signatures (e.g. `"path"` → `read_file`, `"command"` → `execute_bash`).
3. **Format 6b (Direct XML Tag Recovery):** Parse inline XML tags `<tool_name>argument</tool_name>` into valid Kiro Smithy tool structures.
4. **Tool Name Normalization:** Map common shell command aliases (`ls`/`dir` → `list_directory`, `cat`/`read` → `read_file`, `grep` → `grep_search`).
5. **Text Stripping:** Strip the matched tool syntax from the assistant text body before emitting `toolUseEvent` to prevent duplicate tool representation in Kiro IDE.

## Alternatives (Evidenced in Code/Docs)
1. **Strict Prompt Engineering Only:** Rejected because upstream models (especially lightweight or open-source models) frequently ignore strict prompt output constraints when generating code.
2. **Failing on Invalid JSON:** Rejected because it causes complete agent stoppage on Windows developer machines.

## Consequences
- **Positive:** Autonomous agent workflows succeed reliably across heterogeneous models (DeepSeek, GLM, Gemini) on Windows, macOS, and Linux without UI leaks.
- **Negative:** Regex parsing adds slight CPU overhead (~1-3ms per response) and requires careful regression testing to prevent ReDoS on large text payloads.

## Do Not Change Unless
Do not change this pipeline unless all upstream model providers guarantee 100% adherence to OpenAI-compliant structured `tool_calls` without emitting raw text, and eliminate all bare backslash path output.

## Evidence
- Implementation: [`scripts/kiro_proxy_server.js#L2276-L2510`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)
- Test Verification: [`tests/test_bare_json_tool_calls.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_bare_json_tool_calls.js) (9/9 unit tests passing), [`tests/test_tool_translation_layer.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_tool_translation_layer.js)
