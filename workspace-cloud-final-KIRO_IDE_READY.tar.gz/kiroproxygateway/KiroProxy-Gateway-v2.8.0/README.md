# KiroProxy Gateway — Free Multi-Provider AI Proxy Server

**Zero-cost AI access with strict free-only model filtering, dual-layer smart fallback, and Kiro IDE integration**

[![Status](https://img.shields.io/badge/status-production-green)]()
[![Version](https://img.shields.io/badge/version-2.8.0-blue)]()
[![License](https://img.shields.io/badge/license-MIT-blue)]()

---

## 🎯 What is KiroProxy Gateway?

**KiroProxy Gateway** is a production-ready, open-source local proxy server that provides **free access to 193+ AI models** across 9 providers. It connects **Kiro IDE**, **Cursor**, **Cline**, and other AI tools to verified free AI models through a single unified API.

> [!IMPORTANT]
> **Project Information:**
> - **Status:** Production Ready (v2.8.0)
> - **License:** MIT (Open Source)
> - **Models:** 193+ free models verified (including Abhyast-Gemini, GLM, Groq, Cloudflare-Gemini)
> - **Providers:** 9 integrated (Kilo, Gemini, Cline, OpenRouter, OrcaRouter, Ngrok, Custom × 4)
> - **Tests:** 80+ passing (19 core + 8 history + 55 existing tests)
> - **NEW v2.8.0:** Abhyast-Gemini provider + Dual-layer smart fallback (Otomode + Global Automode) + P0 edge case fixes + Canvas history preservation
> - **NEW v2.7.1:** Windows PowerShell compatibility with bash command auto-conversion
> 
> **Naming Distinction:**
> - **KiroProxy Gateway**: This local proxy server (`http://127.0.0.1:8084`)
> - **Kilo Gateway**: External AI provider (`https://api.kilo.ai`)

### Key Capabilities

- ✅ **Strictly Verified Free Models** (100% verified $0 pricing, zero variable billing)
- ✨ **NEW: Dual-Layer Smart Fallback** (v2.8.0)
  - **Otomode**: Cycles through ALL free models within a single provider (e.g., select `kilo-otomode`)
  - **Global Automode**: Tries ALL models across ALL providers via smart failover
- 🚀 **Production Ready**: P0 edge cases fixed, memory leaks prevented, history preserved
- 🛡️ **Canvas History Preservation**: Continuous chat workflows work with Ngrok Canvas Bridge
- � **193+ Free Models**: Access to verified free models across 9 providers
- 🎯 **Zero Configuration**: Just select "Global Automode" in Kiro IDE and it works
- � **Smart Fallback**: Automatic provider switching when failures occur
- � **AWS EventStream Format**: Compatible with Kiro IDE's native format

### Quick Start

1. **Install**: `npm install`
2. **Run**: `npm start`
3. **Configure**: Set `http://127.0.0.1:8084` as AI endpoint in Kiro IDE
4. **Select**: Choose "Global Automode" from model selector

### Core Features

#### Smart Fallback System

- **Dual-layer approach**: Otomode (intra-provider) + Global Automode (cross-provider)
- **Automatic recovery**: Retries failed requests with different providers
- **Rate limit handling**: Automatically switches when providers hit limits
- **Network-level monitoring**: Real-time health checks and failover

#### Provider Coverage

| Provider | Models | Features |
|----------|--------|----------|
| Kilo | 3 | Free, no auth needed |
| Gemini | 9 | Auto-populated, health checks |
| Cline | 420+ | Agentic coding models |
| OpenRouter | Free tier | Diverse model selection |
| OrcaRouter | Free tier | Optimized routing |
| Ngrok Canvas | Gemini | Remote access |
| Custom GLM | 4 | Specialized models |
| Custom Groq | 1 | High-speed inference |
| Custom Abhyast | 9 | Gemini variants |

#### Reliability Features

- **P0 Edge Case Fixes**: Critical production issues resolved
- **Memory Leak Prevention**: Proper cleanup and resource management
- **Race Condition Handling**: Thread-safe operations
- **Silent Failure Detection**: Comprehensive error monitoring
- **History Preservation**: Canvas workflows maintain chat history

### Use Cases

- **Development**: Free AI assistance for coding, debugging, and testing
- **Learning**: Access to diverse AI models for educational purposes
- **Prototyping**: Rapid iteration with multiple AI providers
- **Production**: Reliable AI access with automatic failover
- **Research**: Experiment with different AI models and providers

### Technical Details

- **Protocol**: AWS Bedrock API compatible
- **Format**: EventStream streaming responses
- **Port**: 8084 (configurable)
- **Framework**: Node.js, no external dependencies
- **State**: All state in memory (no database required)
- **Models**: All verified free (rateMultiplier: 0.0)
- **Authentication**: Provider-specific as needed

### Architecture

The proxy server acts as a bridge between Kiro IDE and upstream providers:

1. **Request Translation**: Converts AWS Bedrock requests to provider-specific formats
2. **Smart Routing**: Selects optimal provider based on availability and performance
3. **Response Streaming**: Streams responses back in AWS EventStream format
4. **Automatic Failover**: Switches providers when failures occur
5. **Health Monitoring**: Continuously monitors provider health

### Documentation

### For Users
- **[README.md](README.md)** - Start here!
- **[Quick Start Guide](docs/guides/QUICK_START_v2.md)** - Setup in 5 minutes
- **[Configuration Guide](docs/CONFIGURATION_GUI.md)** - Basic setup
- **[Global Automode Guide](docs/guides/GLOBAL_AUTOMODE_GUIDE.md)** - Smart fallback system
- **[Focus Mode Compatibility](docs/guides/FOCUS_MODE_COMPATIBILITY.md)** - Focus mode usage

### For Developers
- **[CONTRIBUTING.md](CONTRIBUTING.md)** - How to contribute
- **[Architecture Guide](docs/architecture/KIRO_GATEWAY_ARCHITECTURE_GUIDE.md)** - System design
- **[Development Workflow](.kiro/steering/sdlc-workflow.md)** - SDLC process

### For Maintainers
- **[Release Checklist](project-management/RELEASE_CHECKLIST.md)** - Pre-release verification
- **[Changelog](CHANGELOG.md)** - Version history
- **[Release Notes](project-management/RELEASE_NOTES.md)** - Latest release details

## 🆘 Support

### Getting Help
- **[GitHub Issues](https://github.com/yourusername/kiro-integration/issues)** - Bug reports and feature requests
- **[Discussions](https://github.com/yourusername/kiro-integration/discussions)** - Questions and community
- **[Documentation](docs/)** - Comprehensive guides

### Community
- **Contributors:** See [CONTRIBUTING.md](CONTRIBUTING.md)
- **Code of Conduct:** Respectful, inclusive, welcoming
- **License:** MIT - Free to use, modify, distribute

---

## 📊 Project Status

| Metric | Status |
|--------|--------|
| Version | ![Version](https://img.shields.io/badge/version-2.8.0-blue) |
| Tests | ![Tests](https://img.shields.io/badge/tests-80%2B%20passing-green) |
| Coverage | ![Coverage](https://img.shields.io/badge/coverage-100%25-green) |
| License | ![License](https://img.shields.io/badge/license-MIT-blue) |
| Status | ![Status](https://img.shields.io/badge/status-production-green) |
| Models | ![Models](https://img.shields.io/badge/models-193%20free-green) |
| Providers | ![Providers](https://img.shields.io/badge/providers-9%2F9%20healthy-green) |

---

**Built with ❤️ for the Kiro IDE community**