# KiroProxy Gateway v2.8.0 - Cloud Deployment Guide

## ✅ Kiro IDE Compatibility Status

This deployment is **FULLY COMPATIBLE** with Kiro IDE patching.

### Required Endpoints (All Implemented)

- ✅ `/listAvailableModels` - AWS Bedrock model discovery
- ✅ `/v1/models` - OpenAI-compatible model list
- ✅ `/generateAssistantResponse` - AWS Bedrock streaming chat
- ✅ `/health` - Health check endpoint
- ✅ `/status` - Provider status endpoint
- ✅ `/config` - Configuration GUI

## Architecture

**Pure Node.js v22** - No TypeScript compilation required
- 137+ models via aggressive auto-discovery
- Zero-cost waterfall: `kilo → cline → openrouter → orcarouter → gemini → custom → canvas`
- Modular handler system in `src/` directory

## Deployment URL

**Production**: `https://kproxy.space-z.ai`

## Quick Start

### 1. Install Dependencies

```bash
cd kiroproxygateway/KiroProxy-Gateway-v2.8.0
npm install
```

### 2. Configure Environment

Create `.env` file:

```env
# Required for ngrok tunnel (if needed)
NGROK_AUTHTOKEN=your_token_here

# Optional provider API keys
CLINE_API_KEY=
OPENROUTER_API_KEY=
GEMINI_API_KEY=
```

### 3. Start Server

```bash
# Development
npm start

# Production (with PM2)
pm2 start src/index.js --name kiroproxy-gateway
```

Server runs on port **8085** by default (configurable via `PROXY_PORT` env var).

## Kiro IDE Integration

### Option 1: Direct HTTP (Local/VPN)

```json
{
  "bedrock": {
    "endpoint": "http://localhost:8085"
  }
}
```

### Option 2: ngrok Tunnel (Public Access)

The gateway automatically establishes an ngrok tunnel on startup if `NGROK_AUTHTOKEN` is configured.

```bash
curl http://localhost:8085/health | jq .tunnel
```

Use the tunnel URL in Kiro IDE configuration:

```json
{
  "bedrock": {
    "endpoint": "https://your-tunnel-id.ngrok-free.app"
  }
}
```

### Option 3: Cloud Deployment

For z.ai cloud deployment, the gateway is accessible at:

```
https://kproxy.space-z.ai
```

## Verification

### Check Model Discovery

```bash
# AWS Bedrock format
curl http://localhost:8085/listAvailableModels | jq '.models | length'

# OpenAI format
curl http://localhost:8085/v1/models | jq '.data | length'
```

### Test Chat Streaming

```bash
curl -X POST http://localhost:8085/generateAssistantResponse \
  -H "Content-Type: application/json" \
  -d '{
    "conversationState": {},
    "messages": [{"role": "user", "content": [{"text": "Hello"}]}]
  }'
```

## Provider Health Status

```bash
curl http://localhost:8085/status | jq
```

Shows:
- Circuit breaker states
- Success rates per provider
- Latency metrics
- Total request counts

## Configuration GUI

Access the web interface at: `http://localhost:8085/config`

Features:
- Add/remove API keys
- Configure custom providers
- Adjust provider priority order
- View real-time health status

## Key Differences from tmp_cloud_audit

| Feature | Modular (v2.8.0) | tmp_cloud_audit |
|---------|------------------|-----------------|
| Runtime | Pure Node.js | TypeScript + tsx |
| Port | 8085 | 8084 |
| Frontend | Minimal (config GUI only) | Full React 19 SPA |
| Bundle Size | ~5 MB | ~50+ MB |
| Cold Start | <2s | ~5-8s |
| `/listAvailableModels` | ✅ Implemented | ✅ Implemented |
| ngrok Integration | ✅ Native | ✅ Native |

## File Structure

```
KiroProxy-Gateway-v2.8.0/
├── src/
│   ├── index.js                    # Main HTTP server (< 150 lines)
│   ├── config/
│   │   ├── index.js               # Config loader
│   │   └── catalog.js             # Model auto-discovery
│   ├── handlers/
│   │   ├── bedrock_handler.js     # AWS Bedrock streaming
│   │   ├── diagnostics_handler.js # Health, status, /listAvailableModels
│   │   ├── canvas_handler.js      # Canvas bridge
│   │   └── workflow_handler.js    # Workflow endpoints
│   ├── protocol/
│   │   └── smithy_parser.js       # EventStream framing
│   ├── providers/
│   │   └── *.js                   # Provider adapters
│   ├── resilience/
│   │   ├── health.js              # Health checks + ngrok
│   │   ├── circuit_breaker.js     # Circuit breakers
│   │   └── metrics.js             # Telemetry
│   └── translators/
│       └── bedrock_translator.js  # Format conversions
├── config/
│   └── kiro_ai_config.json        # Runtime configuration
├── public/
│   └── config.html                # Web GUI
└── package.json
```

## Troubleshooting

### Models Not Appearing in Kiro IDE

1. Verify endpoint is accessible:
   ```bash
   curl http://localhost:8085/health
   ```

2. Check model count:
   ```bash
   curl http://localhost:8085/listAvailableModels | jq '.models | length'
   ```

3. Refresh provider health:
   ```bash
   curl -X POST http://localhost:8085/api/health/refresh
   ```

### ngrok Tunnel Not Establishing

1. Check authtoken is configured:
   ```bash
   grep NGROK_AUTHTOKEN .env
   ```

2. Verify ngrok module is installed:
   ```bash
   npm list @ngrok/ngrok
   ```

3. Check logs:
   ```bash
   tail -f logs/server.log
   ```

### Circuit Breakers Stuck Open

Reset all circuit breakers:

```bash
curl -X POST http://localhost:8085/api/circuit/reset
```

## Maintenance Commands

```bash
# View logs
tail -f logs/server.log

# Restart service (PM2)
pm2 restart kiroproxy-gateway

# View metrics
curl http://localhost:8085/metrics

# Force model refresh
curl -X POST http://localhost:8085/api/health/refresh
```

## Production Deployment Checklist

- [ ] Install Node.js v22+
- [ ] Run `npm install` in `kiroproxygateway/KiroProxy-Gateway-v2.8.0/`
- [ ] Configure `.env` with provider API keys
- [ ] Set `NGROK_AUTHTOKEN` if public access needed
- [ ] Start with PM2: `pm2 start src/index.js --name kiroproxy`
- [ ] Verify health: `curl http://localhost:8085/health`
- [ ] Test model discovery: `curl http://localhost:8085/listAvailableModels`
- [ ] Configure Kiro IDE to use endpoint
- [ ] Set up monitoring/alerts for `/status` endpoint

## Support

For issues or questions:
- Check logs in `logs/` directory
- Review health status at `/status`
- Verify provider configurations at `/config`
- Consult `docs/` directory for architecture details

---

**Last Updated**: 2026-10-11  
**Version**: 2.8.0  
**Deployment**: kproxy.space-z.ai
