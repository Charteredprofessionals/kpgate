# AGENTS.md — KiroProxy Gateway v2.8.0 Cloud Deployment - AI Maintenance Guide

> **CRITICAL INSTRUCTION FOR ALL AI CODING ASSISTANTS:**
> Before modifying code, read this file completely.
> After making code changes, update all affected documentation in this directory.

---

## 1. Project Summary

`KiroProxy Gateway v2.8.0 Cloud` is a production-ready, **Kiro IDE-compatible** proxy gateway deployed at `https://kproxy.space-z.ai`. It's a **Pure Node.js** (CommonJS) implementation that intercepts AWS Bedrock requests and transparently proxies them across a 7-tier zero-cost waterfall (`kilo → cline → openrouter → orcarouter → gemini → custom → canvas`).

**Key Characteristics**:
- ✅ **Pure JavaScript** - No TypeScript compilation
- ✅ **Port 8085** - Default runtime port
- ✅ **137+ Models** - Aggressive auto-discovery
- ✅ **Zero-cost inference** - Kilo provider default
- ✅ **<2s cold start** - Optimized for cloud deployment
- ✅ **~55 MB bundle** - Lightweight footprint

---

## 2. Documentation Index

| Documentation File | Read This When... |
| :--- | :--- |
| [`README.md`](file:///d:/sdlc_studio/projects/kiro-integration/dist/workspace-cloud-final/README.md) | **START HERE:** Overview, quick start, and getting oriented |
| [`KIRO_IDE_DEPLOYMENT.md`](file:///d:/sdlc_studio/projects/kiro-integration/dist/workspace-cloud-final/KIRO_IDE_DEPLOYMENT.md) | Setting up for first time deployment or Kiro IDE integration |
| [`QUICK_REFERENCE.md`](file:///d:/sdlc_studio/projects/kiro-integration/dist/workspace-cloud-final/QUICK_REFERENCE.md) | Need quick commands, endpoints, or configuration reference |
| [`DEPLOYMENT_CHECKLIST.md`](file:///d:/sdlc_studio/projects/kiro-integration/dist/workspace-cloud-final/DEPLOYMENT_CHECKLIST.md) | Performing production deployment with pre/post verification |
| [`ARCHITECTURE_COMPARISON.md`](file:///d:/sdlc_studio/projects/kiro-integration/dist/workspace-cloud-final/ARCHITECTURE_COMPARISON.md) | Comparing with tmp_cloud_audit or understanding architecture decisions |
| [`VERSION_MANIFEST.json`](file:///d:/sdlc_studio/projects/kiro-integration/dist/workspace-cloud-final/VERSION_MANIFEST.json) | Looking up technical specifications, endpoints, or metadata |
| `verify-kiro-compatibility.sh` | Automated endpoint verification (bash) |
| `verify-kiro-compatibility.ps1` | Automated endpoint verification (PowerShell) |

---

## 3. Hard Rules (Non-Negotiable)

1. **NEVER convert to TypeScript** - This is a Pure Node.js package intentionally. Keep all `.js` files as CommonJS.

2. **NEVER break the `/listAvailableModels` endpoint** - This is **CRITICAL** for Kiro IDE compatibility. Location: `src/handlers/diagnostics_handler.js` lines 90-105.

3. **NEVER change the default port from 8085** - This port is documented throughout. If changed, update ALL documentation files.

4. **NEVER break IEEE 802.3 CRC32 EventStream wire framing** - Located in `src/protocol/smithy_parser.js`. Kiro IDE will crash if framing is corrupted.

5. **NEVER mutate the 7 default provider tiers** without updating documentation: `kilo, cline, openrouter, orcarouter, gemini, custom, canvas`

6. **ALWAYS maintain fallback behavior** - Gateway must work with zero API keys via Kilo provider.

7. **NEVER commit plain API keys** - Use `.env` templates only, never actual credentials.

8. **ALWAYS update VERSION_MANIFEST.json** when making changes to endpoints or features.

---

## 4. Critical Files Map

### Entry Point
- **`kiroproxygateway/KiroProxy-Gateway-v2.8.0/src/index.js`** (150 lines)
  - Main HTTP server
  - Request routing
  - CORS handling
  - Strangler fig modular replacement

### Critical Handlers
- **`src/handlers/diagnostics_handler.js`**
  - ✅ `/listAvailableModels` endpoint (lines 90-105) - **KIRO IDE CRITICAL**
  - `/v1/models` OpenAI-compatible endpoint
  - `/health`, `/status`, `/metrics` endpoints
  - Feature configuration endpoints
  - **RULE**: Any changes here MUST be verified with `verify-kiro-compatibility.sh`

- **`src/handlers/bedrock_handler.js`**
  - `/generateAssistantResponse` streaming endpoint - **KIRO IDE CRITICAL**
  - AWS Bedrock EventStream processing
  - **RULE**: Do not modify EventStream framing logic without deep knowledge

- **`src/handlers/canvas_handler.js`**
  - Canvas bridge endpoints: `/poll`, `/chunk`, `/done`, `/cancel`
  - Gemini queue management

- **`src/handlers/workflow_handler.js`**
  - Workflow endpoints for orchestration

### Configuration
- **`src/config/index.js`**
  - Configuration loader
  - Multi-source config resolution (env, file, defaults)
  - `/tmp` fallback for read-only filesystems

- **`src/config/catalog.js`**
  - Model auto-discovery engine
  - Provider health checks
  - Custom provider model fetching
  - **RULE**: Changes here affect model count - verify with `/listAvailableModels`

### Protocol
- **`src/protocol/smithy_parser.js`**
  - IEEE 802.3 CRC32 EventStream framing
  - AWS Smithy protocol compliance
  - **RULE**: NEVER modify CRC32 calculation or frame boundaries

### Providers
- **`src/providers/*.js`**
  - Individual provider adapters
  - Format translation
  - Error handling

### Resilience
- **`src/resilience/health.js`**
  - Provider health checks
  - ngrok tunnel management
  - Tunnel URL discovery

- **`src/resilience/circuit_breaker.js`**
  - Circuit breaker implementation
  - Failure threshold management

- **`src/resilience/metrics.js`**
  - Prometheus metrics collection
  - Provider statistics

### Translators
- **`src/translators/bedrock_translator.js`**
  - AWS Bedrock ↔ Provider format conversion

---

## 5. Kiro IDE Compatibility Requirements

### Must-Have Endpoints (Break any = break Kiro IDE)

1. **`/listAvailableModels`** (GET)
   - **Location**: `src/handlers/diagnostics_handler.js:90-105`
   - **Format**: AWS Bedrock Smithy
   - **Returns**: `{ models: [...], ... }`
   - **Verification**: `curl http://localhost:8085/listAvailableModels | jq '.models | length'`
   - **Expected**: 100+ models

2. **`/generateAssistantResponse`** (POST)
   - **Location**: `src/handlers/bedrock_handler.js`
   - **Format**: AWS Bedrock EventStream (binary)
   - **Returns**: Streaming EventStream frames with CRC32
   - **Verification**: See `verify-kiro-compatibility.sh` test 11

3. **`/health`** (GET)
   - **Location**: `src/handlers/diagnostics_handler.js:350-380`
   - **Returns**: Health status, model count, tunnel URL
   - **Used by**: Kiro IDE for discovery

### Optional but Recommended

- `/v1/models` - OpenAI-compatible format
- `/status` - Provider metrics
- `/config` - Configuration GUI

### Testing Protocol

After ANY code change:

```bash
# 1. Start server
cd kiroproxygateway/KiroProxy-Gateway-v2.8.0
npm start

# 2. Run verification
cd ../..
bash verify-kiro-compatibility.sh

# 3. Verify all 11 tests pass
# Expected: "✓ ALL TESTS PASSED"

# 4. Manual spot check
curl http://localhost:8085/listAvailableModels | jq '.models | length'
# Expected: 100+ models
```

---

## 6. Maintenance Workflow

### Before Touching Code

1. **Read this file completely**
2. **Identify affected modules** using Critical Files Map (Section 4)
3. **Check dependencies**:
   - Will this affect `/listAvailableModels`?
   - Will this affect EventStream framing?
   - Will this affect provider fallback?
4. **Review related documentation** from Documentation Index (Section 2)

### Making Changes

1. **Edit incrementally** - Test after each logical change
2. **Maintain CommonJS** - No ES6 imports, keep `require()`
3. **Preserve error handling** - Don't remove try-catch blocks
4. **Keep circuit breakers intact** - Resilience is critical
5. **Update comments** - Explain non-obvious logic

### After Making Changes

1. **Run verification**: `bash verify-kiro-compatibility.sh`
2. **Check logs**: Look for errors or warnings
3. **Test manually**: Key endpoints and workflows
4. **Update documentation**:
   - If endpoints changed → Update `VERSION_MANIFEST.json`
   - If configuration changed → Update `KIRO_IDE_DEPLOYMENT.md`
   - If commands changed → Update `QUICK_REFERENCE.md`
   - If behavior changed → Update `README.md`
5. **Rebuild package**: `tar -czf workspace-cloud-final-KIRO_IDE_READY.tar.gz -C workspace-cloud-final .`

---

## 7. Common Modification Scenarios

### Scenario: Adding a New Provider

**Files to modify**:
1. `src/config/index.js` - Add provider config keys
2. `src/providers/[new_provider].js` - Create adapter
3. `src/config/catalog.js` - Add auto-discovery logic
4. `config/kiro_ai_config.template.json` - Add template config

**Documentation to update**:
- `KIRO_IDE_DEPLOYMENT.md` - Provider configuration section
- `QUICK_REFERENCE.md` - Provider priority list
- `VERSION_MANIFEST.json` - Provider list
- `README.md` - Provider tiers

**Testing**:
```bash
# Add provider config
nano kiroproxygateway/KiroProxy-Gateway-v2.8.0/config/kiro_ai_config.json

# Restart
pm2 restart kiroproxy-gateway

# Verify models discovered
curl http://localhost:8085/listAvailableModels | jq '.models | map(select(.provider == "new_provider"))'

# Full verification
bash verify-kiro-compatibility.sh
```

### Scenario: Fixing a Bug in Diagnostics Handler

**Files to check**:
1. `src/handlers/diagnostics_handler.js` - The bug location
2. `src/protocol/smithy_parser.js` - If response format affected
3. `src/config/catalog.js` - If model discovery affected

**Critical verification**:
```bash
# After fix, verify /listAvailableModels still works
curl http://localhost:8085/listAvailableModels | jq '.models[0]'

# Run full verification
bash verify-kiro-compatibility.sh

# Check specific endpoint
curl http://localhost:8085/[affected-endpoint]
```

**Documentation**:
- If bug affected documented behavior → Update relevant docs
- Add entry to `CHANGELOG.md` (if present)

### Scenario: Updating Dependencies

**Command**:
```bash
cd kiroproxygateway/KiroProxy-Gateway-v2.8.0
npm update
npm audit fix
```

**Verification** (CRITICAL):
```bash
# 1. Full restart
pm2 restart kiroproxy-gateway

# 2. Wait for health checks
sleep 10

# 3. Verify compatibility
bash ../../verify-kiro-compatibility.sh

# 4. Check model count didn't decrease
curl http://localhost:8085/listAvailableModels | jq '.models | length'
```

**Risk areas**:
- `@ngrok/ngrok` updates may break tunnel
- HTTP library updates may break streaming
- JSON parsing updates may break config

### Scenario: Changing Port Configuration

**Files to modify**:
1. `.env` or environment - Set `PROXY_PORT=NEW_PORT`

**Documentation to update** (ALL of these):
- `README.md` - All port references
- `KIRO_IDE_DEPLOYMENT.md` - Integration examples
- `QUICK_REFERENCE.md` - Command examples
- `DEPLOYMENT_CHECKLIST.md` - Verification commands
- `ARCHITECTURE_COMPARISON.md` - Port comparison table
- `VERSION_MANIFEST.json` - Deployment port
- `verify-kiro-compatibility.sh` - Default endpoint
- `verify-kiro-compatibility.ps1` - Default endpoint

**Testing**:
```bash
# Update all curl commands in verification
bash verify-kiro-compatibility.sh http://localhost:NEW_PORT
```

---

## 8. Debugging Guide

### Gateway Won't Start

**Check**:
```bash
# Node.js version
node --version  # Must be v18+

# Port availability
netstat -tuln | grep 8085

# Logs
pm2 logs kiroproxy-gateway --lines 50

# File permissions
ls -la kiroproxygateway/KiroProxy-Gateway-v2.8.0/
```

### No Models Discovered

**Debug**:
```bash
# Check provider health
curl http://localhost:8085/status | jq '.health'

# Force refresh
curl -X POST http://localhost:8085/api/health/refresh

# Check config
curl http://localhost:8085/api/config | jq

# Review logs
pm2 logs kiroproxy-gateway | grep -i "model\|discovery\|catalog"
```

### Kiro IDE Can't Connect

**Verify**:
```bash
# 1. Gateway is running
curl http://localhost:8085/health

# 2. /listAvailableModels works
curl http://localhost:8085/listAvailableModels | jq '.models | length'

# 3. CORS headers present
curl -I http://localhost:8085/health | grep -i "access-control"

# 4. Streaming works
curl -X POST http://localhost:8085/generateAssistantResponse \
  -H "Content-Type: application/json" \
  -d '{"conversationState":{},"messages":[{"role":"user","content":[{"text":"test"}]}]}'
```

### Circuit Breakers Stuck Open

**Fix**:
```bash
# Reset all circuit breakers
curl -X POST http://localhost:8085/api/circuit/reset

# Verify state
curl http://localhost:8085/status | jq '.circuitBreakers'

# Check provider health
curl http://localhost:8085/status | jq '.health'
```

---

## 9. Deployment Commands

### Development
```bash
cd kiroproxygateway/KiroProxy-Gateway-v2.8.0
npm install
npm start
```

### Production (PM2)
```bash
cd kiroproxygateway/KiroProxy-Gateway-v2.8.0
npm install
pm2 start src/index.js --name kiroproxy-gateway
pm2 save
pm2 startup
```

### Automated Cloud Deployment
```bash
bash kiroproxygateway/deploy-cloud.sh
```

### Docker
```bash
cd kiroproxygateway/KiroProxy-Gateway-v2.8.0
docker build -t kiroproxy:2.8.0 .
docker run -d -p 8085:8085 --name kiroproxy kiroproxy:2.8.0
```

---

## 10. Package Structure Reference

```
workspace-cloud-final/
├── AGENTS.md                          ← THIS FILE
├── README.md                          ← Start here
├── KIRO_IDE_DEPLOYMENT.md             ← Deployment guide
├── QUICK_REFERENCE.md                 ← Command reference
├── ARCHITECTURE_COMPARISON.md         ← Architecture analysis
├── DEPLOYMENT_CHECKLIST.md            ← Deployment steps
├── VERSION_MANIFEST.json              ← Technical specs
├── verify-kiro-compatibility.sh       ← Bash verification
├── verify-kiro-compatibility.ps1      ← PowerShell verification
└── kiroproxygateway/
    ├── deploy-cloud.sh                ← Deployment automation
    └── KiroProxy-Gateway-v2.8.0/
        ├── src/
        │   ├── index.js               ← Main entry (150 lines)
        │   ├── handlers/
        │   │   ├── diagnostics_handler.js  ← /listAvailableModels ✅
        │   │   ├── bedrock_handler.js      ← Streaming ✅
        │   │   ├── canvas_handler.js
        │   │   └── workflow_handler.js
        │   ├── config/
        │   │   ├── index.js           ← Config loader
        │   │   └── catalog.js         ← Model discovery
        │   ├── protocol/
        │   │   └── smithy_parser.js   ← EventStream framing
        │   ├── providers/             ← Provider adapters
        │   ├── resilience/
        │   │   ├── health.js          ← Health checks + ngrok
        │   │   ├── circuit_breaker.js ← Circuit breakers
        │   │   └── metrics.js         ← Telemetry
        │   └── translators/
        │       └── bedrock_translator.js
        ├── config/
        │   ├── kiro_ai_config.json    ← Runtime config
        │   └── kiro_ai_config.template.json
        ├── public/
        │   └── config.html            ← Web GUI
        ├── package.json
        ├── .env.template
        └── README.md
```

---

## 11. AI Assistant Best Practices

### When Asked to Modify Code

1. ✅ **DO**: Read this AGENTS.md file completely first
2. ✅ **DO**: Identify affected files from Critical Files Map
3. ✅ **DO**: Check if changes affect Kiro IDE compatibility
4. ✅ **DO**: Maintain CommonJS syntax (no ES6 imports)
5. ✅ **DO**: Run verification after changes
6. ✅ **DO**: Update all affected documentation
7. ❌ **DON'T**: Convert to TypeScript
8. ❌ **DON'T**: Break `/listAvailableModels` endpoint
9. ❌ **DON'T**: Modify EventStream framing without expertise
10. ❌ **DON'T**: Remove error handling or circuit breakers

### When Asked About Architecture

- Reference `ARCHITECTURE_COMPARISON.md` for comparisons
- Reference `VERSION_MANIFEST.json` for specs
- Explain that this is the **lightweight Pure Node.js version**
- Emphasize **Kiro IDE compatibility** is non-negotiable

### When Asked About Deployment

- Direct to `KIRO_IDE_DEPLOYMENT.md` as primary source
- Provide `QUICK_REFERENCE.md` commands as shortcuts
- Emphasize `DEPLOYMENT_CHECKLIST.md` for production
- Always recommend running `verify-kiro-compatibility.sh`

### When Asked About Troubleshooting

- Check Section 8 (Debugging Guide) of this file
- Reference `KIRO_IDE_DEPLOYMENT.md` troubleshooting section
- Recommend checking logs: `pm2 logs kiroproxy-gateway`
- Suggest health endpoint: `curl http://localhost:8085/health`

---

## 12. Version and Compatibility

| Attribute | Value |
|-----------|-------|
| **Version** | 2.8.0 |
| **Runtime** | Pure Node.js (CommonJS) |
| **Node.js Requirement** | v18+ |
| **Port** | 8085 (default) |
| **Kiro IDE Compatible** | ✅ YES |
| **Cloud Deployment** | kproxy.space-z.ai |
| **Architecture** | Modular, strangler fig pattern |
| **Cold Start** | <2 seconds |
| **Memory** | ~100-150 MB baseline |
| **Bundle Size** | ~55 MB (with node_modules) |

---

## 13. Support and Resources

**For Code Changes**:
1. Read this AGENTS.md file
2. Check Critical Files Map (Section 4)
3. Review Hard Rules (Section 3)
4. Follow Maintenance Workflow (Section 6)

**For Deployment**:
1. Read `KIRO_IDE_DEPLOYMENT.md`
2. Use `DEPLOYMENT_CHECKLIST.md`
3. Run `verify-kiro-compatibility.sh`

**For Quick Commands**:
1. Check `QUICK_REFERENCE.md`
2. Reference Section 9 of this file

**For Architecture Questions**:
1. Read `ARCHITECTURE_COMPARISON.md`
2. Check `VERSION_MANIFEST.json`

---

## 14. Final Reminders

1. **Kiro IDE compatibility is non-negotiable** - All changes must preserve it
2. **Pure Node.js is intentional** - Don't convert to TypeScript
3. **Documentation is part of code** - Update docs with every change
4. **Verification is mandatory** - Run `verify-kiro-compatibility.sh` after changes
5. **Zero-cost must work** - Gateway must function without API keys
6. **Port 8085 is standard** - Don't change without updating ALL docs

---

**Last Updated**: 2026-10-11  
**Maintained By**: AI Agents  
**Version**: 1.0  
**Gateway Version**: 2.8.0
