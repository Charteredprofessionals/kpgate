import type { NextConfig } from "next";

const KIROPROXY_TARGET = process.env.KIROPROXY_TARGET || "http://127.0.0.1:3001";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Force Next.js's standalone file tracer to bundle the entire KiroProxy
  // source tree alongside the Next.js server. Without this, only the entry
  // file (src/index.js) gets copied and runtime `require('./config/index')`
  // calls inside KiroProxy fail with MODULE_NOT_FOUND.
  outputFileTracingIncludes: {
    "/": ["./kiroproxygateway/**/*", "./public/config.html"],
  },
  // Forward all KiroProxy-owned paths to the gateway running on :3001.
  // Next.js itself only handles `/` (redirect) and `/api/hello` (default route).
  async rewrites() {
    return [
      // KiroProxy HTML GUI + diagnostics
      { source: "/config", destination: `${KIROPROXY_TARGET}/config` },
      { source: "/config.html", destination: `${KIROPROXY_TARGET}/config` },
      { source: "/health", destination: `${KIROPROXY_TARGET}/health` },
      { source: "/status", destination: `${KIROPROXY_TARGET}/status` },
      { source: "/metrics", destination: `${KIROPROXY_TARGET}/metrics` },
      // Canvas Bridge GUI + dashboard (HTML pages)
      { source: "/canvas", destination: `${KIROPROXY_TARGET}/canvas` },
      { source: "/canvas-bridge", destination: `${KIROPROXY_TARGET}/canvas-bridge` },
      { source: "/canvas-dashboard", destination: `${KIROPROXY_TARGET}/canvas-dashboard` },
      { source: "/dashboard", destination: `${KIROPROXY_TARGET}/dashboard` },
      { source: "/bridge", destination: `${KIROPROXY_TARGET}/bridge` },
      { source: "/setup", destination: `${KIROPROXY_TARGET}/setup` },
      // Gemini browser user-script (served as text/javascript)
      { source: "/gemini_bridge.user.js", destination: `${KIROPROXY_TARGET}/gemini_bridge.user.js` },
      { source: "/kiro_gemini_bridge.user.js", destination: `${KIROPROXY_TARGET}/kiro_gemini_bridge.user.js` },
      // OpenAI-compatible catalog + chat
      { source: "/v1/:path*", destination: `${KIROPROXY_TARGET}/v1/:path*` },
      { source: "/api/health/:path*", destination: `${KIROPROXY_TARGET}/api/health/:path*` },
      { source: "/api/circuit/:path*", destination: `${KIROPROXY_TARGET}/api/circuit/:path*` },
      { source: "/api/config", destination: `${KIROPROXY_TARGET}/api/config` },
      // AWS Bedrock / Kiro IDE endpoints (many catch-all paths)
      { source: "/runtime/:path*", destination: `${KIROPROXY_TARGET}/runtime/:path*` },
      { source: "/poll/:path*", destination: `${KIROPROXY_TARGET}/poll/:path*` },
      { source: "/chunk/:path*", destination: `${KIROPROXY_TARGET}/chunk/:path*` },
      { source: "/done/:path*", destination: `${KIROPROXY_TARGET}/done/:path*` },
      { source: "/cancel/:path*", destination: `${KIROPROXY_TARGET}/cancel/:path*` },
    ];
  },
};

export default nextConfig;

