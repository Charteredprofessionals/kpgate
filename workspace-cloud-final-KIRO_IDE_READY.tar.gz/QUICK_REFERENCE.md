# KiroProxy Gateway v2.8.0 - Quick Reference Card

## 🚀 One-Line Deployment

```bash
cd kiroproxygateway/KiroProxy-Gateway-v2.8.0 && npm install && pm2 start src/index.js --name kiroproxy
```

## 🔗 Critical Endpoints

| Endpoint | Purpose | Kiro IDE Required |
|----------|---------|-------------------|
| `/listAvailableModels` | AWS Bedrock model discovery | ✅ **CRITICAL** |
| `/v1/models` | OpenAI-compatible model list | ✅ Optional |
| `/generateAssistantResponse` | AWS Bedrock streaming chat | ✅ **CRITICAL** |
| `/health` | Health check + tunnel URL | ✅ Recommended |
| `/status` | Provider status + metrics | ❌ Diagnostics |
| `/config` | Configuration web GUI | ❌ Management |

## ⚡ Quick Commands

```bash
# Start server
npm start

# Start with PM2 (production)
pm2 start src/index.js --name kiroproxy

# Check health
curl http://localhost:8085/health | jq

# Count models
curl http://localhost:8085/listAvailableModels | jq '.models | length'

# Get tunnel URL
curl http://localhost:8085/health | jq -r .tunnel

# View status
curl http://localhost:8085/status | jq

# Refresh providers
curl -X POST http://localhost:8085/api/health/refresh

# Reset circuit breakers
curl -X POST http://localhost:8085/api/circuit/reset

# View logs
pm2 logs kiroproxy

# Restart
pm2 restart kiroproxy

# Stop
pm2 stop kiroproxy
```

## 🔧 Environment Variables

```env
# Server Configuration
PROXY_PORT=8085
BIND_HOST=0.0.0.0

# ngrok (Public Access)
NGROK_AUTHTOKEN=your_token_here

# Provider API Keys (Optional)
CLINE_API_KEY=
OPENROUTER_API_KEY=
GEMINI_API_KEY=
ORCAROUTER_API_KEY=
GROQ_API_KEY=
```

## 📊 Provider Priority (Default)

```
1. kilo       (Zero-cost cloud inference)
2. cline      (Requires API key)
3. openrouter (Requires API key)
4. orcarouter (Requires API key)
5. gemini     (Requires API key)
6. custom     (User-defined providers)
7. canvas     (Browser-based fallback)
```

## 🩺 Health Check Response

```json
{
  "status": "ok",
  "version": "2.8.0",
  "modelCount": 137,
  "providersHealthy": "5/7",
  "tunnel": "https://xyz.ngrok-free.app",
  "endpoints": { ... }
}
```

## 🎯 Kiro IDE Integration

### Configuration

```json
{
  "bedrock": {
    "endpoint": "http://localhost:8085"
  }
}
```

### With ngrok Tunnel

```json
{
  "bedrock": {
    "endpoint": "https://your-tunnel-id.ngrok-free.app"
  }
}
```

### Cloud Deployment

```json
{
  "bedrock": {
    "endpoint": "https://kproxy.space-z.ai"
  }
}
```

## 🧪 Verification

### Basic Test

```bash
# Run verification script
bash verify-kiro-compatibility.sh

# Or with PowerShell
.\verify-kiro-compatibility.ps1
```

### Manual Verification

```bash
# 1. Health check
curl http://localhost:8085/health

# 2. Model discovery (AWS format)
curl http://localhost:8085/listAvailableModels | jq '.models[0]'

# 3. Model discovery (OpenAI format)
curl http://localhost:8085/v1/models | jq '.data[0]'

# 4. Test streaming
curl -X POST http://localhost:8085/generateAssistantResponse \
  -H "Content-Type: application/json" \
  -d '{"conversationState":{},"messages":[{"role":"user","content":[{"text":"ping"}]}]}'
```

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| Server won't start | Check `logs/error.log`, verify Node.js v18+ |
| No models discovered | Run `curl -X POST http://localhost:8085/api/health/refresh` |
| Tunnel not working | Set `NGROK_AUTHTOKEN` in `.env`, restart server |
| Circuit breaker stuck | Run `curl -X POST http://localhost:8085/api/circuit/reset` |
| 429 rate limits | Wait for circuit breaker cooldown (30s-5m) |
| CORS errors | Check origin headers, verify ngrok headers |

## 📁 File Locations

| Path | Purpose |
|------|---------|
| `src/index.js` | Main HTTP server entry point |
| `src/handlers/diagnostics_handler.js` | `/listAvailableModels` implementation |
| `src/config/catalog.js` | Model auto-discovery engine |
| `config/kiro_ai_config.json` | Runtime configuration (API keys) |
| `logs/` | Server logs (PM2 managed) |
| `.env` | Environment variables |

## 🔒 Security Notes

- **Never commit** `.env` or `kiro_ai_config.json` with real API keys
- Use `.gitignore` to exclude sensitive files
- Rotate API keys regularly
- Use ngrok authentication for public tunnels
- Monitor `/metrics` for abuse patterns

## 🌐 Network Ports

| Port | Service | Notes |
|------|---------|-------|
| 8085 | KiroProxy Gateway | Default (configurable via `PROXY_PORT`) |
| 8084 | tmp_cloud_audit | Alternative TypeScript version |
| 3000 | Next.js frontend | For full-stack z.ai deployment |

## 📈 Monitoring

```bash
# Prometheus metrics
curl http://localhost:8085/metrics

# Detailed status
curl http://localhost:8085/status | jq

# PM2 monitoring
pm2 monit

# Logs (real-time)
pm2 logs kiroproxy --lines 100 --raw
```

## 🔄 Updates

```bash
# Pull latest code
git pull

# Reinstall dependencies
npm install

# Restart
pm2 restart kiroproxy --update-env
```

## 🆘 Support

1. Check `/status` endpoint for provider health
2. Review `logs/error.log` for exceptions
3. Run health refresh: `curl -X POST http://localhost:8085/api/health/refresh`
4. Verify configuration: `curl http://localhost:8085/api/config | jq`
5. Test specific provider via `/status` circuit breaker states

---

**Version**: 2.8.0  
**Deployment**: kproxy.space-z.ai  
**Documentation**: See `KIRO_IDE_DEPLOYMENT.md` for full guide
