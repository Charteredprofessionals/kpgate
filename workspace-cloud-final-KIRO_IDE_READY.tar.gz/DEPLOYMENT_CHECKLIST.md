# KiroProxy Gateway v2.8.0 - Deployment Checklist

## Pre-Deployment Verification

### System Requirements
- [ ] Node.js v18 or higher installed (`node --version`)
- [ ] npm or yarn package manager available
- [ ] PM2 installed globally (`npm install -g pm2`)
- [ ] curl or equivalent HTTP client for testing
- [ ] jq for JSON parsing (optional but recommended)

### Network Requirements
- [ ] Port 8085 available (or custom port configured)
- [ ] Outbound HTTPS access to provider APIs
- [ ] (Optional) ngrok authtoken for public access

### File System
- [ ] Read/write access to deployment directory
- [ ] Sufficient disk space (~100 MB minimum)
- [ ] Logs directory writable

## Installation Steps

### 1. Extract Package
- [ ] Extract `workspace-cloud-final-KIRO_IDE_READY.tar.gz`
- [ ] Navigate to `kiroproxygateway/KiroProxy-Gateway-v2.8.0/`
- [ ] Verify all source files present

### 2. Install Dependencies
- [ ] Run `npm install` (or `npm ci` for production)
- [ ] Verify installation completed without errors
- [ ] Check critical modules present:
  - [ ] `@ngrok/ngrok`
  - [ ] All provider adapters in `src/providers/`

### 3. Configure Environment
- [ ] Copy `.env.template` to `.env`
- [ ] Set `PROXY_PORT` (default: 8085)
- [ ] Set `BIND_HOST` (default: 0.0.0.0)
- [ ] (Optional) Set `NGROK_AUTHTOKEN` for public access
- [ ] (Optional) Add provider API keys:
  - [ ] `CLINE_API_KEY`
  - [ ] `OPENROUTER_API_KEY`
  - [ ] `GEMINI_API_KEY`
  - [ ] `ORCAROUTER_API_KEY`

### 4. Configure Runtime Settings
- [ ] Review `config/kiro_ai_config.json`
- [ ] Verify provider priority order
- [ ] Check custom provider configurations
- [ ] Ensure no sensitive keys committed to version control

## Deployment

### 5. Start Server

**Option A: Direct Start (Development)**
- [ ] Run `npm start` or `node src/index.js`
- [ ] Verify startup messages appear
- [ ] Check for any error messages

**Option B: PM2 (Production)**
- [ ] Run `pm2 start src/index.js --name kiroproxy-gateway`
- [ ] Verify process started: `pm2 status`
- [ ] Save PM2 configuration: `pm2 save`
- [ ] Setup PM2 startup: `pm2 startup`

**Option C: Automated Script**
- [ ] Run `bash ../deploy-cloud.sh`
- [ ] Review deployment output
- [ ] Verify health check passed

### 6. Initial Health Check
- [ ] Server responds on configured port
- [ ] `/health` endpoint returns 200 OK
- [ ] Model count > 0 in health response
- [ ] Tunnel URL present (if ngrok configured)

```bash
curl http://localhost:8085/health | jq
```

Expected fields:
- [ ] `status: "ok"`
- [ ] `version: "2.8.0"`
- [ ] `modelCount` > 0
- [ ] `providersHealthy` shows count
- [ ] `tunnel` URL (if ngrok enabled)

## Kiro IDE Compatibility Verification

### 7. Run Verification Script

**Bash**:
```bash
bash verify-kiro-compatibility.sh http://localhost:8085
```

**PowerShell**:
```powershell
.\verify-kiro-compatibility.ps1 -Endpoint http://localhost:8085
```

### 8. Manual Endpoint Verification

- [ ] **Health Check**
  ```bash
  curl http://localhost:8085/health
  ```
  Expected: HTTP 200, JSON response

- [ ] **ListAvailableModels (AWS) - CRITICAL**
  ```bash
  curl http://localhost:8085/listAvailableModels | jq '.models | length'
  ```
  Expected: HTTP 200, `models` array with 100+ entries

- [ ] **OpenAI Models**
  ```bash
  curl http://localhost:8085/v1/models | jq '.data | length'
  ```
  Expected: HTTP 200, `data` array with model objects

- [ ] **Status Endpoint**
  ```bash
  curl http://localhost:8085/status | jq
  ```
  Expected: HTTP 200, provider metrics

- [ ] **Config API**
  ```bash
  curl http://localhost:8085/api/config | jq
  ```
  Expected: HTTP 200, configuration object

- [ ] **CORS Preflight**
  ```bash
  curl -X OPTIONS http://localhost:8085/health \
    -H "Origin: https://gemini.google.com" \
    -H "Access-Control-Request-Method: POST"
  ```
  Expected: HTTP 200, CORS headers present

- [ ] **Streaming Chat (Basic)**
  ```bash
  curl -X POST http://localhost:8085/generateAssistantResponse \
    -H "Content-Type: application/json" \
    -H "x-amzn-requestid: test-001" \
    -d '{"conversationState":{},"messages":[{"role":"user","content":[{"text":"ping"}]}]}'
  ```
  Expected: HTTP 200, streaming response

### 9. Provider Health Check

- [ ] Run health refresh:
  ```bash
  curl -X POST http://localhost:8085/api/health/refresh
  ```

- [ ] Check provider status:
  ```bash
  curl http://localhost:8085/status | jq '.health'
  ```

- [ ] Verify at least one provider healthy

- [ ] Check circuit breaker states:
  ```bash
  curl http://localhost:8085/status | jq '.circuitBreakers'
  ```

### 10. Model Discovery Verification

- [ ] Automatic model population ran
- [ ] Model count matches expected (~137+)
- [ ] Models include:
  - [ ] Kilo models (free)
  - [ ] OpenRouter models
  - [ ] Gemini models
  - [ ] Custom provider models (if configured)

```bash
# Check model count by provider
curl http://localhost:8085/listAvailableModels | \
  jq '.models | group_by(.provider) | map({provider: .[0].provider, count: length})'
```

## Kiro IDE Integration

### 11. Configure Kiro IDE

- [ ] Locate Kiro IDE configuration file
- [ ] Add bedrock endpoint configuration:

**Local deployment**:
```json
{
  "bedrock": {
    "endpoint": "http://localhost:8085"
  }
}
```

**ngrok tunnel**:
```json
{
  "bedrock": {
    "endpoint": "https://YOUR-TUNNEL-ID.ngrok-free.app"
  }
}
```

**Cloud deployment**:
```json
{
  "bedrock": {
    "endpoint": "https://kproxy.space-z.ai"
  }
}
```

### 12. Test Kiro IDE Integration

- [ ] Launch Kiro IDE
- [ ] Start new conversation
- [ ] Verify models appear in model selector
- [ ] Send test message
- [ ] Verify streaming response received
- [ ] Check gateway logs for request

```bash
# Monitor requests in real-time
pm2 logs kiroproxy-gateway --lines 50
```

## Post-Deployment

### 13. Monitoring Setup

- [ ] Configure log rotation
- [ ] Set up Prometheus scraping (if using):
  ```
  - job_name: 'kiroproxy'
    static_configs:
      - targets: ['localhost:8085']
  ```

- [ ] Setup alerting for:
  - [ ] Server downtime
  - [ ] High error rates
  - [ ] Circuit breaker open states
  - [ ] Low model count

### 14. Performance Baseline

- [ ] Record initial metrics:
  ```bash
  curl http://localhost:8085/metrics
  ```

- [ ] Document baseline values:
  - [ ] Response time (avg)
  - [ ] Success rate per provider
  - [ ] Memory usage
  - [ ] Model discovery time

### 15. Documentation

- [ ] Document deployment specifics:
  - [ ] Server hostname/IP
  - [ ] Port configuration
  - [ ] ngrok tunnel URL (if applicable)
  - [ ] Provider API keys used (reference only, not values)
  - [ ] Custom configurations applied

- [ ] Create runbook for:
  - [ ] Restart procedure
  - [ ] Health check commands
  - [ ] Common troubleshooting steps
  - [ ] Emergency contacts

### 16. Backup and Recovery

- [ ] Backup configuration files:
  - [ ] `.env`
  - [ ] `config/kiro_ai_config.json`
  - [ ] PM2 process list: `pm2 save`

- [ ] Document recovery procedure

- [ ] Test restore from backup (if applicable)

## Security Hardening

### 17. Security Review

- [ ] Verify no API keys in logs
- [ ] Check `.gitignore` includes:
  - [ ] `.env`
  - [ ] `config/kiro_ai_config.json`
  - [ ] `logs/*.log`

- [ ] Review CORS configuration
- [ ] Verify rate limiting (if enabled)
- [ ] Check firewall rules (if applicable)

### 18. Access Control

- [ ] Limit server access to necessary IPs
- [ ] Use ngrok authentication for public tunnels
- [ ] Rotate API keys on schedule
- [ ] Document who has access to what

## Final Verification

### 19. Complete Verification Run

- [ ] All verification tests pass:
  ```bash
  bash verify-kiro-compatibility.sh http://localhost:8085
  ```

- [ ] Expected output: `✓ ALL TESTS PASSED`

### 20. Production Readiness

- [ ] Server stable for 5+ minutes
- [ ] No errors in logs
- [ ] All circuit breakers CLOSED
- [ ] Model count stable
- [ ] Kiro IDE successfully connected
- [ ] At least one successful chat completion

## Rollback Plan

### If Deployment Fails

- [ ] Stop new server: `pm2 stop kiroproxy-gateway`
- [ ] Review error logs
- [ ] Restore previous configuration (if upgrading)
- [ ] Document failure reason
- [ ] Plan remediation

## Sign-Off

### Deployment Team
- [ ] Deployed by: ________________
- [ ] Date: ________________
- [ ] Version: 2.8.0
- [ ] Environment: ________________

### Verification
- [ ] All tests passed
- [ ] Kiro IDE connected
- [ ] Models discovered: ______ models
- [ ] Tunnel URL (if applicable): ________________

### Approval
- [ ] Technical lead sign-off
- [ ] Operations sign-off
- [ ] Security review complete

---

## Quick Reference

**Critical Commands**:
```bash
# Start
pm2 start src/index.js --name kiroproxy-gateway

# Status
pm2 status

# Logs
pm2 logs kiroproxy-gateway

# Restart
pm2 restart kiroproxy-gateway

# Health
curl http://localhost:8085/health | jq

# Models
curl http://localhost:8085/listAvailableModels | jq '.models | length'

# Verify
bash verify-kiro-compatibility.sh
```

**Troubleshooting**:
```bash
# Refresh providers
curl -X POST http://localhost:8085/api/health/refresh

# Reset circuit breakers
curl -X POST http://localhost:8085/api/circuit/reset

# View status
curl http://localhost:8085/status | jq
```

---

**Deployment Checklist Version**: 1.0  
**Gateway Version**: 2.8.0  
**Last Updated**: 2026-10-11
