#!/bin/bash
# KiroProxy Gateway — dev script (started by the platform's start.sh)
# Boots the gateway on port 3000 (PROXY_PORT) bound to 0.0.0.0 so the Caddy gateway can reach it.
set -e

cd /home/z/my-project

echo "[dev] Starting KiroProxy Gateway on 0.0.0.0:3000..."
export PORT=3000
export BIND_HOST=0.0.0.0
exec node kiroproxygateway/KiroProxy-Gateway-v2.8.0/src/index.js
