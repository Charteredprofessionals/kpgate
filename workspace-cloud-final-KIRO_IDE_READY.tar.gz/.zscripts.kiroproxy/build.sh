#!/bin/bash
# KiroProxy Gateway — build script
# Produces the build artifact expected by the platform: /tmp/build_fullstack_${BUILD_ID}.tar.gz
#
# The platform extracts this tarball and then looks for .zscripts/dev.sh inside it
# to start the dev server. So the tarball MUST contain:
#   - package.json (so `bun run dev` works)
#   - .zscripts/dev.sh (so the platform can invoke it)
#   - the actual app source (kiroproxygateway/...)
#   - node_modules/ (so deps are available without re-install)
set -e

cd /home/z/my-project

echo "[build] BUILD_ID=${BUILD_ID:-<unset>}"
if [ -z "$BUILD_ID" ]; then
  echo "[build] ERROR: BUILD_ID is not set"
  exit 1
fi

# Make sure dependencies are installed in the project root
if [ ! -d "node_modules" ]; then
  echo "[build] Installing dependencies..."
  bun install
fi

# Verify the entry point exists
if [ ! -f "kiroproxygateway/KiroProxy-Gateway-v2.8.0/src/index.js" ]; then
  echo "[build] ERROR: src/index.js not found"
  exit 1
fi

# Produce the build artifact tarball.
OUTPUT="/tmp/build_fullstack_${BUILD_ID}.tar.gz"
echo "[build] Creating build artifact at $OUTPUT..."

# Stage a clean deployment directory so the tarball has a sensible top-level layout.
STAGE_DIR="/tmp/build_stage_${BUILD_ID}"
rm -rf "$STAGE_DIR"
mkdir -p "$STAGE_DIR"

# Copy project files. INCLUDE .zscripts/ so the platform can find dev.sh after extraction.
# EXCLUDE only truly disposable stuff (git history, build outputs, caches, logs).
rsync -a \
  --exclude='.git' \
  --exclude='download' \
  --exclude='upload' \
  --exclude='skills' \
  --exclude='dev.log' \
  --exclude='db' \
  --exclude='*.log' \
  ./ "$STAGE_DIR/"

# Create the tarball (top-level = contents of stage dir, no leading directory)
tar -czf "$OUTPUT" -C "$STAGE_DIR" .

# Cleanup stage
rm -rf "$STAGE_DIR"

echo "[build] Artifact created: $OUTPUT ($(du -h "$OUTPUT" | cut -f1))"
ls -la "$OUTPUT"

# Verify the tarball contains the key files
echo "[build] Verifying tarball contents..."
tar -tzf "$OUTPUT" | grep -E '^\./(package\.json|\.zscripts/(build|dev)\.sh|kiroproxygateway/.*/src/index\.js|node_modules/(@ngrok|dotenv)/)' | head -10
