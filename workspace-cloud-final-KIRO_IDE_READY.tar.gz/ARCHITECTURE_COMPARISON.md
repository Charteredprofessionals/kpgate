# KiroProxy Gateway - Architecture Comparison

## Overview

This document compares the **Modular v2.8.0** (deployed at kproxy.space-z.ai) with the **tmp_cloud_audit** TypeScript version.

## Executive Summary

Both versions are **FULLY COMPATIBLE** with Kiro IDE. The key difference is deployment complexity vs feature richness.

| Aspect | Modular v2.8.0 | tmp_cloud_audit |
|--------|----------------|-----------------|
| **Kiro IDE Compatible** | ✅ YES | ✅ YES |
| **Runtime** | Pure Node.js | TypeScript + tsx |
| **Complexity** | Lightweight | Full-featured |
| **Recommended For** | Cloud deployment | Local development |

## Detailed Comparison

### 1. Runtime Architecture

#### Modular v2.8.0 (kproxy.space-z.ai)
- **Language**: Pure JavaScript (CommonJS)
- **Execution**: Direct Node.js execution
- **Compilation**: None required
- **Startup Time**: <2 seconds
- **Memory**: ~100-150 MB baseline
- **Cold Start**: Excellent for serverless

#### tmp_cloud_audit
- **Language**: TypeScript
- **Execution**: Runtime compilation via `tsx`
- **Compilation**: On-the-fly transpilation
- **Startup Time**: ~5-8 seconds
- **Memory**: ~200-300 MB baseline
- **Cold Start**: Moderate

### 2. Port Configuration

| Version | Default Port | Configurable Via |
|---------|--------------|-----------------|
| Modular v2.8.0 | 8085 | `PROXY_PORT` env var |
| tmp_cloud_audit | 8084 | `PORT` env var |

### 3. Model Discovery Endpoints

Both versions implement the **critical** `/listAvailableModels` endpoint.

#### Modular v2.8.0 Implementation

**File**: `src/handlers/diagnostics_handler.js`

```javascript
// Line 90-105
if (urlPath === '/listavailablemodels' || 
    urlPath.includes('listavailablemodels') || 
    amzTarget.includes('listavailablemodels')) {
  console.log(`[KiroProxy] ⭐ ListAvailableModels requested...`);
  autoPopulateFreeModels();
  
  const modelsWithPricing = {
    ...MODELS,
    models: MODELS.models.map(m => ({
      ...m,
      pricing: {
        prompt: String(m.rateMultiplier || 0),
        completion: String(m.rateMultiplier || 0),
        unit: m.rateUnit || 'credit'
      }
    }))
  };
  
  sendAwsResponse(res, 200, modelsWithPricing, reqId);
  return true;
}
```

**Routing**: Catch-all in handler (case-insensitive match)

#### tmp_cloud_audit Implementation

**File**: `src/backend/handlers/diagnostics_handler.ts`

```typescript
// Similar implementation in TypeScript
if (urlPath.includes('listavailablemodels') || 
    amzTarget.includes('listavailablemodels')) {
  // ... TypeScript typed implementation
}
```

**Routing**: Also catch-all in handler

**Verdict**: ✅ **Functionally Identical** - Both support Kiro IDE model discovery

### 4. Bundle Size

| Version | Disk Space | node_modules | Total |
|---------|------------|--------------|-------|
| Modular v2.8.0 | ~5 MB | ~50 MB | ~55 MB |
| tmp_cloud_audit | ~15 MB | ~200 MB | ~215 MB |

**Why the difference?**
- tmp_cloud_audit includes full React 19 frontend + build tooling
- Modular v2.8.0 has minimal static HTML config page

### 5. Frontend Features

#### Modular v2.8.0
- **Config GUI**: Static HTML (`public/config.html`)
- **Functionality**: Basic provider management
- **Bundle**: Single HTML file with inline JS
- **Size**: <100 KB

#### tmp_cloud_audit
- **Frontend**: Full React 19 SPA
- **Build Tool**: Vite 6
- **Features**: Rich UI, real-time updates, model browser
- **Bundle**: ~2 MB minified

### 6. Deployment Complexity

#### Modular v2.8.0

**Steps**:
1. `npm install`
2. Configure `.env`
3. `pm2 start src/index.js`

**Files Needed**: 
- Source code
- `package.json`
- `.env` (optional)

**Deployment Time**: ~30 seconds

#### tmp_cloud_audit

**Steps**:
1. `npm install`
2. `npm run build` (frontend)
3. Configure `.env`
4. `tsx server.ts` or `npm start`

**Files Needed**:
- Source code
- `package.json`
- `tsconfig.json`
- Vite config
- `.env`

**Deployment Time**: ~3-5 minutes (build + install)

### 7. Development Experience

#### Modular v2.8.0

**Pros**:
- Instant feedback (no compilation)
- Minimal dependencies
- Easy to debug (plain JavaScript)
- Works on any Node.js environment

**Cons**:
- No type checking
- Manual type documentation
- Risk of runtime type errors

#### tmp_cloud_audit

**Pros**:
- Full TypeScript type safety
- IDE autocomplete
- Catch errors at compile time
- Modern development workflow

**Cons**:
- Slower startup during development
- Build step adds complexity
- More dependencies to manage

### 8. Feature Parity Matrix

| Feature | Modular v2.8.0 | tmp_cloud_audit |
|---------|----------------|-----------------|
| **Core Endpoints** |
| `/listAvailableModels` | ✅ | ✅ |
| `/generateAssistantResponse` | ✅ | ✅ |
| `/v1/models` | ✅ | ✅ |
| `/health` | ✅ | ✅ |
| `/status` | ✅ | ✅ |
| **Provider Support** |
| Kilo (zero-cost) | ✅ | ✅ |
| Cline | ✅ | ✅ |
| OpenRouter | ✅ | ✅ |
| OrcaRouter | ✅ | ✅ |
| Gemini | ✅ | ✅ |
| Custom Providers | ✅ | ✅ |
| Canvas Bridge | ✅ | ✅ |
| **Resilience** |
| Circuit Breakers | ✅ | ✅ |
| Smart Fallback | ✅ | ✅ |
| Health Checks | ✅ | ✅ |
| Metrics | ✅ | ✅ |
| **Management** |
| Config API | ✅ | ✅ |
| Config GUI | ✅ Static HTML | ✅ React SPA |
| ngrok Integration | ✅ | ✅ |
| **Advanced Features** |
| Server-Sent Events | ❌ | ✅ |
| WebSocket Support | ❌ | ✅ |
| Real-time Dashboard | ❌ | ✅ |
| Model Auto-Discovery | ✅ | ✅ |
| Usage Analytics | ✅ Basic | ✅ Advanced |

### 9. Production Considerations

#### Modular v2.8.0

**Best For**:
- ✅ Cloud Run / Lambda deployments
- ✅ Docker containers
- ✅ Resource-constrained environments
- ✅ Rapid deployment pipelines
- ✅ Edge computing

**Concerns**:
- ⚠️ No compile-time type checking
- ⚠️ Manual type validation needed
- ⚠️ Minimal frontend features

#### tmp_cloud_audit

**Best For**:
- ✅ Developer workstations
- ✅ Feature-rich deployments
- ✅ Teams preferring TypeScript
- ✅ Environments with build infrastructure
- ✅ Full-featured admin interfaces

**Concerns**:
- ⚠️ Larger resource footprint
- ⚠️ Longer cold start times
- ⚠️ More complex deployment

### 10. Code Organization

#### Modular v2.8.0

```
src/
├── index.js                    # 150 lines - main server
├── config/
│   ├── index.js               # Config management
│   └── catalog.js             # Model discovery
├── handlers/
│   ├── bedrock_handler.js     # AWS streaming
│   ├── diagnostics_handler.js # /listAvailableModels ✅
│   ├── canvas_handler.js
│   └── workflow_handler.js
├── protocol/
│   └── smithy_parser.js       # EventStream framing
├── providers/
│   └── [provider adapters]
├── resilience/
│   ├── health.js              # Health + ngrok
│   ├── circuit_breaker.js
│   └── metrics.js
└── translators/
    └── bedrock_translator.js
```

#### tmp_cloud_audit

```
src/
├── backend/
│   ├── handlers/
│   │   ├── diagnostics_handler.ts  # /listAvailableModels ✅
│   │   └── [other handlers]
│   ├── config/
│   └── [similar structure to modular]
├── frontend/
│   ├── components/
│   ├── pages/
│   └── [React 19 SPA]
└── instrumentation.ts         # OpenTelemetry
server.ts                      # Express + Vite SSR
```

### 11. Maintenance Burden

| Task | Modular v2.8.0 | tmp_cloud_audit |
|------|----------------|-----------------|
| Update dependencies | Low | Medium |
| Security patches | Fast | Moderate |
| Feature additions | Direct edit | Edit + rebuild |
| Bug fixes | Immediate | Compile + test |
| Version upgrades | npm update | npm update + rebuild |

### 12. Testing Strategy

#### Modular v2.8.0

**Verification**:
```bash
# Use provided scripts
bash verify-kiro-compatibility.sh
.\verify-kiro-compatibility.ps1
```

**Manual Tests**:
```bash
curl http://localhost:8085/health
curl http://localhost:8085/listAvailableModels
curl http://localhost:8085/v1/models
```

#### tmp_cloud_audit

**Similar verification** + additional frontend tests

### 13. Kiro IDE Integration (Both)

Both versions use **identical** Kiro IDE configuration:

```json
{
  "bedrock": {
    "endpoint": "http://localhost:PORT"
  }
}
```

Where `PORT` is:
- **8085** for Modular v2.8.0
- **8084** for tmp_cloud_audit

## Recommendations

### Use Modular v2.8.0 When:
1. ✅ Deploying to cloud platforms (Cloud Run, Lambda, Fly.io)
2. ✅ Resource efficiency is priority
3. ✅ Fast deployment cycles needed
4. ✅ Minimal maintenance overhead desired
5. ✅ Docker/container deployments

### Use tmp_cloud_audit When:
1. ✅ Rich admin interface required
2. ✅ TypeScript type safety needed
3. ✅ Local development workstation
4. ✅ Team prefers modern frontend stack
5. ✅ Advanced analytics/monitoring needed

## Migration Path

### From tmp_cloud_audit → Modular v2.8.0

1. Export configuration from tmp_cloud_audit
2. Copy API keys to Modular `.env`
3. Deploy Modular version
4. Update Kiro IDE endpoint port (8084→8085)
5. Verify with `verify-kiro-compatibility.sh`

### From Modular v2.8.0 → tmp_cloud_audit

1. Export configuration from Modular
2. Set up tmp_cloud_audit environment
3. Build frontend: `npm run build`
4. Start server: `npm start`
5. Update Kiro IDE endpoint port (8085→8084)

## Conclusion

Both architectures are **production-ready** and **Kiro IDE compatible**. The choice depends on:

- **Performance/efficiency** → Modular v2.8.0
- **Feature richness** → tmp_cloud_audit
- **Cloud deployment** → Modular v2.8.0
- **Local development** → tmp_cloud_audit

**Current Deployment**: kproxy.space-z.ai uses **Modular v2.8.0** for optimal cloud performance.

---

**Last Updated**: 2026-10-11  
**Comparison Version**: 2.8.0
